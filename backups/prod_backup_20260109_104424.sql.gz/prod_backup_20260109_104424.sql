-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: orange_tata_travel
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=285 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add Blacklisted Token',6,'add_blacklistedtoken'),(22,'Can change Blacklisted Token',6,'change_blacklistedtoken'),(23,'Can delete Blacklisted Token',6,'delete_blacklistedtoken'),(24,'Can view Blacklisted Token',6,'view_blacklistedtoken'),(25,'Can add Outstanding Token',7,'add_outstandingtoken'),(26,'Can change Outstanding Token',7,'change_outstandingtoken'),(27,'Can delete Outstanding Token',7,'delete_outstandingtoken'),(28,'Can view Outstanding Token',7,'view_outstandingtoken'),(29,'Can add cors model',8,'add_corsmodel'),(30,'Can change cors model',8,'change_corsmodel'),(31,'Can delete cors model',8,'delete_corsmodel'),(32,'Can view cors model',8,'view_corsmodel'),(33,'Can add crontab',9,'add_crontabschedule'),(34,'Can change crontab',9,'change_crontabschedule'),(35,'Can delete crontab',9,'delete_crontabschedule'),(36,'Can view crontab',9,'view_crontabschedule'),(37,'Can add interval',10,'add_intervalschedule'),(38,'Can change interval',10,'change_intervalschedule'),(39,'Can delete interval',10,'delete_intervalschedule'),(40,'Can view interval',10,'view_intervalschedule'),(41,'Can add periodic task',11,'add_periodictask'),(42,'Can change periodic task',11,'change_periodictask'),(43,'Can delete periodic task',11,'delete_periodictask'),(44,'Can view periodic task',11,'view_periodictask'),(45,'Can add periodic task track',12,'add_periodictasks'),(46,'Can change periodic task track',12,'change_periodictasks'),(47,'Can delete periodic task track',12,'delete_periodictasks'),(48,'Can view periodic task track',12,'view_periodictasks'),(49,'Can add solar event',13,'add_solarschedule'),(50,'Can change solar event',13,'change_solarschedule'),(51,'Can delete solar event',13,'delete_solarschedule'),(52,'Can view solar event',13,'view_solarschedule'),(53,'Can add clocked',14,'add_clockedschedule'),(54,'Can change clocked',14,'change_clockedschedule'),(55,'Can delete clocked',14,'delete_clockedschedule'),(56,'Can view clocked',14,'view_clockedschedule'),(57,'Can add task result',15,'add_taskresult'),(58,'Can change task result',15,'change_taskresult'),(59,'Can delete task result',15,'delete_taskresult'),(60,'Can view task result',15,'view_taskresult'),(61,'Can add chord counter',16,'add_chordcounter'),(62,'Can change chord counter',16,'change_chordcounter'),(63,'Can delete chord counter',16,'delete_chordcounter'),(64,'Can view chord counter',16,'view_chordcounter'),(65,'Can add group result',17,'add_groupresult'),(66,'Can change group result',17,'change_groupresult'),(67,'Can delete group result',17,'delete_groupresult'),(68,'Can view group result',17,'view_groupresult'),(69,'Can add User',18,'add_user'),(70,'Can change User',18,'change_user'),(71,'Can delete User',18,'delete_user'),(72,'Can view User',18,'view_user'),(73,'Can add permission',19,'add_permission'),(74,'Can change permission',19,'change_permission'),(75,'Can delete permission',19,'delete_permission'),(76,'Can view permission',19,'view_permission'),(77,'Can add Role',20,'add_role'),(78,'Can change Role',20,'change_role'),(79,'Can delete Role',20,'delete_role'),(80,'Can view Role',20,'view_role'),(81,'Can add role permission',21,'add_rolepermission'),(82,'Can change role permission',21,'change_rolepermission'),(83,'Can delete role permission',21,'delete_rolepermission'),(84,'Can view role permission',21,'view_rolepermission'),(85,'Can add user role',22,'add_userrole'),(86,'Can change user role',22,'change_userrole'),(87,'Can delete user role',22,'delete_userrole'),(88,'Can view user role',22,'view_userrole'),(89,'Can add External Profile',23,'add_externalprofile'),(90,'Can change External Profile',23,'change_externalprofile'),(91,'Can delete External Profile',23,'delete_externalprofile'),(92,'Can view External Profile',23,'view_externalprofile'),(93,'Can add Organizational Profile',24,'add_organizationalprofile'),(94,'Can change Organizational Profile',24,'change_organizationalprofile'),(95,'Can delete Organizational Profile',24,'delete_organizationalprofile'),(96,'Can view Organizational Profile',24,'view_organizationalprofile'),(97,'Can add approval workflow master',25,'add_approvalworkflowmaster'),(98,'Can change approval workflow master',25,'change_approvalworkflowmaster'),(99,'Can delete approval workflow master',25,'delete_approvalworkflowmaster'),(100,'Can view approval workflow master',25,'view_approvalworkflowmaster'),(101,'Can add city categories master',26,'add_citycategoriesmaster'),(102,'Can change city categories master',26,'change_citycategoriesmaster'),(103,'Can delete city categories master',26,'delete_citycategoriesmaster'),(104,'Can view city categories master',26,'view_citycategoriesmaster'),(105,'Can add company information',27,'add_companyinformation'),(106,'Can change company information',27,'change_companyinformation'),(107,'Can delete company information',27,'delete_companyinformation'),(108,'Can view company information',27,'view_companyinformation'),(109,'Can add country master',28,'add_countrymaster'),(110,'Can change country master',28,'change_countrymaster'),(111,'Can delete country master',28,'delete_countrymaster'),(112,'Can view country master',28,'view_countrymaster'),(113,'Can add designation master',29,'add_designationmaster'),(114,'Can change designation master',29,'change_designationmaster'),(115,'Can delete designation master',29,'delete_designationmaster'),(116,'Can view designation master',29,'view_designationmaster'),(117,'Can add employee type master',30,'add_employeetypemaster'),(118,'Can change employee type master',30,'change_employeetypemaster'),(119,'Can delete employee type master',30,'delete_employeetypemaster'),(120,'Can view employee type master',30,'view_employeetypemaster'),(121,'Can add gl code master',31,'add_glcodemaster'),(122,'Can change gl code master',31,'change_glcodemaster'),(123,'Can delete gl code master',31,'delete_glcodemaster'),(124,'Can view gl code master',31,'view_glcodemaster'),(125,'Can add grade master',32,'add_grademaster'),(126,'Can change grade master',32,'change_grademaster'),(127,'Can delete grade master',32,'delete_grademaster'),(128,'Can view grade master',32,'view_grademaster'),(129,'Can add permission type master',33,'add_permissiontypemaster'),(130,'Can change permission type master',33,'change_permissiontypemaster'),(131,'Can delete permission type master',33,'delete_permissiontypemaster'),(132,'Can view permission type master',33,'view_permissiontypemaster'),(133,'Can add travel mode master',34,'add_travelmodemaster'),(134,'Can change travel mode master',34,'change_travelmodemaster'),(135,'Can delete travel mode master',34,'delete_travelmodemaster'),(136,'Can view travel mode master',34,'view_travelmodemaster'),(137,'Can add vehicle type master',35,'add_vehicletypemaster'),(138,'Can change vehicle type master',35,'change_vehicletypemaster'),(139,'Can delete vehicle type master',35,'delete_vehicletypemaster'),(140,'Can view vehicle type master',35,'view_vehicletypemaster'),(141,'Can add city master',36,'add_citymaster'),(142,'Can change city master',36,'change_citymaster'),(143,'Can delete city master',36,'delete_citymaster'),(144,'Can view city master',36,'view_citymaster'),(145,'Can add conveyance rate master',37,'add_conveyanceratemaster'),(146,'Can change conveyance rate master',37,'change_conveyanceratemaster'),(147,'Can delete conveyance rate master',37,'delete_conveyanceratemaster'),(148,'Can view conveyance rate master',37,'view_conveyanceratemaster'),(149,'Can add state master',38,'add_statemaster'),(150,'Can change state master',38,'change_statemaster'),(151,'Can delete state master',38,'delete_statemaster'),(152,'Can view state master',38,'view_statemaster'),(153,'Can add location master',39,'add_locationmaster'),(154,'Can change location master',39,'change_locationmaster'),(155,'Can delete location master',39,'delete_locationmaster'),(156,'Can view location master',39,'view_locationmaster'),(157,'Can add travel sub option master',40,'add_travelsuboptionmaster'),(158,'Can change travel sub option master',40,'change_travelsuboptionmaster'),(159,'Can delete travel sub option master',40,'delete_travelsuboptionmaster'),(160,'Can view travel sub option master',40,'view_travelsuboptionmaster'),(161,'Can add department master',41,'add_departmentmaster'),(162,'Can change department master',41,'change_departmentmaster'),(163,'Can delete department master',41,'delete_departmentmaster'),(164,'Can view department master',41,'view_departmentmaster'),(165,'Can add da incidental master',42,'add_daincidentalmaster'),(166,'Can change da incidental master',42,'change_daincidentalmaster'),(167,'Can delete da incidental master',42,'delete_daincidentalmaster'),(168,'Can view da incidental master',42,'view_daincidentalmaster'),(169,'Can add location spoc',43,'add_locationspoc'),(170,'Can change location spoc',43,'change_locationspoc'),(171,'Can delete location spoc',43,'delete_locationspoc'),(172,'Can view location spoc',43,'view_locationspoc'),(173,'Can add guest house master',44,'add_guesthousemaster'),(174,'Can change guest house master',44,'change_guesthousemaster'),(175,'Can delete guest house master',44,'delete_guesthousemaster'),(176,'Can view guest house master',44,'view_guesthousemaster'),(177,'Can add arc hotel master',45,'add_archotelmaster'),(178,'Can change arc hotel master',45,'change_archotelmaster'),(179,'Can delete arc hotel master',45,'delete_archotelmaster'),(180,'Can view arc hotel master',45,'view_archotelmaster'),(181,'Can add approval matrix',46,'add_approvalmatrix'),(182,'Can change approval matrix',46,'change_approvalmatrix'),(183,'Can delete approval matrix',46,'delete_approvalmatrix'),(184,'Can view approval matrix',46,'view_approvalmatrix'),(185,'Can add travel policy master',47,'add_travelpolicymaster'),(186,'Can change travel policy master',47,'change_travelpolicymaster'),(187,'Can delete travel policy master',47,'delete_travelpolicymaster'),(188,'Can view travel policy master',47,'view_travelpolicymaster'),(189,'Can add grade entitlement master',48,'add_gradeentitlementmaster'),(190,'Can change grade entitlement master',48,'change_gradeentitlementmaster'),(191,'Can delete grade entitlement master',48,'delete_gradeentitlementmaster'),(192,'Can view grade entitlement master',48,'view_gradeentitlementmaster'),(193,'Can add city category assignment',49,'add_citycategoryassignment'),(194,'Can change city category assignment',49,'change_citycategoryassignment'),(195,'Can delete city category assignment',49,'delete_citycategoryassignment'),(196,'Can view city category assignment',49,'view_citycategoryassignment'),(197,'Can add booking',50,'add_booking'),(198,'Can change booking',50,'change_booking'),(199,'Can delete booking',50,'delete_booking'),(200,'Can view booking',50,'view_booking'),(201,'Can add travel application',51,'add_travelapplication'),(202,'Can change travel application',51,'change_travelapplication'),(203,'Can delete travel application',51,'delete_travelapplication'),(204,'Can view travel application',51,'view_travelapplication'),(205,'Can add travel approval flow',52,'add_travelapprovalflow'),(206,'Can change travel approval flow',52,'change_travelapprovalflow'),(207,'Can delete travel approval flow',52,'delete_travelapprovalflow'),(208,'Can view travel approval flow',52,'view_travelapprovalflow'),(209,'Can add travel document',53,'add_traveldocument'),(210,'Can change travel document',53,'change_traveldocument'),(211,'Can delete travel document',53,'delete_traveldocument'),(212,'Can view travel document',53,'view_traveldocument'),(213,'Can add trip details',54,'add_tripdetails'),(214,'Can change trip details',54,'change_tripdetails'),(215,'Can delete trip details',54,'delete_tripdetails'),(216,'Can view trip details',54,'view_tripdetails'),(217,'Can add accommodation booking',55,'add_accommodationbooking'),(218,'Can change accommodation booking',55,'change_accommodationbooking'),(219,'Can delete accommodation booking',55,'delete_accommodationbooking'),(220,'Can view accommodation booking',55,'view_accommodationbooking'),(221,'Can add vehicle booking',56,'add_vehiclebooking'),(222,'Can change vehicle booking',56,'change_vehiclebooking'),(223,'Can delete vehicle booking',56,'delete_vehiclebooking'),(224,'Can view vehicle booking',56,'view_vehiclebooking'),(225,'Can add travel advance request',57,'add_traveladvancerequest'),(226,'Can change travel advance request',57,'change_traveladvancerequest'),(227,'Can delete travel advance request',57,'delete_traveladvancerequest'),(228,'Can view travel advance request',57,'view_traveladvancerequest'),(229,'Can add audit log',58,'add_auditlog'),(230,'Can change audit log',58,'change_auditlog'),(231,'Can delete audit log',58,'delete_auditlog'),(232,'Can view audit log',58,'view_auditlog'),(233,'Can add booking assignment',59,'add_bookingassignment'),(234,'Can change booking assignment',59,'change_bookingassignment'),(235,'Can delete booking assignment',59,'delete_bookingassignment'),(236,'Can view booking assignment',59,'view_bookingassignment'),(237,'Can add booking note',60,'add_bookingnote'),(238,'Can change booking note',60,'change_bookingnote'),(239,'Can delete booking note',60,'delete_bookingnote'),(240,'Can view booking note',60,'view_bookingnote'),(241,'Can add expense claim',61,'add_expenseclaim'),(242,'Can change expense claim',61,'change_expenseclaim'),(243,'Can delete expense claim',61,'delete_expenseclaim'),(244,'Can view expense claim',61,'view_expenseclaim'),(245,'Can add da incidental breakdown',62,'add_daincidentalbreakdown'),(246,'Can change da incidental breakdown',62,'change_daincidentalbreakdown'),(247,'Can delete da incidental breakdown',62,'delete_daincidentalbreakdown'),(248,'Can view da incidental breakdown',62,'view_daincidentalbreakdown'),(249,'Can add claim document',63,'add_claimdocument'),(250,'Can change claim document',63,'change_claimdocument'),(251,'Can delete claim document',63,'delete_claimdocument'),(252,'Can view claim document',63,'view_claimdocument'),(253,'Can add claim approval flow',64,'add_claimapprovalflow'),(254,'Can change claim approval flow',64,'change_claimapprovalflow'),(255,'Can delete claim approval flow',64,'delete_claimapprovalflow'),(256,'Can view claim approval flow',64,'view_claimapprovalflow'),(257,'Can add expense item',65,'add_expenseitem'),(258,'Can change expense item',65,'change_expenseitem'),(259,'Can delete expense item',65,'delete_expenseitem'),(260,'Can view expense item',65,'view_expenseitem'),(261,'Can add claim status master',66,'add_claimstatusmaster'),(262,'Can change claim status master',66,'change_claimstatusmaster'),(263,'Can delete claim status master',66,'delete_claimstatusmaster'),(264,'Can view claim status master',66,'view_claimstatusmaster'),(265,'Can add expense type master',67,'add_expensetypemaster'),(266,'Can change expense type master',67,'change_expensetypemaster'),(267,'Can delete expense type master',67,'delete_expensetypemaster'),(268,'Can view expense type master',67,'view_expensetypemaster'),(269,'Can add email template master',68,'add_emailtemplatemaster'),(270,'Can change email template master',68,'change_emailtemplatemaster'),(271,'Can delete email template master',68,'delete_emailtemplatemaster'),(272,'Can view email template master',68,'view_emailtemplatemaster'),(273,'Can add notification log',69,'add_notificationlog'),(274,'Can change notification log',69,'change_notificationlog'),(275,'Can delete notification log',69,'delete_notificationlog'),(276,'Can view notification log',69,'view_notificationlog'),(277,'Can add notification rule',70,'add_notificationrule'),(278,'Can change notification rule',70,'change_notificationrule'),(279,'Can delete notification rule',70,'delete_notificationrule'),(280,'Can view notification rule',70,'view_notificationrule'),(281,'Can add notification event',71,'add_notificationevent'),(282,'Can change notification event',71,'change_notificationevent'),(283,'Can delete notification event',71,'delete_notificationevent'),(284,'Can view notification event',71,'view_notificationevent');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `grade_id` bigint DEFAULT NULL,
  `reporting_manager_id` bigint DEFAULT NULL,
  `base_location_id` int DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `designation_id` int DEFAULT NULL,
  `employee_type_id` bigint DEFAULT NULL,
  `gender` varchar(1) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `hrms_id` int DEFAULT NULL,
  `mobile_no` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `employee_id` (`employee_id`),
  UNIQUE KEY `hrms_id` (`hrms_id`),
  KEY `authentication_user_grade_id_7ef3252b_fk_master_da` (`grade_id`),
  KEY `authentication_user_reporting_manager_id_495dfcd8_fk_authentic` (`reporting_manager_id`),
  KEY `authentication_user_base_location_id_607e585d_fk_master_da` (`base_location_id`),
  KEY `authentication_user_company_id_a38f3939_fk_master_da` (`company_id`),
  KEY `authentication_user_department_id_dd2b59c0_fk_master_da` (`department_id`),
  KEY `authentication_user_designation_id_874d4d76_fk_master_da` (`designation_id`),
  KEY `authentication_user_employee_type_id_08909b33_fk_master_da` (`employee_type_id`),
  CONSTRAINT `authentication_user_base_location_id_607e585d_fk_master_da` FOREIGN KEY (`base_location_id`) REFERENCES `master_data_locationmaster` (`location_id`),
  CONSTRAINT `authentication_user_company_id_a38f3939_fk_master_da` FOREIGN KEY (`company_id`) REFERENCES `master_data_companyinformation` (`id`),
  CONSTRAINT `authentication_user_department_id_dd2b59c0_fk_master_da` FOREIGN KEY (`department_id`) REFERENCES `master_data_departmentmaster` (`department_id`),
  CONSTRAINT `authentication_user_designation_id_874d4d76_fk_master_da` FOREIGN KEY (`designation_id`) REFERENCES `master_data_designationmaster` (`designation_id`),
  CONSTRAINT `authentication_user_employee_type_id_08909b33_fk_master_da` FOREIGN KEY (`employee_type_id`) REFERENCES `master_data_employeetypemaster` (`id`),
  CONSTRAINT `authentication_user_grade_id_7ef3252b_fk_master_da` FOREIGN KEY (`grade_id`) REFERENCES `master_data_grademaster` (`id`),
  CONSTRAINT `authentication_user_reporting_manager_id_495dfcd8_fk_authentic` FOREIGN KEY (`reporting_manager_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$1000000$nFadXsa4jDU2ofE3qMpdFa$3Sm1cbOIe8GjqUXF9HWE+K1wlSBDjHjYM5UqEUuwNyk=','2026-01-07 06:26:59.000000',1,'admin','Admin','Master','vasupatel303@gmail.com',1,1,'2025-12-31 06:21:17.000000',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'M','organizational',NULL,NULL),(2,'!pIAwIwSLtxoz9xvpKm0z0UjwsEPVKiqGXVdhgR1n',NULL,0,'admin@tsf.com','admin','(SSO Admin)','admin_at_tsf.com@sso.local',0,1,'2026-01-01 05:09:05.000000',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'M','organizational',NULL,NULL),(3,'',NULL,0,'00262@hrms','Mr.','Mant Kumar','',0,1,'2026-01-01 06:43:04.901955',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,'M','organizational',11,'09431329743'),(4,'',NULL,0,'149971@hrms','Mr.','Laxman Ranguri','',0,1,'2026-01-01 06:43:05.628921',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,'M','organizational',672,''),(5,'',NULL,0,'113707@hrms','Ms.','Urmila Ekka','',0,1,'2026-01-01 06:46:51.822999',NULL,6,NULL,NULL,NULL,NULL,NULL,NULL,'F','organizational',152,''),(6,'',NULL,0,'trainee@orangewebtech.com','Mr.','Syed Jamil Ahmad','trainee@orangewebtech.com',0,1,'2026-01-05 09:41:12.000000',NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,'M','organizational',8,'09006140530'),(7,'',NULL,0,'ronak.k@orangewebtech.com','Dr.','Anuj Bhatnagar','ronak.k@orangewebtech.com',0,1,'2026-01-05 09:41:12.914807',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,'M','organizational',673,'750710095'),(8,'',NULL,0,'197582@hrms','Mr.',' Sourav Roy','',0,1,'2026-01-05 12:58:03.349588',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,'M','organizational',464,'7368806262'),(9,'',NULL,0,'vasu.patel.orangewebtech@gmail.com','Ms.','Smita Verma','vasu.patel.orangewebtech@gmail.com',0,1,'2026-01-05 13:22:47.000000',NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,'F','organizational',26,'07209691209'),(10,'',NULL,0,'97587@hrms','Mr.','Suraj','',0,1,'2026-01-06 10:16:15.293836',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'M','organizational',824,''),(11,'pbkdf2_sha256$1000000$tKOX9lFtersMtjs8VxHq9T$foOGIAp7lxUnYefo7LMBu9QqmFJL4jDT+x2M/Ez4JKo=',NULL,0,'EasternTravel','Bibhuti','B Dash','bibhuti.bdash@easterntravels.co.in',0,1,'2026-01-08 09:47:39.000000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'M','external',NULL,NULL);
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authentication_user_groups_user_id_group_id_8af031ac_uniq` (`user_id`,`group_id`),
  KEY `authentication_user_groups_group_id_6b5c44b7_fk_auth_group_id` (`group_id`),
  CONSTRAINT `authentication_user__user_id_30868577_fk_authentic` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `authentication_user_groups_group_id_6b5c44b7_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authentication_user_user_user_id_permission_id_ec51b09f_uniq` (`user_id`,`permission_id`),
  KEY `authentication_user__permission_id_ea6be19a_fk_auth_perm` (`permission_id`),
  CONSTRAINT `authentication_user__permission_id_ea6be19a_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `authentication_user__user_id_736ebf7e_fk_authentic` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_authentication_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_authentication_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2026-01-06 07:23:37.174177','9','vasu.patel.orangewebtech@gmail.com (Organizational User)',2,'[{\"added\": {\"name\": \"user role\", \"object\": \"vasu.patel.orangewebtech@gmail.com - Travel Desk (Primary)\"}}, {\"changed\": {\"name\": \"user role\", \"object\": \"vasu.patel.orangewebtech@gmail.com - Employee\", \"fields\": [\"Is primary\"]}}]',18,1),(2,'2026-01-06 07:28:50.265502','9','vasu.patel.orangewebtech@gmail.com (Organizational User)',2,'[{\"deleted\": {\"name\": \"user role\", \"object\": \"vasu.patel.orangewebtech@gmail.com - Employee\"}}, {\"deleted\": {\"name\": \"user role\", \"object\": \"vasu.patel.orangewebtech@gmail.com - Travel Desk (Primary)\"}}]',18,1),(3,'2026-01-06 07:29:03.008201','9','vasu.patel.orangewebtech@gmail.com (Organizational User)',2,'[{\"added\": {\"name\": \"user role\", \"object\": \"vasu.patel.orangewebtech@gmail.com - Travel Desk (Primary)\"}}]',18,1),(4,'2026-01-06 07:29:13.738480','9','vasu.patel.orangewebtech@gmail.com (Organizational User)',2,'[{\"added\": {\"name\": \"user role\", \"object\": \"vasu.patel.orangewebtech@gmail.com - Employee\"}}]',18,1),(5,'2026-01-06 08:53:46.774369','6','trainee@orangewebtech.com (Organizational User)',2,'[{\"changed\": {\"name\": \"Organizational Profile\", \"object\": \"8 - Mr. Syed Jamil Ahmad\", \"fields\": [\"Grade\"]}}]',18,1),(6,'2026-01-06 08:57:14.904718','9','vasu.patel.orangewebtech@gmail.com (Organizational User)',2,'[{\"deleted\": {\"name\": \"user role\", \"object\": \"vasu.patel.orangewebtech@gmail.com - Employee\"}}]',18,1),(7,'2026-01-07 07:54:49.363320','7','TR-7 - 97587@hrms (pending_manager)',3,'',51,1),(8,'2026-01-07 07:54:49.363364','6','TR-6 - trainee@orangewebtech.com (pending_travel_desk)',3,'',51,1),(9,'2026-01-07 07:54:49.363383','5','TR-5 - trainee@orangewebtech.com (pending_travel_desk)',3,'',51,1),(10,'2026-01-07 07:54:49.363399','4','TR-4 - trainee@orangewebtech.com (draft)',3,'',51,1),(11,'2026-01-07 07:54:49.363454','3','TR-3 - trainee@orangewebtech.com (pending_travel_desk)',3,'',51,1),(12,'2026-01-07 07:54:49.363483','2','TR-2 - ronak.k@orangewebtech.com (pending_travel_desk)',3,'',51,1),(13,'2026-01-07 07:54:49.363499','1','TR-1 - trainee@orangewebtech.com (cancelled)',3,'',51,1),(14,'2026-01-07 07:55:02.880862','1','India',3,'',28,1),(15,'2026-01-07 11:33:39.669527','1','admin (Organizational User)',2,'[{\"changed\": {\"fields\": [\"Gender\"]}}, {\"added\": {\"name\": \"Organizational Profile\", \"object\": \"No ID - \"}}]',18,1),(16,'2026-01-07 11:35:17.818511','1','admin (Organizational User)',2,'[{\"added\": {\"name\": \"user role\", \"object\": \"admin - Travel Desk\"}}]',18,1),(17,'2026-01-07 11:35:33.607141','1','admin (Organizational User)',2,'[{\"added\": {\"name\": \"user role\", \"object\": \"admin - Booking Agent\"}}, {\"added\": {\"name\": \"user role\", \"object\": \"admin - CEO\"}}, {\"added\": {\"name\": \"user role\", \"object\": \"admin - CHRO\"}}]',18,1),(18,'2026-01-08 05:38:51.161904','1','admin (Organizational User)',2,'[{\"changed\": {\"fields\": [\"First name\", \"Last name\"]}}]',18,1),(19,'2026-01-08 08:31:54.277175','1','Auto / Local Travel',1,'[{\"added\": {}}]',67,1),(20,'2026-01-08 08:31:59.947967','2','Bus',1,'[{\"added\": {}}]',67,1),(21,'2026-01-08 08:32:09.097296','3','Flight',1,'[{\"added\": {}}]',67,1),(22,'2026-01-08 08:32:17.856465','4','Train',1,'[{\"added\": {}}]',67,1),(23,'2026-01-08 08:32:30.167614','5','Food/Meal',1,'[{\"added\": {}}]',67,1),(24,'2026-01-08 08:32:37.535743','6','Fuel',1,'[{\"added\": {}}]',67,1),(25,'2026-01-08 08:32:54.432224','7','Hotel/Guest House/etc.',1,'[{\"added\": {}}]',67,1),(26,'2026-01-08 08:33:07.078519','8','Miscellaneous',1,'[{\"added\": {}}]',67,1),(27,'2026-01-08 08:33:13.404530','9','Parking',1,'[{\"added\": {}}]',67,1),(28,'2026-01-08 08:33:22.741546','10','Personal Car',1,'[{\"added\": {}}]',67,1),(29,'2026-01-08 08:33:28.169856','11','Taxi',1,'[{\"added\": {}}]',67,1),(30,'2026-01-08 08:33:33.300828','12','Toll',1,'[{\"added\": {}}]',67,1),(31,'2026-01-08 08:33:58.694735','10','Personal Car',2,'[{\"changed\": {\"fields\": [\"Is distance based\"]}}]',67,1),(32,'2026-01-08 08:34:24.489919','1','Draft',1,'[{\"added\": {}}]',66,1),(33,'2026-01-08 08:34:31.775010','2','Submitted',1,'[{\"added\": {}}]',66,1),(34,'2026-01-08 08:34:41.111911','3','Manager Pending',1,'[{\"added\": {}}]',66,1),(35,'2026-01-08 08:34:58.285214','4','Finance Pending',1,'[{\"added\": {}}]',66,1),(36,'2026-01-08 08:35:18.620431','5','CHRO_Pending',1,'[{\"added\": {}}]',66,1),(37,'2026-01-08 08:35:29.821715','6','Approved',1,'[{\"added\": {}}]',66,1),(38,'2026-01-08 08:35:38.330539','7','Rejected',1,'[{\"added\": {}}]',66,1),(39,'2026-01-08 08:35:45.843486','8','Paid',1,'[{\"added\": {}}]',66,1),(40,'2026-01-08 08:35:53.977815','9','Closed',1,'[{\"added\": {}}]',66,1),(41,'2026-01-08 08:36:08.097419','2','Submitted',2,'[{\"changed\": {\"fields\": [\"Sequence\"]}}]',66,1),(42,'2026-01-08 08:36:13.605503','3','Manager Pending',2,'[{\"changed\": {\"fields\": [\"Sequence\"]}}]',66,1),(43,'2026-01-08 08:36:18.115451','4','Finance Pending',2,'[{\"changed\": {\"fields\": [\"Sequence\"]}}]',66,1),(44,'2026-01-08 08:36:23.593003','5','CHRO_Pending',2,'[{\"changed\": {\"fields\": [\"Sequence\"]}}]',66,1),(45,'2026-01-08 09:47:40.115749','11','EasternTravel (External User)',1,'[{\"added\": {}}, {\"added\": {\"name\": \"user role\", \"object\": \"EasternTravel - Booking Agent (Primary)\"}}]',18,1),(46,'2026-01-08 09:48:32.177719','11','Eastern Travel (Booking Agent)',1,'[{\"added\": {}}]',23,1),(47,'2026-01-08 11:04:13.147989','4','Finance Pending',3,'',66,1),(48,'2026-01-08 11:04:13.148028','5','CHRO_Pending',3,'',66,1),(49,'2026-01-08 11:04:24.452029','6','Approved',2,'[{\"changed\": {\"fields\": [\"Sequence\"]}}]',66,1),(50,'2026-01-08 11:04:30.851246','7','Rejected',2,'[{\"changed\": {\"fields\": [\"Sequence\"]}}]',66,1),(51,'2026-01-08 11:04:36.766433','8','Paid',2,'[{\"changed\": {\"fields\": [\"Sequence\"]}}]',66,1),(52,'2026-01-08 11:04:40.990769','9','Closed',2,'[{\"changed\": {\"fields\": [\"Sequence\"]}}]',66,1),(53,'2026-01-08 11:06:32.648346','1','GL-Test - Update/Remove it later',3,'',31,1),(54,'2026-01-08 11:45:29.598095','11','EasternTravel (External User)',2,'[{\"changed\": {\"fields\": [\"First name\", \"Last name\", \"Email address\"]}}]',18,1),(55,'2026-01-08 11:47:38.138743','7','Booking Agent',2,'[{\"changed\": {\"fields\": [\"Role type\"]}}]',20,1),(56,'2026-01-08 11:47:44.218091','4','CEO',2,'[{\"changed\": {\"fields\": [\"Role type\"]}}]',20,1),(57,'2026-01-08 11:47:51.422083','5','CHRO',2,'[{\"changed\": {\"fields\": [\"Role type\"]}}]',20,1),(58,'2026-01-08 11:48:05.745291','6','Travel Desk',2,'[{\"changed\": {\"fields\": [\"Role type\"]}}]',20,1),(59,'2026-01-08 12:12:50.989884','2','admin@tsf.com (Organizational User)',2,'[{\"added\": {\"name\": \"user role\", \"object\": \"admin@tsf.com - Booking Agent\"}}, {\"added\": {\"name\": \"user role\", \"object\": \"admin@tsf.com - Travel Desk\"}}]',18,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_clockedschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_clockedschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_clockedschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `clocked_time` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_clockedschedule`
--

LOCK TABLES `django_celery_beat_clockedschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_clockedschedule` DISABLE KEYS */;
INSERT INTO `django_celery_beat_clockedschedule` VALUES (1,'2026-01-07 01:00:00.000000'),(2,'2026-02-07 01:00:00.000000'),(3,'2026-01-19 01:00:00.000000'),(4,'2026-01-21 01:00:00.000000'),(5,'2026-01-29 01:00:00.000000');
/*!40000 ALTER TABLE `django_celery_beat_clockedschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_crontabschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_crontabschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_crontabschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `minute` varchar(240) NOT NULL,
  `hour` varchar(96) NOT NULL,
  `day_of_week` varchar(64) NOT NULL,
  `day_of_month` varchar(124) NOT NULL,
  `month_of_year` varchar(64) NOT NULL,
  `timezone` varchar(63) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_crontabschedule`
--

LOCK TABLES `django_celery_beat_crontabschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_crontabschedule` DISABLE KEYS */;
INSERT INTO `django_celery_beat_crontabschedule` VALUES (1,'0','4','*','*','*','UTC');
/*!40000 ALTER TABLE `django_celery_beat_crontabschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_intervalschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_intervalschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_intervalschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `every` int NOT NULL,
  `period` varchar(24) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_intervalschedule`
--

LOCK TABLES `django_celery_beat_intervalschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_intervalschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_intervalschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_periodictask`
--

DROP TABLE IF EXISTS `django_celery_beat_periodictask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_periodictask` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `task` varchar(200) NOT NULL,
  `args` longtext NOT NULL,
  `kwargs` longtext NOT NULL,
  `queue` varchar(200) DEFAULT NULL,
  `exchange` varchar(200) DEFAULT NULL,
  `routing_key` varchar(200) DEFAULT NULL,
  `expires` datetime(6) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL,
  `last_run_at` datetime(6) DEFAULT NULL,
  `total_run_count` int unsigned NOT NULL,
  `date_changed` datetime(6) NOT NULL,
  `description` longtext NOT NULL,
  `crontab_id` int DEFAULT NULL,
  `interval_id` int DEFAULT NULL,
  `solar_id` int DEFAULT NULL,
  `one_off` tinyint(1) NOT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `priority` int unsigned DEFAULT NULL,
  `headers` longtext NOT NULL DEFAULT (_utf8mb4'{}'),
  `clocked_id` int DEFAULT NULL,
  `expire_seconds` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `django_celery_beat_p_crontab_id_d3cba168_fk_django_ce` (`crontab_id`),
  KEY `django_celery_beat_p_interval_id_a8ca27da_fk_django_ce` (`interval_id`),
  KEY `django_celery_beat_p_solar_id_a87ce72c_fk_django_ce` (`solar_id`),
  KEY `django_celery_beat_p_clocked_id_47a69f82_fk_django_ce` (`clocked_id`),
  CONSTRAINT `django_celery_beat_p_clocked_id_47a69f82_fk_django_ce` FOREIGN KEY (`clocked_id`) REFERENCES `django_celery_beat_clockedschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_crontab_id_d3cba168_fk_django_ce` FOREIGN KEY (`crontab_id`) REFERENCES `django_celery_beat_crontabschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_interval_id_a8ca27da_fk_django_ce` FOREIGN KEY (`interval_id`) REFERENCES `django_celery_beat_intervalschedule` (`id`),
  CONSTRAINT `django_celery_beat_p_solar_id_a87ce72c_fk_django_ce` FOREIGN KEY (`solar_id`) REFERENCES `django_celery_beat_solarschedule` (`id`),
  CONSTRAINT `django_celery_beat_periodictask_chk_1` CHECK ((`total_run_count` >= 0)),
  CONSTRAINT `django_celery_beat_periodictask_chk_2` CHECK ((`priority` >= 0)),
  CONSTRAINT `django_celery_beat_periodictask_chk_3` CHECK ((`expire_seconds` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_periodictask`
--

LOCK TABLES `django_celery_beat_periodictask` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_periodictask` DISABLE KEYS */;
INSERT INTO `django_celery_beat_periodictask` VALUES (1,'celery.backend_cleanup','celery.backend_cleanup','[]','{}',NULL,NULL,NULL,NULL,1,'2026-01-08 04:00:00.006700',8,'2026-01-08 04:00:05.110090','',1,NULL,NULL,0,NULL,NULL,'{}',NULL,43200),(2,'travel_complete_1','notifications.tasks.mark_travel_as_completed','[1]','{}',NULL,NULL,NULL,NULL,0,NULL,0,'2026-01-07 01:02:15.535681','',NULL,NULL,NULL,1,NULL,NULL,'{}',1,NULL),(3,'travel_complete_3','notifications.tasks.mark_travel_as_completed','[3]','{}',NULL,NULL,NULL,NULL,1,NULL,0,'2026-01-05 13:35:30.318107','',NULL,NULL,NULL,1,NULL,NULL,'{}',2,NULL),(4,'travel_complete_7','notifications.tasks.mark_travel_as_completed','[7]','{}',NULL,NULL,NULL,NULL,1,NULL,0,'2026-01-06 10:20:47.365835','',NULL,NULL,NULL,1,NULL,NULL,'{}',3,NULL),(5,'travel_complete_11','notifications.tasks.mark_travel_as_completed','[11]','{}',NULL,NULL,NULL,NULL,1,NULL,0,'2026-01-08 06:08:46.939189','',NULL,NULL,NULL,1,NULL,NULL,'{}',4,NULL),(6,'travel_complete_13','notifications.tasks.mark_travel_as_completed','[13]','{}',NULL,NULL,NULL,NULL,1,NULL,0,'2026-01-08 09:33:49.404909','',NULL,NULL,NULL,1,NULL,NULL,'{}',2,NULL),(7,'travel_complete_12','notifications.tasks.mark_travel_as_completed','[12]','{}',NULL,NULL,NULL,NULL,1,NULL,0,'2026-01-08 09:34:45.178827','',NULL,NULL,NULL,1,NULL,NULL,'{}',5,NULL);
/*!40000 ALTER TABLE `django_celery_beat_periodictask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_periodictasks`
--

DROP TABLE IF EXISTS `django_celery_beat_periodictasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_periodictasks` (
  `ident` smallint NOT NULL,
  `last_update` datetime(6) NOT NULL,
  PRIMARY KEY (`ident`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_periodictasks`
--

LOCK TABLES `django_celery_beat_periodictasks` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_periodictasks` DISABLE KEYS */;
INSERT INTO `django_celery_beat_periodictasks` VALUES (1,'2026-01-08 09:34:45.179474');
/*!40000 ALTER TABLE `django_celery_beat_periodictasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_beat_solarschedule`
--

DROP TABLE IF EXISTS `django_celery_beat_solarschedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_beat_solarschedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `event` varchar(24) NOT NULL,
  `latitude` decimal(9,6) NOT NULL,
  `longitude` decimal(9,6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_celery_beat_solar_event_latitude_longitude_ba64999a_uniq` (`event`,`latitude`,`longitude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_beat_solarschedule`
--

LOCK TABLES `django_celery_beat_solarschedule` WRITE;
/*!40000 ALTER TABLE `django_celery_beat_solarschedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_beat_solarschedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_chordcounter`
--

DROP TABLE IF EXISTS `django_celery_results_chordcounter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_results_chordcounter` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` varchar(255) NOT NULL,
  `sub_tasks` longtext NOT NULL,
  `count` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`),
  CONSTRAINT `django_celery_results_chordcounter_chk_1` CHECK ((`count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_chordcounter`
--

LOCK TABLES `django_celery_results_chordcounter` WRITE;
/*!40000 ALTER TABLE `django_celery_results_chordcounter` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_results_chordcounter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_groupresult`
--

DROP TABLE IF EXISTS `django_celery_results_groupresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_results_groupresult` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` varchar(255) NOT NULL,
  `date_created` datetime(6) NOT NULL,
  `date_done` datetime(6) NOT NULL,
  `content_type` varchar(128) NOT NULL,
  `content_encoding` varchar(64) NOT NULL,
  `result` longtext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`),
  KEY `django_cele_date_cr_bd6c1d_idx` (`date_created`),
  KEY `django_cele_date_do_caae0e_idx` (`date_done`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_groupresult`
--

LOCK TABLES `django_celery_results_groupresult` WRITE;
/*!40000 ALTER TABLE `django_celery_results_groupresult` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_celery_results_groupresult` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_celery_results_taskresult`
--

DROP TABLE IF EXISTS `django_celery_results_taskresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_celery_results_taskresult` (
  `id` int NOT NULL AUTO_INCREMENT,
  `task_id` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL,
  `content_type` varchar(128) NOT NULL,
  `content_encoding` varchar(64) NOT NULL,
  `result` longtext,
  `date_done` datetime(6) NOT NULL,
  `traceback` longtext,
  `meta` longtext,
  `task_args` longtext,
  `task_kwargs` longtext,
  `task_name` varchar(255) DEFAULT NULL,
  `worker` varchar(100) DEFAULT NULL,
  `date_created` datetime(6) NOT NULL,
  `periodic_task_name` varchar(255) DEFAULT NULL,
  `date_started` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `task_id` (`task_id`),
  KEY `django_cele_task_na_08aec9_idx` (`task_name`),
  KEY `django_cele_status_9b6201_idx` (`status`),
  KEY `django_cele_worker_d54dd8_idx` (`worker`),
  KEY `django_cele_date_cr_f04a50_idx` (`date_created`),
  KEY `django_cele_date_do_f59aad_idx` (`date_done`),
  KEY `django_cele_periodi_1993cf_idx` (`periodic_task_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_celery_results_taskresult`
--

LOCK TABLES `django_celery_results_taskresult` WRITE;
/*!40000 ALTER TABLE `django_celery_results_taskresult` DISABLE KEYS */;
INSERT INTO `django_celery_results_taskresult` VALUES (1,'69db8853-ed31-4181-bd97-44e0f9d46249','SUCCESS','application/json','utf-8','null','2026-01-05 13:08:58.248331',NULL,'{\"children\": []}',NULL,NULL,NULL,NULL,'2026-01-05 13:08:53.906146',NULL,'2026-01-05 13:08:53.909821'),(2,'0de85682-f599-4054-b9d9-8ea95f171786','SUCCESS','application/json','utf-8','null','2026-01-05 13:08:58.284330',NULL,'{\"children\": []}',NULL,NULL,NULL,NULL,'2026-01-05 13:08:58.270839',NULL,'2026-01-05 13:08:58.271190'),(3,'a1433893-6573-49df-bf65-10233553187e','SUCCESS','application/json','utf-8','null','2026-01-05 13:09:37.087908',NULL,'{\"children\": []}',NULL,NULL,NULL,NULL,'2026-01-05 13:09:33.581806',NULL,'2026-01-05 13:09:33.582252'),(4,'e71a4d04-5096-45d4-ac3d-49bfe564ad32','SUCCESS','application/json','utf-8','null','2026-01-05 13:09:37.133445',NULL,'{\"children\": []}',NULL,NULL,NULL,NULL,'2026-01-05 13:09:37.109645',NULL,'2026-01-05 13:09:37.109945'),(5,'4fee5e3d-40a2-4114-9f01-a7099eb66eda','FAILURE','application/json','utf-8','{\"exc_type\": \"NotRegistered\", \"exc_message\": [\"notifications.tasks.mark_travel_as_completed\"], \"exc_module\": \"celery.exceptions\"}','2026-01-07 01:00:00.684150',NULL,'{\"children\": []}',NULL,NULL,NULL,NULL,'2026-01-07 01:00:00.682133',NULL,NULL);
/*!40000 ALTER TABLE `django_celery_results_taskresult` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(23,'authentication','externalprofile'),(24,'authentication','organizationalprofile'),(19,'authentication','permission'),(20,'authentication','role'),(21,'authentication','rolepermission'),(18,'authentication','user'),(22,'authentication','userrole'),(4,'contenttypes','contenttype'),(8,'corsheaders','corsmodel'),(14,'django_celery_beat','clockedschedule'),(9,'django_celery_beat','crontabschedule'),(10,'django_celery_beat','intervalschedule'),(11,'django_celery_beat','periodictask'),(12,'django_celery_beat','periodictasks'),(13,'django_celery_beat','solarschedule'),(16,'django_celery_results','chordcounter'),(17,'django_celery_results','groupresult'),(15,'django_celery_results','taskresult'),(64,'expenses','claimapprovalflow'),(63,'expenses','claimdocument'),(66,'expenses','claimstatusmaster'),(62,'expenses','daincidentalbreakdown'),(61,'expenses','expenseclaim'),(65,'expenses','expenseitem'),(67,'expenses','expensetypemaster'),(46,'master_data','approvalmatrix'),(25,'master_data','approvalworkflowmaster'),(45,'master_data','archotelmaster'),(26,'master_data','citycategoriesmaster'),(49,'master_data','citycategoryassignment'),(36,'master_data','citymaster'),(27,'master_data','companyinformation'),(37,'master_data','conveyanceratemaster'),(28,'master_data','countrymaster'),(42,'master_data','daincidentalmaster'),(41,'master_data','departmentmaster'),(29,'master_data','designationmaster'),(30,'master_data','employeetypemaster'),(31,'master_data','glcodemaster'),(48,'master_data','gradeentitlementmaster'),(32,'master_data','grademaster'),(44,'master_data','guesthousemaster'),(39,'master_data','locationmaster'),(43,'master_data','locationspoc'),(33,'master_data','permissiontypemaster'),(38,'master_data','statemaster'),(34,'master_data','travelmodemaster'),(47,'master_data','travelpolicymaster'),(40,'master_data','travelsuboptionmaster'),(35,'master_data','vehicletypemaster'),(68,'notifications','emailtemplatemaster'),(71,'notifications','notificationevent'),(69,'notifications','notificationlog'),(70,'notifications','notificationrule'),(5,'sessions','session'),(6,'token_blacklist','blacklistedtoken'),(7,'token_blacklist','outstandingtoken'),(55,'travel','accommodationbooking'),(58,'travel','auditlog'),(50,'travel','booking'),(59,'travel','bookingassignment'),(60,'travel','bookingnote'),(57,'travel','traveladvancerequest'),(51,'travel','travelapplication'),(52,'travel','travelapprovalflow'),(53,'travel','traveldocument'),(54,'travel','tripdetails'),(56,'travel','vehiclebooking');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-12-31 05:24:25.722751'),(2,'authentication','0001_initial','2025-12-31 05:24:26.044861'),(3,'admin','0001_initial','2025-12-31 05:24:26.510512'),(4,'admin','0002_logentry_remove_auto_add','2025-12-31 05:24:26.528928'),(5,'admin','0003_logentry_add_action_flag_choices','2025-12-31 05:24:26.558635'),(6,'contenttypes','0002_remove_content_type_name','2025-12-31 05:24:26.901472'),(7,'auth','0001_initial','2025-12-31 05:24:27.613704'),(8,'auth','0002_alter_permission_name_max_length','2025-12-31 05:24:27.766596'),(9,'auth','0003_alter_user_email_max_length','2025-12-31 05:24:27.777243'),(10,'auth','0004_alter_user_username_opts','2025-12-31 05:24:27.787636'),(11,'auth','0005_alter_user_last_login_null','2025-12-31 05:24:27.803231'),(12,'auth','0006_require_contenttypes_0002','2025-12-31 05:24:27.817826'),(13,'auth','0007_alter_validators_add_error_messages','2025-12-31 05:24:27.831043'),(14,'auth','0008_alter_user_username_max_length','2025-12-31 05:24:27.844302'),(15,'auth','0009_alter_user_last_name_max_length','2025-12-31 05:24:27.855946'),(16,'auth','0010_alter_group_name_max_length','2025-12-31 05:24:27.889961'),(17,'auth','0011_update_proxy_permissions','2025-12-31 05:24:27.910825'),(18,'auth','0012_alter_user_first_name_max_length','2025-12-31 05:24:27.922459'),(19,'master_data','0001_initial','2025-12-31 05:24:37.329238'),(20,'master_data','0002_citycategoryassignment','2025-12-31 05:24:37.425470'),(21,'master_data','0003_alter_citycategoryassignment_category','2025-12-31 05:24:38.030744'),(22,'master_data','0004_alter_companyinformation_name','2025-12-31 05:24:38.095949'),(23,'master_data','0005_designationmaster_department','2025-12-31 05:24:38.400482'),(24,'master_data','0006_grademaster_glcode','2025-12-31 05:24:38.647399'),(25,'master_data','0007_alter_companyinformation_logo_and_more','2025-12-31 05:24:39.401133'),(26,'master_data','0008_alter_travelsuboptionmaster_options_and_more','2025-12-31 05:24:40.842047'),(27,'master_data','0009_alter_travelsuboptionmaster_options_and_more','2025-12-31 05:24:41.248794'),(28,'master_data','0010_employeecoderule','2025-12-31 05:24:41.301463'),(29,'master_data','0011_delete_employeecoderule','2025-12-31 05:24:41.341158'),(30,'master_data','0012_approvalmatrix_disposal_days_limit_and_more','2025-12-31 05:24:42.040556'),(31,'master_data','0013_alter_approvalmatrix_flight_above_10k_ceo','2025-12-31 05:24:42.054458'),(32,'master_data','0014_delete_emailtemplatemaster','2025-12-31 05:24:42.098107'),(33,'master_data','0015_alter_glcodemaster_description','2025-12-31 05:24:42.238944'),(34,'master_data','0016_alter_glcodemaster_description','2025-12-31 05:24:42.253947'),(35,'authentication','0002_initial','2025-12-31 05:24:44.441915'),(36,'authentication','0003_user_base_location_user_company_user_department_and_more','2025-12-31 05:24:45.791168'),(37,'authentication','0004_notificationpreference','2025-12-31 05:24:46.390455'),(38,'authentication','0005_user_gender','2025-12-31 05:24:46.707388'),(39,'authentication','0006_alter_user_gender','2025-12-31 05:24:47.217296'),(40,'authentication','0007_alter_role_dashboard_access','2025-12-31 05:24:47.232771'),(41,'authentication','0008_role_redirect_path_alter_role_dashboard_access','2025-12-31 05:24:47.468414'),(42,'authentication','0009_externalprofile_organizationalprofile_and_more','2025-12-31 05:24:51.807057'),(43,'authentication','0010_delete_notificationpreference','2025-12-31 05:24:51.850212'),(44,'authentication','0011_organizationalprofile_organizatio_employe_104b31_idx_and_more','2025-12-31 05:24:52.273038'),(45,'authentication','0012_externalprofile_service_cities','2025-12-31 05:24:52.861052'),(46,'authentication','0013_externalprofile_serves_all_cities','2025-12-31 05:24:53.136604'),(47,'authentication','0014_organizationalprofile_employee_code_user_hrms_id_and_more','2025-12-31 05:24:54.102004'),(48,'django_celery_beat','0001_initial','2025-12-31 05:24:54.750668'),(49,'django_celery_beat','0002_auto_20161118_0346','2025-12-31 05:24:54.991890'),(50,'django_celery_beat','0003_auto_20161209_0049','2025-12-31 05:24:55.079731'),(51,'django_celery_beat','0004_auto_20170221_0000','2025-12-31 05:24:55.092909'),(52,'django_celery_beat','0005_add_solarschedule_events_choices','2025-12-31 05:24:55.107984'),(53,'django_celery_beat','0006_auto_20180322_0932','2025-12-31 05:24:55.530123'),(54,'django_celery_beat','0007_auto_20180521_0826','2025-12-31 05:24:55.832284'),(55,'django_celery_beat','0008_auto_20180914_1922','2025-12-31 05:24:55.894427'),(56,'django_celery_beat','0006_auto_20180210_1226','2025-12-31 05:24:55.949594'),(57,'django_celery_beat','0006_periodictask_priority','2025-12-31 05:24:56.571188'),(58,'django_celery_beat','0009_periodictask_headers','2025-12-31 05:24:56.858790'),(59,'django_celery_beat','0010_auto_20190429_0326','2025-12-31 05:24:57.177891'),(60,'django_celery_beat','0011_auto_20190508_0153','2025-12-31 05:24:57.453679'),(61,'django_celery_beat','0012_periodictask_expire_seconds','2025-12-31 05:24:57.613441'),(62,'django_celery_beat','0013_auto_20200609_0727','2025-12-31 05:24:57.639031'),(63,'django_celery_beat','0014_remove_clockedschedule_enabled','2025-12-31 05:24:57.844697'),(64,'django_celery_beat','0015_edit_solarschedule_events_choices','2025-12-31 05:24:57.854740'),(65,'django_celery_beat','0016_alter_crontabschedule_timezone','2025-12-31 05:24:57.882952'),(66,'django_celery_beat','0017_alter_crontabschedule_month_of_year','2025-12-31 05:24:57.913617'),(67,'django_celery_beat','0018_improve_crontab_helptext','2025-12-31 05:24:57.927466'),(68,'django_celery_beat','0019_alter_periodictasks_options','2025-12-31 05:24:57.934583'),(69,'django_celery_results','0001_initial','2025-12-31 05:24:58.007770'),(70,'django_celery_results','0002_add_task_name_args_kwargs','2025-12-31 05:24:58.362814'),(71,'django_celery_results','0003_auto_20181106_1101','2025-12-31 05:24:58.370969'),(72,'django_celery_results','0004_auto_20190516_0412','2025-12-31 05:24:58.741498'),(73,'django_celery_results','0005_taskresult_worker','2025-12-31 05:24:59.010815'),(74,'django_celery_results','0006_taskresult_date_created','2025-12-31 05:24:59.453836'),(75,'django_celery_results','0007_remove_taskresult_hidden','2025-12-31 05:24:59.765413'),(76,'django_celery_results','0008_chordcounter','2025-12-31 05:24:59.907102'),(77,'django_celery_results','0009_groupresult','2025-12-31 05:25:01.190484'),(78,'django_celery_results','0010_remove_duplicate_indices','2025-12-31 05:25:01.207728'),(79,'django_celery_results','0011_taskresult_periodic_task_name','2025-12-31 05:25:01.372257'),(80,'django_celery_results','0012_taskresult_date_started','2025-12-31 05:25:01.597212'),(81,'django_celery_results','0013_taskresult_django_cele_periodi_1993cf_idx','2025-12-31 05:25:01.650269'),(82,'django_celery_results','0014_alter_taskresult_status','2025-12-31 05:25:01.663466'),(83,'travel','0001_initial','2025-12-31 05:25:11.112157'),(84,'travel','0002_booking_special_instruction_traveladvancerequest','2025-12-31 05:25:11.392121'),(85,'travel','0003_travelapprovalflow_parallel_group','2025-12-31 05:25:11.535735'),(86,'travel','0004_travelapplication_cancellation_approved_at_and_more','2025-12-31 05:25:12.187813'),(87,'travel','0005_traveldocument_parent_document_and_more','2025-12-31 05:25:13.694065'),(88,'travel','0006_alter_tripdetails_from_location_and_more','2025-12-31 05:25:15.581660'),(89,'travel','0007_alter_tripdetails_from_location_and_more','2025-12-31 05:25:17.350548'),(90,'travel','0008_alter_tripdetails_from_location_and_more','2025-12-31 05:25:18.467866'),(91,'travel','0009_alter_travelapplication_sanction_number','2025-12-31 05:25:18.633888'),(92,'travel','0010_tripdetails_end_time_and_more','2025-12-31 05:25:19.056638'),(93,'travel','0011_travelapplication_self_approved','2025-12-31 05:25:19.241542'),(94,'expenses','0001_initial','2025-12-31 05:25:21.177740'),(95,'expenses','0002_claimstatusmaster_expensetypemaster_and_more','2025-12-31 05:25:22.464140'),(96,'master_data','0017_citycategoriesmaster_display_name_and_more','2025-12-31 05:25:22.938574'),(97,'master_data','0018_remove_citycategoriesmaster_display_name_and_more','2025-12-31 05:25:23.473655'),(98,'master_data','0019_alter_citycategoriesmaster_name','2025-12-31 05:25:23.488164'),(99,'master_data','0020_alter_grademaster_sorting_no','2025-12-31 05:25:23.626908'),(100,'notifications','0001_initial','2025-12-31 05:25:24.437998'),(101,'notifications','0002_alter_emailtemplatemaster_options_and_more','2025-12-31 05:25:25.057454'),(102,'notifications','0003_load_cancellation_notification_data','2025-12-31 05:25:25.250948'),(103,'sessions','0001_initial','2025-12-31 05:25:25.336297'),(104,'token_blacklist','0001_initial','2025-12-31 05:25:25.790167'),(105,'token_blacklist','0002_outstandingtoken_jti_hex','2025-12-31 05:25:25.917957'),(106,'token_blacklist','0003_auto_20171017_2007','2025-12-31 05:25:25.999921'),(107,'token_blacklist','0004_auto_20171017_2013','2025-12-31 05:25:26.346702'),(108,'token_blacklist','0005_remove_outstandingtoken_jti','2025-12-31 05:25:26.606380'),(109,'token_blacklist','0006_auto_20171017_2113','2025-12-31 05:25:26.848561'),(110,'token_blacklist','0007_auto_20171017_2214','2025-12-31 05:25:27.423975'),(111,'token_blacklist','0008_migrate_to_bigautofield','2025-12-31 05:25:28.291933'),(112,'token_blacklist','0010_fix_migrate_to_bigautofield','2025-12-31 05:25:28.392312'),(113,'token_blacklist','0011_linearizes_history','2025-12-31 05:25:28.402178'),(114,'token_blacklist','0012_alter_outstandingtoken_user','2025-12-31 05:25:28.524301'),(115,'token_blacklist','0013_alter_blacklistedtoken_options_and_more','2025-12-31 05:25:28.614814'),(116,'travel','0012_alter_travelapprovalflow_approval_level','2025-12-31 05:25:28.684148'),(117,'travel','0013_travelapplication_booking_completed_at_and_more','2025-12-31 05:25:31.529383'),(118,'travel','0014_booking_uploaded_at_booking_uploaded_by','2025-12-31 05:25:31.860456'),(119,'travel','0013_alter_booking_estimated_cost_and_more','2025-12-31 05:25:31.945956'),(120,'travel','0015_merge_20251211_0618','2025-12-31 05:25:31.951072'),(121,'travel','0015_merge_20251208_0821','2025-12-31 05:25:31.958646'),(122,'travel','0016_merge_20251212_1004','2025-12-31 05:25:31.965296'),(123,'travel','0017_travelapplication_previous_status_and_more','2025-12-31 05:25:32.277129'),(124,'travel','0018_add_cancellation_rejection_reason','2025-12-31 05:25:32.438824'),(125,'travel','0017_alter_auditlog_action','2025-12-31 05:25:32.478786'),(126,'travel','0019_merge_20251229_1106','2025-12-31 05:25:32.483375'),(127,'travel','0020_tripdetails_no_bookings_required_and_more','2026-01-07 12:14:34.064889'),(128,'master_data','0021_alter_glcodemaster_sorting_no','2026-01-08 11:55:37.867335'),(129,'master_data','0022_glcodemaster_short_description','2026-01-08 11:55:37.963244');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('cl6xm41kg7o3ispi6h4h3q5x1y43qwkg','.eJxVjM0OwiAQhN-FsyFgWX48evcZCOwuUjU0Ke3J-O62SQ96m8z3zbxFTOtS49p5jiOJi9Di9NvlhE9uO6BHavdJ4tSWecxyV-RBu7xNxK_r4f4d1NTrtmZrkQZPwWzJWmcKaaWZEFxmZ3Ty6MFCHow7ky6MaIICBYUg2xJQfL7mpTgc:1vdN0V:gRPdiJTZeHL7rYp1rnYXNHHKQQzOFPrZ1qExeOFPoC0','2026-01-21 06:26:59.367846'),('x8y6wm3p9gx1tggscgx6zrxeybqu0171','.eJxVjM0OwiAQhN-FsyFgWX48evcZCOwuUjU0Ke3J-O62SQ96m8z3zbxFTOtS49p5jiOJi9Di9NvlhE9uO6BHavdJ4tSWecxyV-RBu7xNxK_r4f4d1NTrtmZrkQZPwWzJWmcKaaWZEFxmZ3Ty6MFCHow7ky6MaIICBYUg2xJQfL7mpTgc:1vapcn:WeZYmTF-RUPWwOApX0GzZBnFOaZOOiHjCb9tk_z8Vbo','2026-01-14 06:24:01.968832'),('z93dum7xqp8ertwx1adyp6vbr1u4zmmr','.eJxVjM0OwiAQhN-FsyFgWX48evcZCOwuUjU0Ke3J-O62SQ96m8z3zbxFTOtS49p5jiOJi9Di9NvlhE9uO6BHavdJ4tSWecxyV-RBu7xNxK_r4f4d1NTrtmZrkQZPwWzJWmcKaaWZEFxmZ3Ty6MFCHow7ky6MaIICBYUg2xJQfL7mpTgc:1vd1Nh:6xDfwQNdcr2WVIuc2FV5bK_S59BKIdYgu831deaFmAU','2026-01-20 07:21:29.860761');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_claimapprovalflow`
--

DROP TABLE IF EXISTS `expenses_claimapprovalflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses_claimapprovalflow` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `level` int unsigned NOT NULL,
  `status` varchar(50) NOT NULL,
  `remarks` longtext NOT NULL,
  `acted_on` datetime(6) DEFAULT NULL,
  `approver_id` bigint NOT NULL,
  `claim_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_claimapprovalflow_approver_id_2f1f4f8b_fk_auth_user_id` (`approver_id`),
  KEY `expenses_claimapprov_claim_id_d8e101ab_fk_expenses_` (`claim_id`),
  CONSTRAINT `expenses_claimapprov_claim_id_d8e101ab_fk_expenses_` FOREIGN KEY (`claim_id`) REFERENCES `expenses_expenseclaim` (`id`),
  CONSTRAINT `expenses_claimapprovalflow_approver_id_2f1f4f8b_fk_auth_user_id` FOREIGN KEY (`approver_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `expenses_claimapprovalflow_chk_1` CHECK ((`level` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_claimapprovalflow`
--

LOCK TABLES `expenses_claimapprovalflow` WRITE;
/*!40000 ALTER TABLE `expenses_claimapprovalflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_claimapprovalflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_claimdocument`
--

DROP TABLE IF EXISTS `expenses_claimdocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses_claimdocument` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `doc_type` varchar(50) NOT NULL,
  `file` varchar(100) NOT NULL,
  `uploaded_on` datetime(6) NOT NULL,
  `claim_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_claimdocume_claim_id_1f0f6750_fk_expenses_` (`claim_id`),
  CONSTRAINT `expenses_claimdocume_claim_id_1f0f6750_fk_expenses_` FOREIGN KEY (`claim_id`) REFERENCES `expenses_expenseclaim` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_claimdocument`
--

LOCK TABLES `expenses_claimdocument` WRITE;
/*!40000 ALTER TABLE `expenses_claimdocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_claimdocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_claimstatusmaster`
--

DROP TABLE IF EXISTS `expenses_claimstatusmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses_claimstatusmaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `label` varchar(100) NOT NULL,
  `sequence` int unsigned NOT NULL,
  `is_terminal` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  CONSTRAINT `expenses_claimstatusmaster_chk_1` CHECK ((`sequence` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_claimstatusmaster`
--

LOCK TABLES `expenses_claimstatusmaster` WRITE;
/*!40000 ALTER TABLE `expenses_claimstatusmaster` DISABLE KEYS */;
INSERT INTO `expenses_claimstatusmaster` VALUES (1,'draft','Draft',1,0),(2,'submitted','Submitted',2,0),(3,'manager_pending','Manager Pending',3,0),(6,'approved','Approved',4,1),(7,'rejected','Rejected',5,1),(8,'paid','Paid',6,1),(9,'closed','Closed',7,1);
/*!40000 ALTER TABLE `expenses_claimstatusmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_daincidentalbreakdown`
--

DROP TABLE IF EXISTS `expenses_daincidentalbreakdown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses_daincidentalbreakdown` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `eligible_da` decimal(7,2) NOT NULL,
  `eligible_incidental` decimal(7,2) NOT NULL,
  `hours` decimal(5,2) NOT NULL,
  `remarks` longtext NOT NULL,
  `claim_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_daincidenta_claim_id_b8a21e7c_fk_expenses_` (`claim_id`),
  CONSTRAINT `expenses_daincidenta_claim_id_b8a21e7c_fk_expenses_` FOREIGN KEY (`claim_id`) REFERENCES `expenses_expenseclaim` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_daincidentalbreakdown`
--

LOCK TABLES `expenses_daincidentalbreakdown` WRITE;
/*!40000 ALTER TABLE `expenses_daincidentalbreakdown` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_daincidentalbreakdown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_expenseclaim`
--

DROP TABLE IF EXISTS `expenses_expenseclaim`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses_expenseclaim` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `submitted_on` datetime(6) DEFAULT NULL,
  `status_id` bigint DEFAULT NULL,
  `total_da` decimal(10,2) NOT NULL,
  `total_incidental` decimal(10,2) NOT NULL,
  `total_expenses` decimal(10,2) NOT NULL,
  `advance_received` decimal(10,2) NOT NULL,
  `final_amount_payable` decimal(10,2) NOT NULL,
  `is_late_submission` tinyint(1) NOT NULL,
  `late_submission_reason` longtext NOT NULL,
  `exceptions` json NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `updated_on` datetime(6) NOT NULL,
  `employee_id` bigint NOT NULL,
  `travel_application_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `travel_application_id` (`travel_application_id`),
  KEY `expenses_expenseclaim_employee_id_7acbed91_fk_auth_user_id` (`employee_id`),
  KEY `expenses_expenseclaim_status_id_dda4af64` (`status_id`),
  CONSTRAINT `expenses_expenseclai_status_id_dda4af64_fk_expenses_` FOREIGN KEY (`status_id`) REFERENCES `expenses_claimstatusmaster` (`id`),
  CONSTRAINT `expenses_expenseclai_travel_application_i_55d61201_fk_travel_tr` FOREIGN KEY (`travel_application_id`) REFERENCES `travel_travelapplication` (`id`),
  CONSTRAINT `expenses_expenseclaim_employee_id_7acbed91_fk_auth_user_id` FOREIGN KEY (`employee_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_expenseclaim`
--

LOCK TABLES `expenses_expenseclaim` WRITE;
/*!40000 ALTER TABLE `expenses_expenseclaim` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_expenseclaim` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_expenseitem`
--

DROP TABLE IF EXISTS `expenses_expenseitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses_expenseitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `expense_type_id` bigint NOT NULL,
  `expense_date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `receipt_file` varchar(100) DEFAULT NULL,
  `has_receipt` tinyint(1) NOT NULL,
  `is_self_certified` tinyint(1) NOT NULL,
  `self_certified_reason` longtext NOT NULL,
  `distance_km` decimal(7,2) DEFAULT NULL,
  `vendor_name` varchar(255) NOT NULL,
  `bill_number` varchar(100) NOT NULL,
  `city_category` varchar(10) NOT NULL,
  `remarks` longtext NOT NULL,
  `created_on` datetime(6) NOT NULL,
  `claim_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_expenseitem_claim_id_5aed9929_fk_expenses_` (`claim_id`),
  KEY `expenses_expenseitem_expense_type_id_3ab47002` (`expense_type_id`),
  CONSTRAINT `expenses_expenseitem_claim_id_5aed9929_fk_expenses_` FOREIGN KEY (`claim_id`) REFERENCES `expenses_expenseclaim` (`id`),
  CONSTRAINT `expenses_expenseitem_expense_type_id_3ab47002_fk_expenses_` FOREIGN KEY (`expense_type_id`) REFERENCES `expenses_expensetypemaster` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_expenseitem`
--

LOCK TABLES `expenses_expenseitem` WRITE;
/*!40000 ALTER TABLE `expenses_expenseitem` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses_expenseitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_expensetypemaster`
--

DROP TABLE IF EXISTS `expenses_expensetypemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses_expensetypemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `requires_receipt` tinyint(1) NOT NULL,
  `is_distance_based` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_expensetypemaster`
--

LOCK TABLES `expenses_expensetypemaster` WRITE;
/*!40000 ALTER TABLE `expenses_expensetypemaster` DISABLE KEYS */;
INSERT INTO `expenses_expensetypemaster` VALUES (1,'auto','Auto / Local Travel',1,0,1),(2,'bus','Bus',1,0,1),(3,'flight','Flight',1,0,1),(4,'train','Train',1,0,1),(5,'food','Food/Meal',1,0,1),(6,'fuel','Fuel',1,0,1),(7,'stay','Hotel/Guest House/etc.',1,0,1),(8,'misc','Miscellaneous',1,0,1),(9,'parking','Parking',1,0,1),(10,'personal_car','Personal Car',1,1,1),(11,'taxi','Taxi',1,0,1),(12,'toll','Toll',1,0,1);
/*!40000 ALTER TABLE `expenses_expensetypemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_profiles`
--

DROP TABLE IF EXISTS `external_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_profiles` (
  `user_id` bigint NOT NULL,
  `profile_type` varchar(50) NOT NULL,
  `organization_name` varchar(200) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(254) NOT NULL,
  `address` longtext NOT NULL,
  `service_categories` json NOT NULL,
  `gst_number` varchar(15) NOT NULL,
  `pan_number` varchar(10) NOT NULL,
  `license_number` varchar(50) NOT NULL,
  `is_verified` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `serves_all_cities` tinyint(1) NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `external_profiles_user_id_7fb9aec0_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_profiles`
--

LOCK TABLES `external_profiles` WRITE;
/*!40000 ALTER TABLE `external_profiles` DISABLE KEYS */;
INSERT INTO `external_profiles` VALUES (11,'booking_agent','Eastern Travel','Bibhuti B Dash','7077339639','bibhuti.bdash@easterntravels.co.in','','[\"flight_booking\"]','','','',1,1,'2026-01-08 09:48:32.169116','2026-01-08 09:48:32.169149',1);
/*!40000 ALTER TABLE `external_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_profiles_service_cities`
--

DROP TABLE IF EXISTS `external_profiles_service_cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_profiles_service_cities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `externalprofile_id` bigint NOT NULL,
  `citymaster_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `external_profiles_servic_externalprofile_id_citym_fb68f059_uniq` (`externalprofile_id`,`citymaster_id`),
  KEY `external_profiles_se_citymaster_id_0137610c_fk_master_da` (`citymaster_id`),
  CONSTRAINT `external_profiles_se_citymaster_id_0137610c_fk_master_da` FOREIGN KEY (`citymaster_id`) REFERENCES `master_data_citymaster` (`id`),
  CONSTRAINT `external_profiles_se_externalprofile_id_5ad8cbd2_fk_external_` FOREIGN KEY (`externalprofile_id`) REFERENCES `external_profiles` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_profiles_service_cities`
--

LOCK TABLES `external_profiles_service_cities` WRITE;
/*!40000 ALTER TABLE `external_profiles_service_cities` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_profiles_service_cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_approvalmatrix`
--

DROP TABLE IF EXISTS `master_data_approvalmatrix`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_approvalmatrix` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `min_amount` decimal(10,2) NOT NULL,
  `max_amount` decimal(10,2) DEFAULT NULL,
  `requires_manager` tinyint(1) NOT NULL,
  `requires_chro` tinyint(1) NOT NULL,
  `requires_ceo` tinyint(1) NOT NULL,
  `flight_above_10k_ceo` tinyint(1) NOT NULL,
  `manager_can_view` tinyint(1) NOT NULL,
  `manager_can_approve` tinyint(1) NOT NULL,
  `advance_booking_required_days` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `employee_grade_id` bigint NOT NULL,
  `travel_mode_id` bigint NOT NULL,
  `disposal_days_limit` int DEFAULT NULL,
  `distance_limit_km` decimal(8,2) DEFAULT NULL,
  `requires_chro_for_disposal` tinyint(1) NOT NULL,
  `requires_chro_for_distance` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_approvalmatr_travel_mode_id_employee__10fd0fcd_uniq` (`travel_mode_id`,`employee_grade_id`,`min_amount`),
  KEY `master_data_approval_employee_grade_id_9db5dffd_fk_master_da` (`employee_grade_id`),
  KEY `master_data_travel__f9b015_idx` (`travel_mode_id`,`employee_grade_id`),
  KEY `master_data_min_amo_3abb78_idx` (`min_amount`,`max_amount`),
  CONSTRAINT `master_data_approval_employee_grade_id_9db5dffd_fk_master_da` FOREIGN KEY (`employee_grade_id`) REFERENCES `master_data_grademaster` (`id`),
  CONSTRAINT `master_data_approval_travel_mode_id_ac3bf344_fk_master_da` FOREIGN KEY (`travel_mode_id`) REFERENCES `master_data_travelmodemaster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_approvalmatrix`
--

LOCK TABLES `master_data_approvalmatrix` WRITE;
/*!40000 ALTER TABLE `master_data_approvalmatrix` DISABLE KEYS */;
INSERT INTO `master_data_approvalmatrix` VALUES (36,0.00,NULL,0,0,0,0,1,0,7,1,'2025-12-31 09:09:26.657008','2025-12-31 09:09:26.657096',1,1,NULL,NULL,0,0),(37,0.00,NULL,0,0,0,0,1,0,7,1,'2025-12-31 09:09:26.663349','2025-12-31 09:09:26.663381',2,1,NULL,NULL,0,0),(38,0.00,NULL,1,0,0,0,1,1,7,1,'2025-12-31 09:09:26.669180','2025-12-31 09:09:26.669212',3,1,NULL,NULL,0,0),(39,0.00,NULL,1,0,0,0,1,1,7,1,'2025-12-31 09:09:26.676738','2025-12-31 09:09:26.676773',4,1,NULL,NULL,0,0),(40,0.00,NULL,1,0,0,0,1,1,7,1,'2025-12-31 09:09:26.689923','2025-12-31 09:09:26.689953',5,1,NULL,NULL,0,0),(41,10000.00,NULL,0,1,0,1,1,1,0,1,'2025-12-31 09:09:26.700764','2025-12-31 09:09:26.700793',1,1,NULL,NULL,0,0),(42,10000.00,NULL,0,1,0,1,1,1,0,1,'2025-12-31 09:09:26.706185','2025-12-31 09:09:26.706214',2,1,NULL,NULL,0,0),(43,10000.00,NULL,0,1,0,1,1,1,0,1,'2025-12-31 09:09:26.713319','2025-12-31 09:09:26.713349',3,1,NULL,NULL,0,0),(44,10000.00,NULL,0,1,0,1,1,1,0,1,'2025-12-31 09:09:26.725904','2025-12-31 09:09:26.725955',4,1,NULL,NULL,0,0),(45,10000.00,NULL,0,1,0,1,1,1,0,1,'2025-12-31 09:09:26.733345','2025-12-31 09:09:26.733374',5,1,NULL,NULL,0,0),(46,0.00,NULL,0,0,0,0,1,1,3,1,'2025-12-31 09:09:26.740220','2025-12-31 09:09:26.740249',1,2,NULL,NULL,0,0),(47,0.00,NULL,0,0,0,0,1,1,3,1,'2025-12-31 09:09:26.760362','2025-12-31 09:09:26.760390',2,2,NULL,NULL,0,0),(48,0.00,NULL,0,0,0,0,1,1,3,1,'2025-12-31 09:09:26.768580','2025-12-31 09:09:26.768611',3,2,NULL,NULL,0,0),(49,0.00,NULL,1,0,0,0,1,1,3,1,'2025-12-31 09:09:26.775347','2025-12-31 09:09:26.775378',4,2,NULL,NULL,0,0),(50,0.00,NULL,1,0,0,0,1,1,3,1,'2025-12-31 09:09:26.791580','2025-12-31 09:09:26.791611',5,2,NULL,NULL,0,0),(51,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.798551','2025-12-31 09:09:26.798586',1,3,NULL,NULL,0,0),(52,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.807081','2025-12-31 09:09:26.807111',2,3,NULL,NULL,0,0),(53,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.821505','2025-12-31 09:09:26.821534',3,3,NULL,NULL,0,0),(54,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.829363','2025-12-31 09:09:26.829418',4,3,NULL,NULL,0,0),(55,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.836817','2025-12-31 09:09:26.836847',5,3,NULL,NULL,0,0),(56,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.849539','2025-12-31 09:09:26.849568',1,4,NULL,NULL,0,0),(57,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.859330','2025-12-31 09:09:26.859359',2,4,NULL,NULL,0,0),(58,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.866321','2025-12-31 09:09:26.866350',3,4,NULL,NULL,0,0),(59,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.879366','2025-12-31 09:09:26.879425',4,4,NULL,NULL,0,0),(60,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.889104','2025-12-31 09:09:26.889133',5,4,NULL,NULL,0,0),(61,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.897210','2025-12-31 09:09:26.897242',1,5,5,NULL,1,0),(62,0.00,NULL,0,0,0,0,1,1,0,1,'2025-12-31 09:09:26.908665','2025-12-31 09:09:26.908710',2,5,5,NULL,1,0),(63,0.00,NULL,1,0,0,0,1,1,0,1,'2025-12-31 09:09:26.916508','2025-12-31 09:09:26.916537',3,5,5,NULL,1,0),(64,0.00,NULL,1,0,0,0,1,1,0,1,'2025-12-31 09:09:26.922664','2025-12-31 09:09:26.922694',4,5,5,NULL,1,0),(65,0.00,NULL,1,0,0,0,1,1,0,1,'2025-12-31 09:09:26.927890','2025-12-31 09:09:26.927919',5,5,5,NULL,1,0),(66,0.00,NULL,1,0,0,0,1,1,0,1,'2025-12-31 09:09:26.938733','2025-12-31 09:09:26.938768',1,6,NULL,150.00,0,1),(67,0.00,NULL,1,0,0,0,1,1,0,1,'2025-12-31 09:09:26.946757','2025-12-31 09:09:26.946786',2,6,NULL,150.00,0,1),(68,0.00,NULL,1,0,0,0,1,1,0,1,'2025-12-31 09:09:26.953254','2025-12-31 09:09:26.953286',3,6,NULL,150.00,0,1),(69,0.00,NULL,1,0,0,0,1,1,0,1,'2025-12-31 09:09:26.958852','2025-12-31 09:09:26.958883',4,6,NULL,150.00,0,1),(70,0.00,NULL,1,0,0,0,1,1,0,1,'2025-12-31 09:09:26.964957','2025-12-31 09:09:26.964988',5,6,NULL,150.00,0,1);
/*!40000 ALTER TABLE `master_data_approvalmatrix` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_approvalworkflowmaster`
--

DROP TABLE IF EXISTS `master_data_approvalworkflowmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_approvalworkflowmaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `module` varchar(50) NOT NULL,
  `is_enabled` tinyint(1) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_approvalworkflowmaster`
--

LOCK TABLES `master_data_approvalworkflowmaster` WRITE;
/*!40000 ALTER TABLE `master_data_approvalworkflowmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_approvalworkflowmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_archotelmaster`
--

DROP TABLE IF EXISTS `master_data_archotelmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_archotelmaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `hotel_type` varchar(20) DEFAULT NULL,
  `star_rating` int unsigned DEFAULT NULL,
  `group_name` varchar(100) NOT NULL,
  `gstin` varchar(15) DEFAULT NULL,
  `pan` varchar(10) DEFAULT NULL,
  `operating_since` int unsigned DEFAULT NULL,
  `address` longtext NOT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `phone_number` varchar(15) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `website` varchar(200) NOT NULL,
  `social_media` json NOT NULL,
  `total_rooms` int unsigned DEFAULT NULL,
  `room_types` json NOT NULL,
  `check_in_time` time(6) DEFAULT NULL,
  `check_out_time` time(6) DEFAULT NULL,
  `facilities` json NOT NULL,
  `rate_per_night` decimal(8,2) NOT NULL,
  `tax_percentage` decimal(5,2) NOT NULL,
  `contract_start_date` date NOT NULL,
  `contract_end_date` date NOT NULL,
  `category` varchar(20) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `city_id` bigint DEFAULT NULL,
  `country_id` bigint DEFAULT NULL,
  `state_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_data_archotel_created_by_id_5bfe4596_fk_authentic` (`created_by_id`),
  KEY `master_data_archotel_updated_by_id_0b15cf4c_fk_authentic` (`updated_by_id`),
  KEY `master_data_archotel_country_id_154ff1ed_fk_master_da` (`country_id`),
  KEY `master_data_archotel_state_id_1ed854bc_fk_master_da` (`state_id`),
  KEY `master_data_city_id_7e9b65_idx` (`city_id`,`category`,`is_active`),
  KEY `master_data_contrac_c2140c_idx` (`contract_start_date`,`contract_end_date`),
  KEY `master_data_star_ra_6a33a3_idx` (`star_rating`,`hotel_type`),
  CONSTRAINT `master_data_archotel_city_id_47e4d6bd_fk_master_da` FOREIGN KEY (`city_id`) REFERENCES `master_data_citymaster` (`id`),
  CONSTRAINT `master_data_archotel_country_id_154ff1ed_fk_master_da` FOREIGN KEY (`country_id`) REFERENCES `master_data_countrymaster` (`id`),
  CONSTRAINT `master_data_archotel_created_by_id_5bfe4596_fk_authentic` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `master_data_archotel_state_id_1ed854bc_fk_master_da` FOREIGN KEY (`state_id`) REFERENCES `master_data_statemaster` (`id`),
  CONSTRAINT `master_data_archotel_updated_by_id_0b15cf4c_fk_authentic` FOREIGN KEY (`updated_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `master_data_archotelmaster_chk_1` CHECK ((`star_rating` >= 0)),
  CONSTRAINT `master_data_archotelmaster_chk_2` CHECK ((`operating_since` >= 0)),
  CONSTRAINT `master_data_archotelmaster_chk_3` CHECK ((`total_rooms` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_archotelmaster`
--

LOCK TABLES `master_data_archotelmaster` WRITE;
/*!40000 ALTER TABLE `master_data_archotelmaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_archotelmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_citycategoriesmaster`
--

DROP TABLE IF EXISTS `master_data_citycategoriesmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_citycategoriesmaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(1) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_citycategoriesmaster`
--

LOCK TABLES `master_data_citycategoriesmaster` WRITE;
/*!40000 ALTER TABLE `master_data_citycategoriesmaster` DISABLE KEYS */;
INSERT INTO `master_data_citycategoriesmaster` VALUES (1,'A','Category A – NCR, State Capitals, Major Cities'),(2,'B','Category B – Other cities not in Category A'),(3,'C','Category C – Revenue villages ≥ 5 km from nearest city');
/*!40000 ALTER TABLE `master_data_citycategoriesmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_citycategoryassignment`
--

DROP TABLE IF EXISTS `master_data_citycategoryassignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_citycategoryassignment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `country_name` varchar(100) NOT NULL,
  `country_code` varchar(10) DEFAULT NULL,
  `state_name` varchar(100) NOT NULL,
  `state_code` varchar(10) DEFAULT NULL,
  `city_name` varchar(100) NOT NULL,
  `category_id` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_citycategory_country_name_state_name__1984fff3_uniq` (`country_name`,`state_name`,`city_name`),
  KEY `master_data_citycategoryassignment_category_id_188cbf79` (`category_id`),
  CONSTRAINT `master_data_citycate_category_id_188cbf79_fk_master_da` FOREIGN KEY (`category_id`) REFERENCES `master_data_citycategoriesmaster` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_citycategoryassignment`
--

LOCK TABLES `master_data_citycategoryassignment` WRITE;
/*!40000 ALTER TABLE `master_data_citycategoryassignment` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_citycategoryassignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_citymaster`
--

DROP TABLE IF EXISTS `master_data_citymaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_citymaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `city_name` varchar(100) NOT NULL,
  `city_code` varchar(10) NOT NULL,
  `category_id` bigint NOT NULL,
  `state_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_citymaster_city_name_state_id_9a4dd010_uniq` (`city_name`,`state_id`),
  KEY `master_data_citymast_state_id_721c4e88_fk_master_da` (`state_id`),
  KEY `master_data_citymast_category_id_68432070_fk_master_da` (`category_id`),
  CONSTRAINT `master_data_citymast_category_id_68432070_fk_master_da` FOREIGN KEY (`category_id`) REFERENCES `master_data_citycategoriesmaster` (`id`),
  CONSTRAINT `master_data_citymast_state_id_721c4e88_fk_master_da` FOREIGN KEY (`state_id`) REFERENCES `master_data_statemaster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3774 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_citymaster`
--

LOCK TABLES `master_data_citymaster` WRITE;
/*!40000 ALTER TABLE `master_data_citymaster` DISABLE KEYS */;
INSERT INTO `master_data_citymaster` VALUES (23,'Bamboo Flat','',2,4),(24,'Nicobar','',2,4),(25,'Port Blair','',2,4),(26,'South Andaman','',2,4),(27,'Addanki','',2,5),(28,'Adoni','',2,5),(29,'Akasahebpet','',2,5),(30,'Akividu','',2,5),(31,'Akkarampalle','',2,5),(32,'Amalapuram','',2,5),(33,'Amudalavalasa','',2,5),(34,'Anakapalle','',2,5),(35,'Anantapur','',2,5),(36,'Atmakur','',2,5),(37,'Attili','',2,5),(38,'Avanigadda','',2,5),(39,'Badvel','',2,5),(40,'Banganapalle','',2,5),(41,'Bapatla','',2,5),(42,'Betamcherla','',2,5),(43,'Bhattiprolu','',2,5),(44,'Bhimavaram','',2,5),(45,'Bhimunipatnam','',2,5),(46,'Bobbili','',2,5),(47,'Challapalle','',2,5),(48,'Chemmumiahpet','',2,5),(49,'Chilakalurupet','',2,5),(50,'Chinnachowk','',2,5),(51,'Chipurupalle','',2,5),(52,'Chirala','',2,5),(53,'Chittoor','',2,5),(54,'Chodavaram','',2,5),(55,'Cuddapah','',2,5),(56,'Cumbum','',2,5),(57,'Darsi','',2,5),(58,'Dharmavaram','',2,5),(59,'Dhone','',2,5),(60,'Diguvametta','',2,5),(61,'East Godavari','',2,5),(62,'Elamanchili','',2,5),(63,'Ellore','',2,5),(64,'Emmiganur','',2,5),(65,'Erraguntla','',2,5),(66,'Etikoppaka','',2,5),(67,'Gajuwaka','',2,5),(68,'Ganguvada','',2,5),(69,'Gannavaram','',2,5),(70,'Giddalur','',2,5),(71,'Gokavaram','',2,5),(72,'Gorantla','',2,5),(73,'Govindapuram,Chilakaluripet,Guntur','',2,5),(74,'Gudivada','',2,5),(75,'Gudlavalleru','',2,5),(76,'Gudur','',2,5),(77,'Guntakal Junction','',2,5),(78,'Guntur','',1,5),(79,'Hindupur','',2,5),(80,'Ichchapuram','',2,5),(81,'Jaggayyapeta','',2,5),(82,'Jammalamadugu','',2,5),(83,'Kadiri','',2,5),(84,'Kaikalur','',2,5),(85,'Kakinada','',2,5),(86,'Kalyandurg','',2,5),(87,'Kamalapuram','',2,5),(88,'Kandukur','',2,5),(89,'Kanigiri','',2,5),(90,'Kankipadu','',2,5),(91,'Kanuru','',2,5),(92,'Kavali','',2,5),(93,'Kolanukonda','',2,5),(94,'Kondapalle','',2,5),(95,'Korukollu','',2,5),(96,'Kosigi','',2,5),(97,'Kovur','',2,5),(98,'Kovvur','',2,5),(99,'Krishna','',2,5),(100,'Kuppam','',2,5),(101,'Kurnool','',2,5),(102,'Macherla','',2,5),(103,'Machilipatnam','',2,5),(104,'Madanapalle','',2,5),(105,'Madugula','',2,5),(106,'Mandapeta','',2,5),(107,'Mandasa','',2,5),(108,'Mangalagiri','',2,5),(109,'Markapur','',2,5),(110,'Nagari','',2,5),(111,'Nagireddipalli','',2,5),(112,'Nandigama','',2,5),(113,'Nandikotkur','',2,5),(114,'Nandyal','',2,5),(115,'Narasannapeta','',2,5),(116,'Narasapur','',2,5),(117,'Narasaraopet','',2,5),(118,'Narasingapuram','',2,5),(119,'Narayanavanam','',2,5),(120,'Narsipatnam','',2,5),(121,'Nayudupet','',2,5),(122,'Nellore','',2,5),(123,'Nidadavole','',2,5),(124,'Nuzvid','',2,5),(125,'Ongole','',2,5),(126,'Pakala','',2,5),(127,'Palakollu','',2,5),(128,'Palasa','',2,5),(129,'Palkonda','',2,5),(130,'Pallevada','',2,5),(131,'Palmaner','',2,5),(132,'Parlakimidi','',2,5),(133,'Parvatipuram','',2,5),(134,'Pavuluru','',2,5),(135,'Pedana','',2,5),(136,'pedda nakkalapalem','',2,5),(137,'Peddapuram','',2,5),(138,'Penugonda','',2,5),(139,'Penukonda','',2,5),(140,'Phirangipuram','',2,5),(141,'Pippara','',2,5),(142,'Pithapuram','',2,5),(143,'Polavaram','',2,5),(144,'Ponnur','',2,5),(145,'Ponnuru','',2,5),(146,'Prakasam','',2,5),(147,'Proddatur','',2,5),(148,'Pulivendla','',2,5),(149,'Punganuru','',2,5),(150,'Puttaparthi','',2,5),(151,'Puttur','',2,5),(152,'Rajahmundry','',2,5),(153,'Ramachandrapuram','',2,5),(154,'Ramanayyapeta','',2,5),(155,'Ramapuram','',2,5),(156,'Rampachodavaram','',2,5),(157,'Rayachoti','',2,5),(158,'Rayadrug','',2,5),(159,'Razam','',2,5),(160,'Razampeta','',2,5),(161,'Razole','',2,5),(162,'Renigunta','',2,5),(163,'Repalle','',2,5),(164,'Salur','',2,5),(165,'Samalkot','',2,5),(166,'Sattenapalle','',2,5),(167,'Singarayakonda','',2,5),(168,'Sompeta','',2,5),(169,'Srikakulam','',2,5),(170,'Srisailain','',2,5),(171,'Suluru','',2,5),(172,'Tadepalle','',2,5),(173,'Tadepallegudem','',2,5),(174,'Tadpatri','',2,5),(175,'Tanuku','',2,5),(176,'Tekkali','',2,5),(177,'Tirumala','',2,5),(178,'Tirupati','',2,5),(179,'Tuni','',2,5),(180,'Uravakonda','',2,5),(181,'vadlamuru','',2,5),(182,'Vadlapudi','',2,5),(183,'Venkatagiri','',2,5),(184,'Vepagunta','',2,5),(185,'Vetapalem','',2,5),(186,'Vijayawada','',1,5),(187,'Vinukonda','',2,5),(188,'Visakhapatnam','',1,5),(189,'Vishakhapatnam','',2,5),(190,'Vizianagaram','',2,5),(191,'Vizianagaram District','',2,5),(192,'Vuyyuru','',2,5),(193,'West Godavari','',2,5),(194,'Yanam','',2,5),(195,'Yanamalakuduru','',2,5),(196,'Yarada','',2,5),(197,'Along','',2,6),(198,'Anjaw','',2,6),(199,'Basar','',2,6),(200,'Bomdila','',2,6),(201,'Changlang','',2,6),(202,'Dibang Valley','',2,6),(203,'East Kameng','',2,6),(204,'East Siang','',2,6),(205,'Hayuliang','',2,6),(206,'Itanagar','',2,6),(207,'Khonsa','',2,6),(208,'Kurung Kumey','',2,6),(209,'Lohit District','',2,6),(210,'Lower Dibang Valley','',2,6),(211,'Lower Subansiri','',2,6),(212,'Margherita','',2,6),(213,'Naharlagun','',2,6),(214,'Pasighat','',2,6),(215,'Tawang','',2,6),(216,'Tezu','',2,6),(217,'Tirap','',2,6),(218,'Upper Siang','',2,6),(219,'Upper Subansiri','',2,6),(220,'West Kameng','',2,6),(221,'West Siang','',2,6),(222,'Ziro','',2,6),(223,'Abhayapuri','',2,7),(224,'Amguri','',2,7),(225,'Badarpur','',2,7),(226,'Baksa','',2,7),(227,'Barpathar','',2,7),(228,'Barpeta','',2,7),(229,'Barpeta Road','',2,7),(230,'Basugaon','',2,7),(231,'Bihpuriagaon','',2,7),(232,'Bijni','',2,7),(233,'Bilasipara','',2,7),(234,'Bokajan','',2,7),(235,'Bokakhat','',2,7),(236,'Bongaigaon','',2,7),(237,'Cachar','',2,7),(238,'Chabua','',2,7),(239,'Chapar','',2,7),(240,'Chirang','',2,7),(241,'Darrang','',2,7),(242,'Dergaon','',2,7),(243,'Dhekiajuli','',2,7),(244,'Dhemaji','',2,7),(245,'Dhing','',2,7),(246,'Dhubri','',2,7),(247,'Dhuburi','',2,7),(248,'Dibrugarh','',2,7),(249,'Digboi','',2,7),(250,'Dima Hasao District','',2,7),(251,'Diphu','',2,7),(252,'Dispur','',2,7),(253,'Duliagaon','',2,7),(254,'Dum Duma','',2,7),(255,'Gauripur','',2,7),(256,'Goalpara','',2,7),(257,'Gohpur','',2,7),(258,'Golaghat','',2,7),(259,'Golakganj','',2,7),(260,'Goshaingaon','',2,7),(261,'Guwahati','',2,7),(262,'Haflong','',2,7),(263,'Hailakandi','',2,7),(264,'Hajo','',2,7),(265,'Hojai','',2,7),(266,'Howli','',2,7),(267,'Jogighopa','',2,7),(268,'Jorhat','',2,7),(269,'Kamrup','',2,7),(270,'Kamrup Metropolitan','',2,7),(271,'Karbi Anglong','',2,7),(272,'Karimganj','',2,7),(273,'Kharupatia','',2,7),(274,'Kokrajhar','',2,7),(275,'Lakhimpur','',2,7),(276,'Lakhipur','',2,7),(277,'Lala','',2,7),(278,'Lumding Railway Colony','',2,7),(279,'Mahur','',2,7),(280,'Maibong','',2,7),(281,'Makum','',2,7),(282,'Mangaldai','',2,7),(283,'Mariani','',2,7),(284,'Moranha','',2,7),(285,'Morigaon','',2,7),(286,'Nagaon','',2,7),(287,'Nahorkatiya','',2,7),(288,'Nalbari','',2,7),(289,'Namrup','',2,7),(290,'Nazira','',2,7),(291,'North Guwahati','',2,7),(292,'North Lakhimpur','',2,7),(293,'Numaligarh','',2,7),(294,'Palasbari','',2,7),(295,'Raha','',2,7),(296,'Rangapara','',2,7),(297,'Rangia','',2,7),(298,'Sapatgram','',2,7),(299,'Sarupathar','',2,7),(300,'Sibsagar','',2,7),(301,'Silapathar','',2,7),(302,'Silchar','',2,7),(303,'Soalkuchi','',2,7),(304,'Sonari','',2,7),(305,'Sonitpur','',2,7),(306,'Sorbhog','',2,7),(307,'Tezpur','',2,7),(308,'Tinsukia','',1,7),(309,'Titabar','',2,7),(310,'Udalguri','',2,7),(311,'Amarpur','',2,8),(312,'Araria','',2,8),(313,'Arrah','',2,8),(314,'Arwal','',2,8),(315,'Asarganj','',2,8),(316,'Aurangabad','',2,8),(317,'Bagaha','',2,8),(318,'Bahadurganj','',2,8),(319,'Bairagnia','',2,8),(320,'Baisi','',2,8),(321,'Bakhtiyarpur','',2,8),(322,'Bangaon','',2,8),(323,'Banka','',2,8),(324,'Banmankhi','',2,8),(325,'Bar Bigha','',2,8),(326,'Barauli','',2,8),(327,'Barh','',2,8),(328,'Barhiya','',2,8),(329,'Bariarpur','',2,8),(330,'Baruni','',2,8),(331,'Begusarai','',2,8),(332,'Belsand','',2,8),(333,'Bettiah','',2,8),(334,'Bhabhua','',2,8),(335,'Bhagalpur','',2,8),(336,'Bhagirathpur','',2,8),(337,'Bhawanipur','',2,8),(338,'Bhojpur','',2,8),(339,'Bihar Sharif','',2,8),(340,'Bihariganj','',2,8),(341,'Bikramganj','',2,8),(342,'Birpur','',2,8),(343,'Buddh Gaya','',2,8),(344,'Buxar','',2,8),(345,'Chakia','',2,8),(346,'Chapra','',2,8),(347,'Chhatapur','',2,8),(348,'Colgong','',2,8),(349,'Dalsingh Sarai','',2,8),(350,'Darbhanga','',2,8),(351,'Daudnagar','',2,8),(352,'Dehri','',2,8),(353,'Dhaka','',2,8),(354,'Dighwara','',2,8),(355,'Dinapore','',2,8),(356,'Dumra','',2,8),(357,'Dumraon','',2,8),(358,'Fatwa','',2,8),(359,'Forbesganj','',2,8),(360,'Gaya','',2,8),(361,'Ghoga','',2,8),(362,'Gopalganj','',2,8),(363,'Hajipur','',2,8),(364,'Hilsa','',2,8),(365,'Hisua','',2,8),(366,'Islampur','',2,8),(367,'Jagdispur','',2,8),(368,'Jahanabad','',2,8),(369,'Jamalpur','',2,8),(370,'Jamui','',2,8),(371,'Jaynagar','',2,8),(372,'Jehanabad','',2,8),(373,'Jha-Jha','',2,8),(374,'Jhanjharpur','',2,8),(375,'Jogbani','',2,8),(376,'Kaimur District','',2,8),(377,'Kasba','',2,8),(378,'Katihar','',2,8),(379,'Khagaria','',2,8),(380,'Khagaul','',2,8),(381,'Kharagpur','',2,8),(382,'Khusropur','',2,8),(383,'Kishanganj','',2,8),(384,'Koath','',2,8),(385,'Koelwar','',2,8),(386,'Lakhisarai','',2,8),(387,'Lalganj','',2,8),(388,'Luckeesarai','',2,8),(389,'Madhepura','',2,8),(390,'Madhipura','',2,8),(391,'Madhubani','',2,8),(392,'Maharajgani','',2,8),(393,'Mairwa','',2,8),(394,'Maner','',2,8),(395,'Manihari','',2,8),(396,'Marhaura','',2,8),(397,'Masaurhi Buzurg','',2,8),(398,'Mohiuddinnagar','',2,8),(399,'Mokameh','',2,8),(400,'Monghyr','',2,8),(401,'Mothihari','',2,8),(402,'Munger','',2,8),(403,'Murliganj','',2,8),(404,'Muzaffarpur','',2,8),(405,'Nabinagar','',2,8),(406,'Nalanda','',2,8),(407,'Nasriganj','',2,8),(408,'Naugachhia','',2,8),(409,'Nawada','',2,8),(410,'Nirmali','',2,8),(411,'Pashchim Champaran','',2,8),(412,'Patna','',2,8),(413,'Piro','',2,8),(414,'Pupri','',2,8),(415,'Purba Champaran','',2,8),(416,'Purnia','',2,8),(417,'Rafiganj','',2,8),(418,'Raghunathpur','',2,8),(419,'Rajgir','',2,8),(420,'Ramnagar','',2,8),(421,'Raxaul','',2,8),(422,'Revelganj','',2,8),(423,'Rohtas','',2,8),(424,'Rusera','',2,8),(425,'Sagauli','',2,8),(426,'Saharsa','',2,8),(427,'Samastipur','',2,8),(428,'Saran','',2,8),(429,'Shahbazpur','',2,8),(430,'Shahpur','',2,8),(431,'Sheikhpura','',2,8),(432,'Sheohar','',2,8),(433,'Sherghati','',2,8),(434,'Silao','',2,8),(435,'Sitamarhi','',2,8),(436,'Siwan','',2,8),(437,'Supaul','',2,8),(438,'Teghra','',2,8),(439,'Tekari','',2,8),(440,'Thakurganj','',2,8),(441,'Vaishali','',2,8),(442,'Waris Aliganj','',2,8),(443,'Chandigarh','',2,9),(444,'Akaltara','',2,10),(445,'Ambagarh Chauki','',2,10),(446,'Ambikapur','',2,10),(447,'Arang','',2,10),(448,'Baikunthpur','',2,10),(449,'Balod','',2,10),(450,'Baloda','',2,10),(451,'Baloda Bazar','',2,10),(452,'Basna','',2,10),(453,'Bastar','',2,10),(454,'Bemetara','',2,10),(455,'Bhanpuri','',2,10),(456,'Bhatapara','',2,10),(457,'Bhatgaon','',2,10),(458,'Bhilai','',1,10),(459,'Bijapur','',2,10),(460,'Bilaspur','',2,10),(461,'Champa','',2,10),(462,'Chhuikhadan','',2,10),(463,'Deori','',2,10),(464,'Dhamtari','',2,10),(465,'Dongargaon','',2,10),(466,'Dongargarh','',2,10),(467,'Durg','',1,10),(468,'Gandai','',2,10),(469,'Gariaband','',2,10),(470,'Gaurela','',2,10),(471,'Gharghoda','',2,10),(472,'Gidam','',2,10),(473,'Jagdalpur','',2,10),(474,'Janjgir','',2,10),(475,'Janjgir-Champa','',2,10),(476,'Jashpur','',2,10),(477,'Jashpurnagar','',2,10),(478,'Junagarh','',2,10),(479,'Kabeerdham','',2,10),(480,'Kanker','',2,10),(481,'Katghora','',2,10),(482,'Kawardha','',2,10),(483,'Khairagarh','',2,10),(484,'Khamharia','',2,10),(485,'Kharod','',2,10),(486,'Kharsia','',2,10),(487,'Kirandul','',2,10),(488,'Kondagaon','',2,10),(489,'Korba','',2,10),(490,'Koriya','',2,10),(491,'Kota','',1,10),(492,'Kotaparh','',2,10),(493,'Kumhari','',2,10),(494,'Kurud','',2,10),(495,'Lormi','',2,10),(496,'Mahasamund','',2,10),(497,'Mungeli','',2,10),(498,'Narayanpur','',2,10),(499,'Narharpur','',2,10),(500,'Pandaria','',2,10),(501,'Pandatarai','',2,10),(502,'Pasan','',2,10),(503,'Patan','',2,10),(504,'Pathalgaon','',2,10),(505,'Pendra','',2,10),(506,'Pithora','',2,10),(507,'Raigarh','',2,10),(508,'Raipur','',2,10),(509,'Raj Nandgaon','',2,10),(510,'Raj-Nandgaon','',2,10),(511,'Ramanuj Ganj','',2,10),(512,'Ratanpur','',2,10),(513,'Sakti','',2,10),(514,'Saraipali','',2,10),(515,'Sarangarh','',2,10),(516,'Seorinarayan','',2,10),(517,'Simga','',2,10),(518,'Surguja','',2,10),(519,'Takhatpur','',2,10),(520,'Umarkot','',2,10),(521,'Uttar Bastar Kanker','',2,10),(522,'Amli','',2,11),(523,'Dadra','',2,11),(524,'Dadra & Nagar Haveli','',2,11),(525,'Silvassa','',2,11),(526,'Daman','',2,12),(527,'Daman District','',2,12),(528,'Diu','',2,12),(529,'Alipur','',2,13),(530,'Bawana','',2,13),(531,'Central Delhi','',2,13),(532,'Delhi','',2,13),(533,'Deoli','',2,13),(534,'East Delhi','',2,13),(535,'Karol Bagh','',2,13),(536,'Najafgarh','',2,13),(537,'Nangloi Jat','',2,13),(538,'Narela','',2,13),(539,'New Delhi','',2,13),(540,'North Delhi','',2,13),(541,'North East Delhi','',2,13),(542,'North West Delhi','',2,13),(543,'Pitampura','',2,13),(544,'Rohini','',2,13),(545,'South Delhi','',2,13),(546,'South West Delhi','',2,13),(547,'West Delhi','',2,13),(548,'Aldona','',2,14),(549,'Arambol','',2,14),(550,'Baga','',2,14),(551,'Bambolim','',2,14),(552,'Bandora','',2,14),(553,'Benaulim','',2,14),(554,'Calangute','',2,14),(555,'Candolim','',2,14),(556,'Carapur','',2,14),(557,'Cavelossim','',2,14),(558,'Chicalim','',2,14),(559,'Chinchinim','',2,14),(560,'Colovale','',2,14),(561,'Colva','',2,14),(562,'Cortalim','',2,14),(563,'Cuncolim','',2,14),(564,'Curchorem','',2,14),(565,'Curti','',2,14),(566,'Davorlim','',2,14),(567,'Dicholi','',2,14),(568,'Goa Velha','',2,14),(569,'Guirim','',2,14),(570,'Jua','',2,14),(571,'Kankon','',2,14),(572,'Madgaon','',2,14),(573,'Mapuca','',2,14),(574,'Morjim','',2,14),(575,'Mormugao','',2,14),(576,'Navelim','',2,14),(577,'North Goa','',2,14),(578,'Palle','',2,14),(579,'Panaji','',2,14),(580,'Pernem','',2,14),(581,'Ponda','',2,14),(582,'Quepem','',2,14),(583,'Queula','',2,14),(584,'Raia','',2,14),(585,'Saligao','',2,14),(586,'Sancoale','',2,14),(587,'Sanguem','',2,14),(588,'Sanquelim','',2,14),(589,'Sanvordem','',2,14),(590,'Serula','',2,14),(591,'Solim','',2,14),(592,'South Goa','',2,14),(593,'Taleigao','',2,14),(594,'Vagator','',2,14),(595,'Valpoy','',2,14),(596,'Varca','',2,14),(597,'Vasco da Gama','',2,14),(598,'Abrama','',2,15),(599,'Adalaj','',2,15),(600,'Ahmadabad','',2,15),(601,'Ahmedabad','',1,15),(602,'Ahwa','',2,15),(603,'Amod','',2,15),(604,'Amreli','',2,15),(605,'Amroli','',2,15),(606,'Anand','',2,15),(607,'Anjar','',2,15),(608,'Ankleshwar','',2,15),(609,'Babra','',2,15),(610,'Bagasara','',2,15),(611,'Bagasra','',2,15),(612,'Banas Kantha','',2,15),(613,'Bantva','',2,15),(614,'Bardoli','',2,15),(615,'Bedi','',2,15),(616,'Bhachau','',2,15),(617,'Bhanvad','',2,15),(618,'Bharuch','',2,15),(619,'Bhavnagar','',1,15),(620,'Bhayavadar','',2,15),(621,'Bhuj','',2,15),(622,'Bilimora','',2,15),(623,'Bilkha','',2,15),(624,'Borsad','',2,15),(625,'Botad','',2,15),(626,'Chaklasi','',2,15),(627,'Chalala','',2,15),(628,'Chanasma','',2,15),(629,'Chhala','',2,15),(630,'Chhota Udepur','',2,15),(631,'Chikhli','',2,15),(632,'Chotila','',2,15),(633,'Dabhoi','',2,15),(634,'Dahegam','',2,15),(635,'Dahod','',2,15),(636,'Dakor','',2,15),(637,'Damnagar','',2,15),(638,'Dangs (India)','',2,15),(639,'Dayapar','',2,15),(640,'Delvada','',2,15),(641,'Delwada','',2,15),(642,'Devbhumi Dwarka','',2,15),(643,'Devgadh Bariya','',2,15),(644,'Dhandhuka','',2,15),(645,'Dhanera','',2,15),(646,'Dharampur','',2,15),(647,'Dhari','',2,15),(648,'Dhola','',2,15),(649,'Dholka','',2,15),(650,'Dhoraji','',2,15),(651,'Dhrangadhra','',2,15),(652,'Dhrol','',2,15),(653,'Dhuwaran','',2,15),(654,'Disa','',2,15),(655,'Dohad','',2,15),(656,'Dungarpur','',2,15),(657,'Dwarka','',2,15),(658,'Gadhada','',2,15),(659,'Gandevi','',2,15),(660,'Gandhidham','',2,15),(661,'Gandhinagar','',2,15),(662,'Gariadhar','',2,15),(663,'Ghogha','',2,15),(664,'Gir Somnath','',2,15),(665,'Godhra','',2,15),(666,'Gondal','',2,15),(667,'Halol','',2,15),(668,'Halvad','',2,15),(669,'Hansot','',2,15),(670,'Harij','',2,15),(671,'Himatnagar','',2,15),(672,'Jalalpore','',2,15),(673,'Jalalpur','',2,15),(674,'Jambusar','',2,15),(675,'Jamnagar','',2,15),(676,'Jasdan','',2,15),(677,'Jetalsar','',2,15),(678,'Jetpur','',2,15),(679,'Jhulasan','',2,15),(680,'Jodhpur','',1,15),(681,'Jodia','',2,15),(682,'Jodiya Bandar','',2,15),(683,'Junagadh','',2,15),(684,'Kachchh','',2,15),(685,'Kadi','',2,15),(686,'Kadod','',2,15),(687,'Kalavad','',2,15),(688,'Kalol','',2,15),(689,'Kandla','',2,15),(690,'Kanodar','',2,15),(691,'Kapadvanj','',2,15),(692,'Karamsad','',2,15),(693,'Kathor','',2,15),(694,'Katpur','',2,15),(695,'Kavant','',2,15),(696,'Kawant','',2,15),(697,'Keshod','',2,15),(698,'Khambhalia','',2,15),(699,'Khambhaliya','',2,15),(700,'Khambhat','',2,15),(701,'Kheda','',2,15),(702,'Khedbrahma','',2,15),(703,'Kheralu','',2,15),(704,'Kodinar','',2,15),(705,'Kosamba','',2,15),(706,'Kundla','',2,15),(707,'Kutch district','',2,15),(708,'Kutiyana','',2,15),(709,'Lakhtar','',2,15),(710,'Lalpur','',2,15),(711,'Lathi','',2,15),(712,'Limbdi','',2,15),(713,'Lunavada','',2,15),(714,'Mahemdavad','',2,15),(715,'Mahesana','',2,15),(716,'Mahudha','',2,15),(717,'Malpur','',2,15),(718,'Manavadar','',2,15),(719,'Mandal','',2,15),(720,'Mandvi','',2,15),(721,'Mandvi (Surat)','',2,15),(722,'Mangrol','',2,15),(723,'Mansa','',2,15),(724,'Meghraj','',2,15),(725,'Mehsana','',2,15),(726,'Mendarda','',2,15),(727,'Modasa','',2,15),(728,'Morbi','',2,15),(729,'Morva (Hadaf)','',2,15),(730,'Morwa','',2,15),(731,'Mundra','',2,15),(732,'Nadiad','',2,15),(733,'Naliya','',2,15),(734,'Narmada','',2,15),(735,'Naroda','',2,15),(736,'Navsari','',2,15),(737,'Okha','',2,15),(738,'Olpad','',2,15),(739,'Paddhari','',2,15),(740,'Padra','',2,15),(741,'Palanpur','',2,15),(742,'Palitana','',2,15),(743,'Paliyad','',2,15),(744,'Panch Mahals','',2,15),(745,'Panchmahal district','',2,15),(746,'Pardi','',2,15),(747,'Parnera','',2,15),(748,'Patan','',2,15),(749,'Pavi Jetpur','',2,15),(750,'Petlad','',2,15),(751,'Porbandar','',2,15),(752,'Radhanpur','',2,15),(753,'Rajkot','',2,15),(754,'Rajpipla','',2,15),(755,'Rajula','',2,15),(756,'Ranavav','',2,15),(757,'Rapar','',2,15),(758,'Roha','',2,15),(759,'Sabar Kantha','',2,15),(760,'Sachin','',2,15),(761,'Salaya','',2,15),(762,'Sanand','',2,15),(763,'Sankheda','',2,15),(764,'Sarkhej','',2,15),(765,'Savarkundla','',2,15),(766,'Sayla','',2,15),(767,'Shahpur','',2,15),(768,'Shivrajpur','',2,15),(769,'Siddhapur','',2,15),(770,'Siddhpur','',2,15),(771,'Sihor','',2,15),(772,'Sikka','',2,15),(773,'Sinor','',2,15),(774,'Sojitra','',2,15),(775,'Songadh','',2,15),(776,'Surat','',1,15),(777,'Surendranagar','',2,15),(778,'Talaja','',2,15),(779,'Tankara','',2,15),(780,'Tapi','',2,15),(781,'Than','',2,15),(782,'Thangadh','',2,15),(783,'Tharad','',2,15),(784,'Thasra','',2,15),(785,'The Dangs','',2,15),(786,'Umrala','',2,15),(787,'Umreth','',2,15),(788,'Un','',2,15),(789,'Una','',2,15),(790,'Unjha','',2,15),(791,'Upleta','',2,15),(792,'Utran','',2,15),(793,'Vadnagar','',2,15),(794,'Vadodara','',1,15),(795,'Vaghodia','',2,15),(796,'Valabhipur','',2,15),(797,'Vallabh Vidyanagar','',2,15),(798,'Vallabhipur','',2,15),(799,'Valsad','',2,15),(800,'Vansada','',2,15),(801,'Vansda','',2,15),(802,'Vapi','',2,15),(803,'Vartej','',2,15),(804,'Vasa','',2,15),(805,'Vaso','',2,15),(806,'Vejalpur','',2,15),(807,'Veraval','',2,15),(808,'Vijapur','',2,15),(809,'Vinchhiya','',2,15),(810,'Vinchia','',2,15),(811,'Virpur','',2,15),(812,'Visavadar','',2,15),(813,'Visnagar','',2,15),(814,'Vyara','',2,15),(815,'Wadhai','',2,15),(816,'Wadhwan','',2,15),(817,'Waghai','',2,15),(818,'Wankaner','',2,15),(819,'Ambala','',2,16),(820,'Asandh','',2,16),(821,'Ateli Mandi','',2,16),(822,'Bahadurgarh','',2,16),(823,'Bara Uchana','',2,16),(824,'Barwala','',2,16),(825,'Bawal','',2,16),(826,'Beri Khas','',2,16),(827,'Bhiwani','',2,16),(828,'Bilaspur','',2,16),(829,'Buriya','',2,16),(830,'Charkhi Dadri','',2,16),(831,'Chhachhrauli','',2,16),(832,'Dabwali','',2,16),(833,'Dharuhera','',2,16),(834,'Ellenabad','',2,16),(835,'Faridabad','',1,16),(836,'Faridabad District','',2,16),(837,'Farrukhnagar','',2,16),(838,'Fatehabad','',2,16),(839,'Fatehabad District','',2,16),(840,'Firozpur Jhirka','',2,16),(841,'Gharaunda','',2,16),(842,'Gohana','',2,16),(843,'Gorakhpur','',1,16),(844,'Gurgaon','',1,16),(845,'Hansi','',2,16),(846,'Hasanpur','',2,16),(847,'Hisar','',2,16),(848,'Hodal','',2,16),(849,'Inda Chhoi','',2,16),(850,'Indri','',2,16),(851,'Jagadhri','',2,16),(852,'Jakhal','',2,16),(853,'Jhajjar','',2,16),(854,'Jind','',2,16),(855,'Kaithal','',2,16),(856,'Kalanaur','',2,16),(857,'Kalanwali','',2,16),(858,'Kanina Khas','',2,16),(859,'Karnal','',2,16),(860,'Kharkhauda','',2,16),(861,'Kheri Sampla','',2,16),(862,'Kurukshetra','',2,16),(863,'Ladwa','',2,16),(864,'Loharu','',2,16),(865,'Maham','',2,16),(866,'Mahendragarh','',2,16),(867,'Mandholi Kalan','',2,16),(868,'Mustafabad','',2,16),(869,'Narayangarh','',2,16),(870,'Narnaul','',2,16),(871,'Narnaund','',2,16),(872,'Narwana','',2,16),(873,'Nilokheri','',2,16),(874,'Nuh','',2,16),(875,'Palwal','',2,16),(876,'Panchkula','',2,16),(877,'Panipat','',2,16),(878,'Pataudi','',2,16),(879,'Pehowa','',2,16),(880,'Pinjaur','',2,16),(881,'Punahana','',2,16),(882,'Pundri','',2,16),(883,'Radaur','',2,16),(884,'Rania','',2,16),(885,'Ratia','',2,16),(886,'Rewari','',2,16),(887,'Rewari District','',2,16),(888,'Rohtak','',2,16),(889,'Safidon','',2,16),(890,'Samalkha','',2,16),(891,'Shadipur Julana','',2,16),(892,'Shahabad','',2,16),(893,'Sirsa','',2,16),(894,'Sohna','',2,16),(895,'Sonipat','',2,16),(896,'Taoru','',2,16),(897,'Thanesar','',2,16),(898,'Tohana','',2,16),(899,'Tosham','',2,16),(900,'Uklana','',2,16),(901,'Yamunanagar','',2,16),(902,'Arki','',2,17),(903,'Baddi','',2,17),(904,'Banjar','',2,17),(905,'Bilaspur','',2,17),(906,'Chamba','',2,17),(907,'Chaupal','',2,17),(908,'Chowari','',2,17),(909,'Chuari Khas','',2,17),(910,'Dagshai','',2,17),(911,'Dalhousie','',2,17),(912,'Daulatpur','',2,17),(913,'Dera Gopipur','',2,17),(914,'Dharamsala','',2,17),(915,'Gagret','',2,17),(916,'Ghumarwin','',2,17),(917,'Hamirpur','',2,17),(918,'Jawala Mukhi','',2,17),(919,'Jogindarnagar','',2,17),(920,'Jubbal','',2,17),(921,'Jutogh','',2,17),(922,'Kalka','',2,17),(923,'Kangar','',2,17),(924,'Kangra','',2,17),(925,'Kasauli','',2,17),(926,'Kinnaur','',2,17),(927,'Kotkhai','',2,17),(928,'Kotla','',2,17),(929,'Kulu','',2,17),(930,'Kyelang','',2,17),(931,'Lahul and Spiti','',2,17),(932,'Manali','',2,17),(933,'Mandi','',2,17),(934,'Nadaun','',2,17),(935,'Nagar','',2,17),(936,'Nagrota','',2,17),(937,'Nahan','',2,17),(938,'Nalagarh','',2,17),(939,'Palampur','',2,17),(940,'Pandoh','',2,17),(941,'Paonta Sahib','',2,17),(942,'Parwanoo','',2,17),(943,'Rajgarh','',2,17),(944,'Rampur','',2,17),(945,'Rohru','',2,17),(946,'Sabathu','',2,17),(947,'Santokhgarh','',2,17),(948,'Sarahan','',2,17),(949,'Sarka Ghat','',2,17),(950,'Seoni','',2,17),(951,'Shimla','',2,17),(952,'Sirmaur','',2,17),(953,'Solan','',2,17),(954,'Sundarnagar','',2,17),(955,'Theog','',2,17),(956,'Tira Sujanpur','',2,17),(957,'Una','',2,17),(958,'Yol','',2,17),(959,'Akhnur','',2,18),(960,'Anantnag','',2,18),(961,'Awantipur','',2,18),(962,'Badgam','',2,18),(963,'Bandipore','',2,18),(964,'Bandipura','',2,18),(965,'Banihal','',2,18),(966,'Baramula','',2,18),(967,'Batoti','',2,18),(968,'Bhadarwah','',2,18),(969,'Bijbehara','',2,18),(970,'Bishnah','',2,18),(971,'Doda','',2,18),(972,'Gandarbal','',2,18),(973,'Ganderbal','',2,18),(974,'Gho Brahmanan de','',2,18),(975,'Hajan','',2,18),(976,'Hiranagar','',2,18),(977,'Jammu','',1,18),(978,'Jaurian','',2,18),(979,'Kathua','',2,18),(980,'Katra','',2,18),(981,'Khaur','',2,18),(982,'Kishtwar','',2,18),(983,'Kud','',2,18),(984,'Kulgam','',2,18),(985,'Kupwara','',2,18),(986,'Ladakh','',2,18),(987,'Magam','',2,18),(988,'Nawanshahr','',2,18),(989,'Noria','',2,18),(990,'Padam','',2,18),(991,'Pahlgam','',2,18),(992,'Parol','',2,18),(993,'Pattan','',2,18),(994,'Pulwama','',2,18),(995,'Punch','',2,18),(996,'Qazigund','',2,18),(997,'Rajaori','',2,18),(998,'Rajauri','',2,18),(999,'Ramban','',2,18),(1000,'Ramgarh','',2,18),(1001,'Ramnagar','',2,18),(1002,'Riasi','',2,18),(1003,'Samba','',2,18),(1004,'Shupiyan','',2,18),(1005,'Sopur','',2,18),(1006,'Soyibug','',2,18),(1007,'Srinagar','',2,18),(1008,'Sumbal','',2,18),(1009,'Thang','',2,18),(1010,'Thanna Mandi','',2,18),(1011,'Tral','',2,18),(1012,'Tsrar Sharif','',2,18),(1013,'Udhampur','',2,18),(1014,'Uri','',2,18),(1015,'Bagra','',2,19),(1016,'Barka Kana','',2,19),(1017,'Barki Saria','',2,19),(1018,'Barwadih','',2,19),(1019,'Bhojudih','',2,19),(1020,'Bokaro','',1,19),(1021,'Bundu','',2,19),(1022,'Chaibasa','',2,19),(1023,'Chakradharpur','',2,19),(1024,'Chakulia','',2,19),(1025,'Chandil','',2,19),(1026,'Chas','',2,19),(1027,'Chatra','',2,19),(1028,'Chiria','',2,19),(1029,'Daltonganj','',2,19),(1030,'Deogarh','',2,19),(1031,'Dhanbad','',1,19),(1032,'Dhanwar','',2,19),(1033,'Dugda','',2,19),(1034,'Dumka','',2,19),(1035,'Garhwa','',2,19),(1036,'Ghatsila','',2,19),(1037,'Giridih','',2,19),(1038,'Gobindpur','',2,19),(1039,'Godda','',2,19),(1040,'Gomoh','',2,19),(1041,'Gopinathpur','',2,19),(1042,'Gua','',2,19),(1043,'Gumia','',2,19),(1044,'Gumla','',2,19),(1045,'Hazaribag','',2,19),(1046,'Hazaribagh','',2,19),(1047,'Hesla','',2,19),(1048,'Husainabad','',2,19),(1049,'Jagannathpur','',2,19),(1050,'Jamadoba','',2,19),(1051,'Jamshedpur','',1,19),(1052,'Jamtara','',2,19),(1053,'Jasidih','',2,19),(1054,'Jharia','',2,19),(1055,'Jugsalai','',2,19),(1056,'Jumri Tilaiya','',2,19),(1057,'Kalikapur','',2,19),(1058,'Kandra','',2,19),(1059,'Kanke','',2,19),(1060,'Katras','',2,19),(1061,'Kenduadih','',2,19),(1062,'Kharsawan','',2,19),(1063,'Khunti','',2,19),(1064,'Kodarma','',2,19),(1065,'Kuju','',2,19),(1066,'Latehar','',2,19),(1067,'Lohardaga','',2,19),(1068,'Madhupur','',2,19),(1069,'Malkera','',2,19),(1070,'Manoharpur','',2,19),(1071,'Mugma','',2,19),(1072,'Mushabani','',2,19),(1073,'Neturhat','',2,19),(1074,'Nirsa','',2,19),(1075,'Noamundi','',2,19),(1076,'Pakur','',2,19),(1077,'Palamu','',2,19),(1078,'Pashchim Singhbhum','',2,19),(1079,'patamda','',2,19),(1080,'Pathardih','',2,19),(1081,'Purba Singhbhum','',2,19),(1082,'Ramgarh','',2,19),(1083,'Ranchi','',2,19),(1084,'Ray','',2,19),(1085,'Sahibganj','',2,19),(1086,'Saraikela','',2,19),(1087,'Sarubera','',2,19),(1088,'Sijua','',2,19),(1089,'Simdega','',2,19),(1090,'Sini','',2,19),(1091,'Topchanchi','',2,19),(1092,'Afzalpur','',2,20),(1093,'Ajjampur','',2,20),(1094,'Aland','',2,20),(1095,'Alnavar','',2,20),(1096,'Alur','',2,20),(1097,'Anekal','',2,20),(1098,'Ankola','',2,20),(1099,'Annigeri','',2,20),(1100,'Arkalgud','',2,20),(1101,'Arsikere','',2,20),(1102,'Athni','',2,20),(1103,'Aurad','',2,20),(1104,'Badami','',2,20),(1105,'Bagalkot','',2,20),(1106,'Bagepalli','',2,20),(1107,'Bail-Hongal','',2,20),(1108,'Ballari','',2,20),(1109,'Banavar','',2,20),(1110,'Bangalore Rural','',2,20),(1111,'Bangalore Urban','',2,20),(1112,'Bangarapet','',2,20),(1113,'Bannur','',2,20),(1114,'Bantval','',2,20),(1115,'Basavakalyan','',2,20),(1116,'Basavana Bagevadi','',2,20),(1117,'Belgaum','',1,20),(1118,'Bellary','',2,20),(1119,'Belluru','',2,20),(1120,'Beltangadi','',2,20),(1121,'Belur','',2,20),(1122,'Bengaluru','',2,20),(1123,'Bhadravati','',2,20),(1124,'Bhalki','',2,20),(1125,'Bhatkal','',2,20),(1126,'Bidar','',2,20),(1127,'Bijapur','',2,20),(1128,'Bilgi','',2,20),(1129,'Birur','',2,20),(1130,'Byadgi','',2,20),(1131,'Byndoor','',2,20),(1132,'Canacona','',2,20),(1133,'Challakere','',2,20),(1134,'Chamrajnagar','',2,20),(1135,'Channagiri','',2,20),(1136,'Channapatna','',2,20),(1137,'Channarayapatna','',2,20),(1138,'Chik Ballapur','',2,20),(1139,'Chikkaballapur','',2,20),(1140,'Chikmagalur','',2,20),(1141,'Chiknayakanhalli','',2,20),(1142,'Chikodi','',2,20),(1143,'Chincholi','',2,20),(1144,'Chintamani','',2,20),(1145,'Chitapur','',2,20),(1146,'Chitradurga','',2,20),(1147,'Closepet','',2,20),(1148,'Coondapoor','',2,20),(1149,'Dakshina Kannada','',2,20),(1150,'Dandeli','',2,20),(1151,'Davanagere','',2,20),(1152,'Davangere','',2,20),(1153,'Devanhalli','',2,20),(1154,'Dharwad','',2,20),(1155,'Dod Ballapur','',2,20),(1156,'French Rocks','',2,20),(1157,'Gadag','',2,20),(1158,'Gadag-Betageri','',2,20),(1159,'Gajendragarh','',2,20),(1160,'Gangawati','',2,20),(1161,'Gangolli','',2,20),(1162,'Gokak','',2,20),(1163,'Gokarna','',2,20),(1164,'Goribidnur','',2,20),(1165,'Gorur','',2,20),(1166,'Gubbi','',2,20),(1167,'Gudibanda','',2,20),(1168,'Gulbarga','',2,20),(1169,'Guledagudda','',2,20),(1170,'Gundlupet','',2,20),(1171,'Gurmatkal','',2,20),(1172,'Hadagalli','',2,20),(1173,'Haliyal','',2,20),(1174,'Hampi','',2,20),(1175,'Hangal','',2,20),(1176,'Harihar','',2,20),(1177,'Harpanahalli','',2,20),(1178,'Hassan','',2,20),(1179,'Haveri','',2,20),(1180,'Heggadadevankote','',2,20),(1181,'Hirekerur','',2,20),(1182,'Hiriyur','',2,20),(1183,'Holalkere','',2,20),(1184,'Hole Narsipur','',2,20),(1185,'Homnabad','',2,20),(1186,'Honavar','',2,20),(1187,'Honnali','',2,20),(1188,'Hosakote','',2,20),(1189,'Hosanagara','',2,20),(1190,'Hosangadi','',2,20),(1191,'Hosdurga','',2,20),(1192,'Hoskote','',2,20),(1193,'Hospet','',2,20),(1194,'Hubli','',1,20),(1195,'Hukeri','',2,20),(1196,'Hungund','',2,20),(1197,'Hunsur','',2,20),(1198,'Ilkal','',2,20),(1199,'Indi','',2,20),(1200,'Jagalur','',2,20),(1201,'Jamkhandi','',2,20),(1202,'Jevargi','',2,20),(1203,'Kadur','',2,20),(1204,'Kalghatgi','',2,20),(1205,'Kampli','',2,20),(1206,'Kankanhalli','',2,20),(1207,'Karkala','',2,20),(1208,'Karwar','',2,20),(1209,'Kavalur','',2,20),(1210,'Kerur','',2,20),(1211,'Khanapur','',2,20),(1212,'Kodagu','',2,20),(1213,'Kodigenahalli','',2,20),(1214,'Kodlipet','',2,20),(1215,'Kolar','',2,20),(1216,'Kollegal','',2,20),(1217,'Konanur','',2,20),(1218,'Konnur','',2,20),(1219,'Koppa','',2,20),(1220,'Koppal','',2,20),(1221,'Koratagere','',2,20),(1222,'Kotturu','',2,20),(1223,'Krishnarajpet','',2,20),(1224,'Kudachi','',2,20),(1225,'Kudligi','',2,20),(1226,'Kumsi','',2,20),(1227,'Kumta','',2,20),(1228,'Kundgol','',2,20),(1229,'Kunigal','',2,20),(1230,'Kurgunta','',2,20),(1231,'Kushalnagar','',2,20),(1232,'Kushtagi','',2,20),(1233,'Lakshmeshwar','',2,20),(1234,'Lingsugur','',2,20),(1235,'Londa','',2,20),(1236,'Maddagiri','',2,20),(1237,'Maddur','',2,20),(1238,'Madikeri','',2,20),(1239,'Magadi','',2,20),(1240,'Mahalingpur','',2,20),(1241,'Malavalli','',2,20),(1242,'Malpe','',2,20),(1243,'Malur','',2,20),(1244,'Mandya','',2,20),(1245,'Mangalore','',1,20),(1246,'Manipal','',2,20),(1247,'Manvi','',2,20),(1248,'Mayakonda','',2,20),(1249,'Melukote','',2,20),(1250,'Mudbidri','',2,20),(1251,'Muddebihal','',2,20),(1252,'Mudgal','',2,20),(1253,'Mudgere','',2,20),(1254,'Mudhol','',2,20),(1255,'Mulbagal','',2,20),(1256,'Mulgund','',2,20),(1257,'Mulki','',2,20),(1258,'Mundargi','',2,20),(1259,'Mundgod','',2,20),(1260,'Munirabad','',2,20),(1261,'Murudeshwara','',2,20),(1262,'Mysore','',1,20),(1263,'Nagamangala','',2,20),(1264,'Nanjangud','',2,20),(1265,'Narasimharajapura','',2,20),(1266,'Naregal','',2,20),(1267,'Nargund','',2,20),(1268,'Navalgund','',2,20),(1269,'Nelamangala','',2,20),(1270,'Nyamti','',2,20),(1271,'Pangala','',2,20),(1272,'Pavugada','',2,20),(1273,'Piriyapatna','',2,20),(1274,'Ponnampet','',2,20),(1275,'Puttur','',2,20),(1276,'Rabkavi','',2,20),(1277,'Raichur','',2,20),(1278,'Ramanagara','',2,20),(1279,'Ranibennur','',2,20),(1280,'Raybag','',2,20),(1281,'Robertsonpet','',2,20),(1282,'Ron','',2,20),(1283,'Sadalgi','',2,20),(1284,'Sagar','',2,20),(1285,'Sakleshpur','',2,20),(1286,'Sandur','',2,20),(1287,'Sanivarsante','',2,20),(1288,'Sankeshwar','',2,20),(1289,'Sargur','',2,20),(1290,'Saundatti','',2,20),(1291,'Savanur','',2,20),(1292,'Seram','',2,20),(1293,'Shahabad','',2,20),(1294,'Shahpur','',2,20),(1295,'Shiggaon','',2,20),(1296,'Shikarpur','',2,20),(1297,'Shimoga','',2,20),(1298,'Shirhatti','',2,20),(1299,'Shorapur','',2,20),(1300,'Shrirangapattana','',2,20),(1301,'Siddapur','',2,20),(1302,'Sidlaghatta','',2,20),(1303,'Sindgi','',2,20),(1304,'Sindhnur','',2,20),(1305,'Sira','',2,20),(1306,'Sirsi','',2,20),(1307,'Siruguppa','',2,20),(1308,'Someshwar','',2,20),(1309,'Somvarpet','',2,20),(1310,'Sorab','',2,20),(1311,'Sravana Belgola','',2,20),(1312,'Sringeri','',2,20),(1313,'Srinivaspur','',2,20),(1314,'Sulya','',2,20),(1315,'Suntikoppa','',2,20),(1316,'Talikota','',2,20),(1317,'Tarikere','',2,20),(1318,'Tekkalakote','',2,20),(1319,'Terdal','',2,20),(1320,'Tiptur','',2,20),(1321,'Tirthahalli','',2,20),(1322,'Tirumakudal Narsipur','',2,20),(1323,'Tumkur','',2,20),(1324,'Turuvekere','',2,20),(1325,'Udupi','',2,20),(1326,'Ullal','',2,20),(1327,'Uttar Kannada','',2,20),(1328,'Vadigenhalli','',2,20),(1329,'Virarajendrapet','',2,20),(1330,'Wadi','',2,20),(1331,'Yadgir','',2,20),(1332,'Yelahanka','',2,20),(1333,'Yelandur','',2,20),(1334,'Yelbarga','',2,20),(1335,'Yellapur','',2,20),(1336,'Adur','',2,21),(1337,'Alappuzha','',2,21),(1338,'Aluva','',2,21),(1339,'Alwaye','',2,21),(1340,'Angamali','',2,21),(1341,'Aroor','',2,21),(1342,'Arukutti','',2,21),(1343,'Attingal','',2,21),(1344,'Avanoor','',2,21),(1345,'Azhikkal','',2,21),(1346,'Badagara','',2,21),(1347,'Beypore','',2,21),(1348,'Changanacheri','',2,21),(1349,'Chelakara','',2,21),(1350,'Chengannur','',2,21),(1351,'Cherpulassery','',2,21),(1352,'Cherthala','',2,21),(1353,'Chetwayi','',2,21),(1354,'Chittur','',2,21),(1355,'Cochin','',1,21),(1356,'Dharmadam','',2,21),(1357,'Edakkulam','',2,21),(1358,'Elur','',2,21),(1359,'Erattupetta','',2,21),(1360,'Ernakulam','',2,21),(1361,'Ferokh','',2,21),(1362,'Guruvayur','',2,21),(1363,'Idukki','',2,21),(1364,'Iringal','',2,21),(1365,'Irinjalakuda','',2,21),(1366,'Kadakkavoor','',2,21),(1367,'Kalamassery','',2,21),(1368,'Kalavoor','',2,21),(1369,'Kalpatta','',2,21),(1370,'Kannangad','',2,21),(1371,'Kannavam','',2,21),(1372,'Kannur','',2,21),(1373,'Kasaragod','',2,21),(1374,'Kasaragod District','',2,21),(1375,'Kattanam','',2,21),(1376,'Kayankulam','',2,21),(1377,'Kizhake Chalakudi','',2,21),(1378,'Kodungallur','',2,21),(1379,'Kollam','',2,21),(1380,'Kotamangalam','',2,21),(1381,'Kottayam','',2,21),(1382,'Kovalam','',2,21),(1383,'Kozhikode','',1,21),(1384,'Kumbalam','',2,21),(1385,'Kunnamangalam','',2,21),(1386,'Kunnamkulam','',2,21),(1387,'Kunnumma','',2,21),(1388,'Kutiatodu','',2,21),(1389,'Kuttampuzha','',2,21),(1390,'Lalam','',2,21),(1391,'Mahe','',2,21),(1392,'Malappuram','',2,21),(1393,'Manjeri','',2,21),(1394,'Manjeshvar','',2,21),(1395,'Mannarakkat','',2,21),(1396,'Marayur','',2,21),(1397,'Mattanur','',2,21),(1398,'Mavelikara','',2,21),(1399,'Mavoor','',2,21),(1400,'Muluppilagadu','',2,21),(1401,'Munnar','',2,21),(1402,'Muvattupula','',2,21),(1403,'Muvattupuzha','',2,21),(1404,'Nadapuram','',2,21),(1405,'Naduvannur','',2,21),(1406,'Nedumangad','',2,21),(1407,'Neyyattinkara','',2,21),(1408,'Nileshwar','',2,21),(1409,'Ottappalam','',2,21),(1410,'Palackattumala','',2,21),(1411,'Palakkad district','',2,21),(1412,'Palghat','',2,21),(1413,'Panamaram','',2,21),(1414,'Pappinissheri','',2,21),(1415,'Paravur Tekkumbhagam','',2,21),(1416,'Pariyapuram','',2,21),(1417,'Pathanamthitta','',2,21),(1418,'Pattanamtitta','',2,21),(1419,'Payyannur','',2,21),(1420,'Perumbavoor','',2,21),(1421,'Perumpavur','',2,21),(1422,'Perya','',2,21),(1423,'Piravam','',2,21),(1424,'Ponmana','',2,21),(1425,'Ponnani','',2,21),(1426,'Punalur','',2,21),(1427,'Ramamangalam','',2,21),(1428,'Shertallai','',2,21),(1429,'Shoranur','',2,21),(1430,'Talipparamba','',2,21),(1431,'Tellicherry','',2,21),(1432,'Thanniyam','',2,21),(1433,'Thiruvananthapuram','',2,21),(1434,'Thrissur','',2,21),(1435,'Thrissur District','',2,21),(1436,'Tirur','',2,21),(1437,'Tiruvalla','',2,21),(1438,'Vaikam','',2,21),(1439,'Varkala','',2,21),(1440,'Vayalar','',2,21),(1441,'Vettur','',2,21),(1442,'Wayanad','',1,21),(1443,'Kargil','',2,22),(1444,'Leh','',2,22),(1445,'Kavaratti','',2,23),(1446,'Lakshadweep','',2,23),(1447,'Agar','',2,24),(1448,'Ajaigarh','',2,24),(1449,'Akodia','',2,24),(1450,'Alampur','',2,24),(1451,'Alirajpur','',2,24),(1452,'Alot','',2,24),(1453,'Amanganj','',2,24),(1454,'Amarkantak','',2,24),(1455,'Amarpatan','',2,24),(1456,'Amarwara','',2,24),(1457,'Ambah','',2,24),(1458,'Amla','',2,24),(1459,'Anjad','',2,24),(1460,'Antri','',2,24),(1461,'Anuppur','',2,24),(1462,'Aron','',2,24),(1463,'Ashoknagar','',2,24),(1464,'Ashta','',2,24),(1465,'Babai','',2,24),(1466,'Badarwas','',2,24),(1467,'Badnawar','',2,24),(1468,'Bag','',2,24),(1469,'Bagli','',2,24),(1470,'Baihar','',2,24),(1471,'Baikunthpur','',2,24),(1472,'Bakshwaho','',2,24),(1473,'Balaghat','',2,24),(1474,'Baldeogarh','',2,24),(1475,'Bamna','',2,24),(1476,'Bamor Kalan','',2,24),(1477,'Bamora','',2,24),(1478,'Banda','',2,24),(1479,'Barela','',2,24),(1480,'Barghat','',2,24),(1481,'Bargi','',2,24),(1482,'Barhi','',2,24),(1483,'Barwani','',2,24),(1484,'Basoda','',2,24),(1485,'Begamganj','',2,24),(1486,'Beohari','',2,24),(1487,'Berasia','',2,24),(1488,'Betma','',2,24),(1489,'Betul','',2,24),(1490,'Betul Bazar','',2,24),(1491,'Bhabhra','',2,24),(1492,'Bhainsdehi','',2,24),(1493,'Bhander','',2,24),(1494,'Bhanpura','',2,24),(1495,'Bhawaniganj','',2,24),(1496,'Bhikangaon','',2,24),(1497,'Bhind','',2,24),(1498,'Bhitarwar','',2,24),(1499,'Bhopal','',2,24),(1500,'Biaora','',2,24),(1501,'Bijawar','',2,24),(1502,'Bijrauni','',2,24),(1503,'Bodri','',2,24),(1504,'Burhanpur','',2,24),(1505,'Burhar','',2,24),(1506,'Chanderi','',2,24),(1507,'Chandia','',2,24),(1508,'Chandla','',2,24),(1509,'Chhatarpur','',2,24),(1510,'Chhindwara','',2,24),(1511,'Chichli','',2,24),(1512,'Chorhat','',2,24),(1513,'Daboh','',2,24),(1514,'Dabra','',2,24),(1515,'Damoh','',2,24),(1516,'Datia','',2,24),(1517,'Deori Khas','',2,24),(1518,'Depalpur','',2,24),(1519,'Dewas','',2,24),(1520,'Dhamnod','',2,24),(1521,'Dhana','',2,24),(1522,'Dhar','',2,24),(1523,'Dharampuri','',2,24),(1524,'Dindori','',2,24),(1525,'Etawa','',2,24),(1526,'Gadarwara','',2,24),(1527,'Garha Brahman','',2,24),(1528,'Garhakota','',2,24),(1529,'Gautampura','',2,24),(1530,'Ghansor','',2,24),(1531,'Gogapur','',2,24),(1532,'Gohadi','',2,24),(1533,'Govindgarh','',2,24),(1534,'Guna','',2,24),(1535,'Gurh','',2,24),(1536,'Gwalior','',1,24),(1537,'Harda','',2,24),(1538,'Harda Khas','',2,24),(1539,'Harpalpur','',2,24),(1540,'Harrai','',2,24),(1541,'Harsud','',2,24),(1542,'Hatod','',2,24),(1543,'Hatta','',2,24),(1544,'Hindoria','',2,24),(1545,'Hoshangabad','',2,24),(1546,'Iawar','',2,24),(1547,'Ichhawar','',2,24),(1548,'Iklehra','',2,24),(1549,'Indore','',1,24),(1550,'Isagarh','',2,24),(1551,'Itarsi','',2,24),(1552,'Jabalpur','',1,24),(1553,'Jaisinghnagar','',2,24),(1554,'Jaithari','',2,24),(1555,'Jamai','',2,24),(1556,'Jaora','',2,24),(1557,'Jatara','',2,24),(1558,'Jawad','',2,24),(1559,'Jhabua','',2,24),(1560,'Jiran','',2,24),(1561,'Jobat','',2,24),(1562,'Jora','',2,24),(1563,'Kailaras','',2,24),(1564,'Kaimori','',2,24),(1565,'Kannod','',2,24),(1566,'Kareli','',2,24),(1567,'Karera','',2,24),(1568,'Karrapur','',2,24),(1569,'Kasrawad','',2,24),(1570,'Katangi','',2,24),(1571,'Katni','',2,24),(1572,'Khachrod','',2,24),(1573,'Khailar','',2,24),(1574,'Khajuraho Group of Monuments','',2,24),(1575,'Khamaria','',2,24),(1576,'Khandwa','',2,24),(1577,'Khandwa district','',2,24),(1578,'Khargapur','',2,24),(1579,'Khargone','',2,24),(1580,'Khategaon','',2,24),(1581,'Khilchipur','',2,24),(1582,'Khirkiyan','',2,24),(1583,'Khujner','',2,24),(1584,'Khurai','',2,24),(1585,'Kolaras','',2,24),(1586,'Korwai','',2,24),(1587,'Kotar','',2,24),(1588,'Kothi','',2,24),(1589,'Kotma','',2,24),(1590,'Kotwa','',2,24),(1591,'Kukshi','',2,24),(1592,'Kumbhraj','',2,24),(1593,'Lahar','',2,24),(1594,'Lakhnadon','',2,24),(1595,'Leteri','',2,24),(1596,'Lodhikheda','',2,24),(1597,'Machalpur','',2,24),(1598,'Madhogarh','',2,24),(1599,'Maheshwar','',2,24),(1600,'Mahgawan','',2,24),(1601,'Maihar','',2,24),(1602,'Majholi','',2,24),(1603,'Maksi','',2,24),(1604,'Malhargarh','',2,24),(1605,'Manasa','',2,24),(1606,'Manawar','',2,24),(1607,'Mandideep','',2,24),(1608,'Mandla','',2,24),(1609,'Mandleshwar','',2,24),(1610,'Mandsaur','',2,24),(1611,'Mangawan','',2,24),(1612,'Manpur','',2,24),(1613,'Mau','',2,24),(1614,'Mauganj','',2,24),(1615,'Mihona','',2,24),(1616,'Mohgaon','',2,24),(1617,'Morar','',2,24),(1618,'Morena','',2,24),(1619,'Multai','',2,24),(1620,'Mundi','',2,24),(1621,'Mungaoli','',2,24),(1622,'Murwara','',2,24),(1623,'Nagda','',2,24),(1624,'Nagod','',2,24),(1625,'Naigarhi','',2,24),(1626,'Nainpur','',2,24),(1627,'Namli','',2,24),(1628,'Naraini','',2,24),(1629,'Narayangarh','',2,24),(1630,'Narsimhapur','',2,24),(1631,'Narsinghgarh','',2,24),(1632,'Narwar','',2,24),(1633,'Nasrullahganj','',2,24),(1634,'Neemuch','',2,24),(1635,'Nepanagar','',2,24),(1636,'Orchha','',2,24),(1637,'Pachmarhi','',2,24),(1638,'Palera','',2,24),(1639,'Pali','',2,24),(1640,'Panagar','',2,24),(1641,'Panara','',2,24),(1642,'Pandhana','',2,24),(1643,'Pandhurna','',2,24),(1644,'Panna','',2,24),(1645,'Pansemal','',2,24),(1646,'Parasia','',2,24),(1647,'Patan','',2,24),(1648,'Patharia','',2,24),(1649,'Pawai','',2,24),(1650,'Petlawad','',2,24),(1651,'Piploda','',2,24),(1652,'Pithampur','',2,24),(1653,'Porsa','',2,24),(1654,'Punasa','',2,24),(1655,'Raghogarh','',2,24),(1656,'Rahatgarh','',2,24),(1657,'Raisen','',2,24),(1658,'Rajgarh','',2,24),(1659,'Rajnagar','',2,24),(1660,'Rajpur','',2,24),(1661,'Rampura','',2,24),(1662,'Ranapur','',2,24),(1663,'Ratangarh','',2,24),(1664,'Ratlam','',2,24),(1665,'Rehli','',2,24),(1666,'Rehti','',2,24),(1667,'Rewa','',2,24),(1668,'Sabalgarh','',2,24),(1669,'Sagar','',2,24),(1670,'Sailana','',2,24),(1671,'Sanawad','',2,24),(1672,'Sanchi','',2,24),(1673,'Sanwer','',2,24),(1674,'Sarangpur','',2,24),(1675,'Satna','',2,24),(1676,'Satwas','',2,24),(1677,'Saugor','',2,24),(1678,'Sausar','',2,24),(1679,'Sehore','',2,24),(1680,'Sendhwa','',2,24),(1681,'Seondha','',2,24),(1682,'Seoni','',2,24),(1683,'Seoni Malwa','',2,24),(1684,'Shahdol','',2,24),(1685,'Shahgarh','',2,24),(1686,'Shahpur','',2,24),(1687,'Shahpura','',2,24),(1688,'Shajapur','',2,24),(1689,'Shamgarh','',2,24),(1690,'Sheopur','',2,24),(1691,'Shivpuri','',2,24),(1692,'Shujalpur','',2,24),(1693,'Sidhi','',2,24),(1694,'Sihora','',2,24),(1695,'Simaria','',2,24),(1696,'Singoli','',2,24),(1697,'Singrauli','',2,24),(1698,'Sirmaur','',2,24),(1699,'Sironj','',2,24),(1700,'Sitamau','',2,24),(1701,'Sohagi','',2,24),(1702,'Sohagpur','',2,24),(1703,'Sultanpur','',2,24),(1704,'Susner','',2,24),(1705,'Tal','',2,24),(1706,'Talen','',2,24),(1707,'Tarana','',2,24),(1708,'Tekanpur','',2,24),(1709,'Tendukheda','',2,24),(1710,'Teonthar','',2,24),(1711,'Thandla','',2,24),(1712,'Tikamgarh','',2,24),(1713,'Tirodi','',2,24),(1714,'Udaipura','',2,24),(1715,'Ujjain','',2,24),(1716,'Ukwa','',2,24),(1717,'Umaria','',2,24),(1718,'Umaria District','',2,24),(1719,'Umri','',2,24),(1720,'Unhel','',2,24),(1721,'Vidisha','',2,24),(1722,'Waraseoni','',2,24),(1723,'Achalpur','',2,25),(1724,'Ahiri','',2,25),(1725,'Ahmadnagar','',2,25),(1726,'Ahmadpur','',2,25),(1727,'Airoli','',2,25),(1728,'Ajra','',2,25),(1729,'Akalkot','',2,25),(1730,'Akola','',2,25),(1731,'Akot','',2,25),(1732,'Alandi','',2,25),(1733,'Alibag','',2,25),(1734,'Allapalli','',2,25),(1735,'Amalner','',2,25),(1736,'Amarnath','',2,25),(1737,'Ambad','',2,25),(1738,'Ambajogai','',2,25),(1739,'Amravati','',2,25),(1740,'Amravati Division','',2,25),(1741,'Anjangaon','',2,25),(1742,'Anshing','',2,25),(1743,'Arangaon','',2,25),(1744,'Artist Village','',2,25),(1745,'Arvi','',2,25),(1746,'Ashta','',2,25),(1747,'Ashti','',2,25),(1748,'Aurangabad','',2,25),(1749,'Ausa','',2,25),(1750,'Badlapur','',2,25),(1751,'Balapur','',2,25),(1752,'Ballalpur','',2,25),(1753,'Baramati','',2,25),(1754,'Barsi','',2,25),(1755,'Basmat','',2,25),(1756,'Beed','',2,25),(1757,'Bhandara','',2,25),(1758,'Bhayandar','',2,25),(1759,'Bhigvan','',2,25),(1760,'Bhiwandi','',2,25),(1761,'Bhor','',2,25),(1762,'Bhudgaon','',2,25),(1763,'Bhum','',2,25),(1764,'Bhusaval','',2,25),(1765,'Bid','',2,25),(1766,'Biloli','',2,25),(1767,'Boisar','',2,25),(1768,'Borivli','',2,25),(1769,'Buldana','',2,25),(1770,'Chakan','',2,25),(1771,'Chalisgaon','',2,25),(1772,'Chanda','',2,25),(1773,'Chandor','',2,25),(1774,'Chandrapur','',2,25),(1775,'Chandur','',2,25),(1776,'Chandur Bazar','',2,25),(1777,'Chicholi','',2,25),(1778,'Chikhli','',2,25),(1779,'Chinchani','',2,25),(1780,'Chiplun','',2,25),(1781,'Chopda','',2,25),(1782,'Dabhol','',2,25),(1783,'Dahanu','',2,25),(1784,'Darwha','',2,25),(1785,'Daryapur','',2,25),(1786,'Dattapur','',2,25),(1787,'Daulatabad','',2,25),(1788,'Daund','',2,25),(1789,'Dehu','',2,25),(1790,'Deolali','',2,25),(1791,'Deoli','',2,25),(1792,'Deulgaon Raja','',2,25),(1793,'Dharangaon','',2,25),(1794,'Dharmabad','',2,25),(1795,'Dharur','',2,25),(1796,'Dhule','',2,25),(1797,'Dhulia','',2,25),(1798,'Diglur','',2,25),(1799,'Digras','',2,25),(1800,'Dombivli','',2,25),(1801,'Dondaicha','',2,25),(1802,'Dudhani','',2,25),(1803,'Durgapur','',1,25),(1804,'Erandol','',2,25),(1805,'Faizpur','',2,25),(1806,'Gadchiroli','',2,25),(1807,'Gadhinglaj','',2,25),(1808,'Gangakher','',2,25),(1809,'Gangapur','',2,25),(1810,'Gevrai','',2,25),(1811,'Ghatanji','',2,25),(1812,'Ghoti Budrukh','',2,25),(1813,'Ghugus','',2,25),(1814,'Gondia','',2,25),(1815,'Gondiya','',2,25),(1816,'Goregaon','',2,25),(1817,'Guhagar','',2,25),(1818,'Hadgaon','',2,25),(1819,'Harnai','',2,25),(1820,'Hinganghat','',2,25),(1821,'Hingoli','',2,25),(1822,'Hirapur Hamesha','',2,25),(1823,'Ichalkaranji','',2,25),(1824,'Igatpuri','',2,25),(1825,'Indapur','',2,25),(1826,'Jaisingpur','',2,25),(1827,'Jalgaon','',2,25),(1828,'Jalgaon Jamod','',2,25),(1829,'Jalna','',2,25),(1830,'Jawhar','',2,25),(1831,'Jejuri','',2,25),(1832,'Jintur','',2,25),(1833,'Junnar','',2,25),(1834,'Kagal','',2,25),(1835,'Kalamb','',2,25),(1836,'Kalamnuri','',2,25),(1837,'Kalas','',2,25),(1838,'Kalmeshwar','',2,25),(1839,'Kalundri','',2,25),(1840,'Kalyan','',1,25),(1841,'Kamthi','',2,25),(1842,'Kandri','',2,25),(1843,'Kankauli','',2,25),(1844,'Kannad','',2,25),(1845,'Karad','',2,25),(1846,'Karanja','',2,25),(1847,'Karjat','',2,25),(1848,'Karmala','',2,25),(1849,'Kati','',2,25),(1850,'Katol','',2,25),(1851,'Khadki','',2,25),(1852,'Khamgaon','',2,25),(1853,'Khapa','',2,25),(1854,'Kharakvasla','',2,25),(1855,'Khed','',2,25),(1856,'Khetia','',2,25),(1857,'Khopoli','',2,25),(1858,'Khuldabad','',2,25),(1859,'Kinwat','',2,25),(1860,'Kodoli','',2,25),(1861,'Kolhapur','',1,25),(1862,'Kondalwadi','',2,25),(1863,'Kopargaon','',2,25),(1864,'Koradi','',2,25),(1865,'Koregaon','',2,25),(1866,'Koynanagar','',2,25),(1867,'Kudal','',2,25),(1868,'Kurandvad','',2,25),(1869,'Kurduvadi','',2,25),(1870,'Lanja','',2,25),(1871,'Lasalgaon','',2,25),(1872,'Latur','',2,25),(1873,'Lohogaon','',2,25),(1874,'Lonar','',2,25),(1875,'Lonavla','',2,25),(1876,'Mahabaleshwar','',2,25),(1877,'Mahad','',2,25),(1878,'Maindargi','',2,25),(1879,'Majalgaon','',2,25),(1880,'Makhjan','',2,25),(1881,'Malegaon','',2,25),(1882,'Malkapur','',2,25),(1883,'Malvan','',2,25),(1884,'Manchar','',2,25),(1885,'Mangrul Pir','',2,25),(1886,'Manmad','',2,25),(1887,'Manor','',2,25),(1888,'Mansar','',2,25),(1889,'Manwat','',2,25),(1890,'Matheran','',2,25),(1891,'Mehekar','',2,25),(1892,'Mhasla','',2,25),(1893,'Mhasvad','',2,25),(1894,'Mohpa','',2,25),(1895,'Moram','',2,25),(1896,'Morsi','',2,25),(1897,'Mowad','',2,25),(1898,'Mudkhed','',2,25),(1899,'Mukher','',2,25),(1900,'Mul','',2,25),(1901,'Mumbai','',2,25),(1902,'Mumbai Suburban','',2,25),(1903,'Murbad','',2,25),(1904,'Murgud','',2,25),(1905,'Murtajapur','',2,25),(1906,'Murud','',2,25),(1907,'Nagothana','',2,25),(1908,'Nagpur','',1,25),(1909,'Nagpur Division','',2,25),(1910,'Naldurg','',2,25),(1911,'Nanded','',2,25),(1912,'Nandgaon','',2,25),(1913,'Nandura Buzurg','',2,25),(1914,'Nandurbar','',2,25),(1915,'Nashik','',2,25),(1916,'Nashik Division','',2,25),(1917,'Navi Mumbai','',2,25),(1918,'Neral','',2,25),(1919,'Nilanga','',2,25),(1920,'Nipani','',2,25),(1921,'Osmanabad','',2,25),(1922,'Ozar','',2,25),(1923,'Pachora','',2,25),(1924,'Paithan','',2,25),(1925,'Palghar','',2,25),(1926,'Panchgani','',2,25),(1927,'Pandharpur','',2,25),(1928,'Panhala','',2,25),(1929,'Panvel','',2,25),(1930,'Parbhani','',2,25),(1931,'Parli Vaijnath','',2,25),(1932,'Parola','',2,25),(1933,'Partur','',2,25),(1934,'Patan','',2,25),(1935,'Pathardi','',2,25),(1936,'Pathri','',2,25),(1937,'Patur','',2,25),(1938,'Pawni','',2,25),(1939,'Pen','',2,25),(1940,'Phaltan','',2,25),(1941,'Pimpri','',2,25),(1942,'Pipri','',2,25),(1943,'Powai','',2,25),(1944,'Pulgaon','',2,25),(1945,'Pune','',1,25),(1946,'Pune Division','',2,25),(1947,'Purna','',2,25),(1948,'Pusad','',2,25),(1949,'Rahimatpur','',2,25),(1950,'Rahuri','',2,25),(1951,'Raigarh','',2,25),(1952,'Rajapur','',2,25),(1953,'Rajgurunagar','',2,25),(1954,'Rajur','',2,25),(1955,'Rajura','',2,25),(1956,'Ramtek','',2,25),(1957,'Ratnagiri','',2,25),(1958,'Raver','',2,25),(1959,'Revadanda','',2,25),(1960,'Risod','',2,25),(1961,'Roha','',2,25),(1962,'Sangamner','',2,25),(1963,'Sangli','',2,25),(1964,'Sangola','',2,25),(1965,'Saoner','',2,25),(1966,'Sasvad','',2,25),(1967,'Satana','',2,25),(1968,'Satara','',2,25),(1969,'Satara Division','',2,25),(1970,'Savantvadi','',2,25),(1971,'Savda','',2,25),(1972,'Selu','',2,25),(1973,'Shahada','',2,25),(1974,'Shahapur','',2,25),(1975,'Shegaon','',2,25),(1976,'Shiraguppi','',2,25),(1977,'Shirdi','',2,25),(1978,'Shirgaon','',2,25),(1979,'Shirpur','',2,25),(1980,'Shirwal','',2,25),(1981,'Shivaji Nagar','',2,25),(1982,'Shrigonda','',2,25),(1983,'Sillod','',2,25),(1984,'Sindhudurg','',2,25),(1985,'Sindi','',2,25),(1986,'Sinnar','',2,25),(1987,'Sirur','',2,25),(1988,'Solapur','',2,25),(1989,'Sonegaon','',2,25),(1990,'Soygaon','',2,25),(1991,'Srivardhan','',2,25),(1992,'Surgana','',2,25),(1993,'Talegaon Dabhade','',2,25),(1994,'Taloda','',2,25),(1995,'Tarapur','',2,25),(1996,'Tasgaon','',2,25),(1997,'Telhara','',2,25),(1998,'Thane','',1,25),(1999,'Trimbak','',2,25),(2000,'Tuljapur','',2,25),(2001,'Tumsar','',2,25),(2002,'Udgir','',2,25),(2003,'Ulhasnagar','',2,25),(2004,'Umarga','',2,25),(2005,'Umarkhed','',2,25),(2006,'Umred','',2,25),(2007,'Uran','',2,25),(2008,'Vada','',2,25),(2009,'Vaijapur','',2,25),(2010,'Varangaon','',2,25),(2011,'Vasind','',2,25),(2012,'Vengurla','',2,25),(2013,'Virar','',2,25),(2014,'Vite','',2,25),(2015,'Wadgaon','',2,25),(2016,'Wai','',2,25),(2017,'Wani','',2,25),(2018,'Wardha','',2,25),(2019,'Warora','',2,25),(2020,'Warud','',2,25),(2021,'Washim','',2,25),(2022,'Yaval','',2,25),(2023,'Yavatmal','',2,25),(2024,'Yeola','',2,25),(2025,'Bishnupur','',2,26),(2026,'Churachandpur','',2,26),(2027,'Imphal','',2,26),(2028,'Kakching','',2,26),(2029,'Mayang Imphal','',2,26),(2030,'Moirang','',2,26),(2031,'Phek','',2,26),(2032,'Senapati','',2,26),(2033,'Tamenglong','',2,26),(2034,'Thoubal','',2,26),(2035,'Ukhrul','',2,26),(2036,'Wangjing','',2,26),(2037,'Yairipok','',2,26),(2038,'Cherrapunji','',2,27),(2039,'East Garo Hills','',2,27),(2040,'East Jaintia Hills','',2,27),(2041,'East Khasi Hills','',2,27),(2042,'Mairang','',2,27),(2043,'Mankachar','',2,27),(2044,'Nongpoh','',2,27),(2045,'Nongstoin','',2,27),(2046,'North Garo Hills','',2,27),(2047,'Ri-Bhoi','',2,27),(2048,'Shillong','',2,27),(2049,'South Garo Hills','',2,27),(2050,'South West Garo Hills','',2,27),(2051,'South West Khasi Hills','',2,27),(2052,'Tura','',2,27),(2053,'West Garo Hills','',2,27),(2054,'West Jaintia Hills','',2,27),(2055,'West Khasi Hills','',2,27),(2056,'Aizawl','',2,28),(2057,'Champhai','',2,28),(2058,'Darlawn','',2,28),(2059,'Khawhai','',2,28),(2060,'Kolasib','',2,28),(2061,'Kolasib district','',2,28),(2062,'Lawngtlai','',2,28),(2063,'Lunglei','',2,28),(2064,'Mamit','',2,28),(2065,'North Vanlaiphai','',2,28),(2066,'Saiha','',2,28),(2067,'Sairang','',2,28),(2068,'Saitlaw','',2,28),(2069,'Serchhip','',2,28),(2070,'Thenzawl','',2,28),(2071,'Dimapur','',2,29),(2072,'Kohima','',2,29),(2073,'Mokokchung','',2,29),(2074,'Mon','',2,29),(2075,'Peren','',2,29),(2076,'Phek','',2,29),(2077,'Tuensang','',2,29),(2078,'Tuensang District','',2,29),(2079,'Wokha','',2,29),(2080,'Zunheboto','',2,29),(2081,'Angul','',2,30),(2082,'Angul District','',2,30),(2083,'Asika','',2,30),(2084,'Athagarh','',2,30),(2085,'Bada Barabil','',2,30),(2086,'Balangir','',2,30),(2087,'Balasore','',2,30),(2088,'Baleshwar','',2,30),(2089,'Balimila','',2,30),(2090,'Balugaon','',2,30),(2091,'Banapur','',2,30),(2092,'Banki','',2,30),(2093,'Banposh','',2,30),(2094,'Baragarh','',2,30),(2095,'Barbil','',2,30),(2096,'Bargarh','',2,30),(2097,'Barpali','',2,30),(2098,'Basudebpur','',2,30),(2099,'Baud','',2,30),(2100,'Baudh','',2,30),(2101,'Belaguntha','',2,30),(2102,'Bhadrak','',2,30),(2103,'Bhadrakh','',2,30),(2104,'Bhanjanagar','',2,30),(2105,'Bhawanipatna','',2,30),(2106,'Bhuban','',2,30),(2107,'Bhubaneshwar','',2,30),(2108,'Binka','',2,30),(2109,'Birmitrapur','',2,30),(2110,'Bolanikhodan','',2,30),(2111,'Brahmapur','',2,30),(2112,'Brajarajnagar','',2,30),(2113,'Buguda','',2,30),(2114,'Burla','',2,30),(2115,'Champua','',2,30),(2116,'Chandbali','',2,30),(2117,'Chatrapur','',2,30),(2118,'Chikitigarh','',2,30),(2119,'Chittarkonda','',2,30),(2120,'Cuttack','',2,30),(2121,'Daitari','',2,30),(2122,'Deogarh','',2,30),(2123,'Dhenkanal','',2,30),(2124,'Digapahandi','',2,30),(2125,'Gajapati','',2,30),(2126,'Ganjam','',2,30),(2127,'Gopalpur','',2,30),(2128,'Gudari','',2,30),(2129,'Gunupur','',2,30),(2130,'Hinjilikatu','',2,30),(2131,'Hirakud','',2,30),(2132,'Jagatsinghapur','',2,30),(2133,'Jagatsinghpur','',2,30),(2134,'Jajpur','',2,30),(2135,'Jaleshwar','',2,30),(2136,'Jatani','',2,30),(2137,'Jeypore','',2,30),(2138,'Jharsuguda','',2,30),(2139,'Jharsuguda District','',2,30),(2140,'Kaintragarh','',2,30),(2141,'Kalahandi','',2,30),(2142,'Kamakhyanagar','',2,30),(2143,'Kandhamal','',2,30),(2144,'Kantabanji','',2,30),(2145,'Kantilo','',2,30),(2146,'Kendrapara','',2,30),(2147,'Kendraparha','',2,30),(2148,'Kendujhar','',2,30),(2149,'Kesinga','',2,30),(2150,'Khallikot','',2,30),(2151,'Kharhial','',2,30),(2152,'Khordha','',2,30),(2153,'Khurda','',2,30),(2154,'Kiri Buru','',2,30),(2155,'Kodala','',2,30),(2156,'Konarka','',2,30),(2157,'Koraput','',2,30),(2158,'Kuchaiburi','',2,30),(2159,'Kuchinda','',2,30),(2160,'Malakanagiri','',2,30),(2161,'Malkangiri','',2,30),(2162,'Mayurbhanj','',2,30),(2163,'Nabarangpur','',2,30),(2164,'Nayagarh','',2,30),(2165,'Nayagarh District','',2,30),(2166,'Nilgiri','',2,30),(2167,'Nimaparha','',2,30),(2168,'Nowrangapur','',2,30),(2169,'Nuapada','',2,30),(2170,'Padampur','',2,30),(2171,'Paradip Garh','',2,30),(2172,'Patamundai','',2,30),(2173,'Patnagarh','',2,30),(2174,'Phulbani','',2,30),(2175,'Pipili','',2,30),(2176,'Polasara','',2,30),(2177,'Puri','',2,30),(2178,'Purushottampur','',2,30),(2179,'Rambha','',2,30),(2180,'Raurkela','',2,30),(2181,'Rayagada','',2,30),(2182,'Remuna','',2,30),(2183,'Rengali','',2,30),(2184,'Sambalpur','',2,30),(2185,'Sonepur','',2,30),(2186,'Sorada','',2,30),(2187,'Soro','',2,30),(2188,'Subarnapur','',2,30),(2189,'Sundargarh','',2,30),(2190,'Talcher','',2,30),(2191,'Tarabha','',2,30),(2192,'Titlagarh','',2,30),(2193,'Udayagiri','',2,30),(2194,'Karaikal','',2,31),(2195,'Mahe','',2,31),(2196,'Puducherry','',2,31),(2197,'Yanam','',2,31),(2198,'Abohar','',2,32),(2199,'Adampur','',2,32),(2200,'Ajitgarh','',2,32),(2201,'Ajnala','',2,32),(2202,'Akalgarh','',2,32),(2203,'Alawalpur','',2,32),(2204,'Amloh','',2,32),(2205,'Amritsar','',1,32),(2206,'Anandpur Sahib','',2,32),(2207,'Badhni Kalan','',2,32),(2208,'Bagha Purana','',2,32),(2209,'Bakloh','',2,32),(2210,'Balachor','',2,32),(2211,'Banga','',2,32),(2212,'Banur','',2,32),(2213,'Barnala','',2,32),(2214,'Batala','',2,32),(2215,'Begowal','',2,32),(2216,'Bhadaur','',2,32),(2217,'Bhatinda','',2,32),(2218,'Bhawanigarh','',2,32),(2219,'Bhikhi','',2,32),(2220,'Bhogpur','',2,32),(2221,'Bholath','',2,32),(2222,'Budhlada','',2,32),(2223,'Chima','',2,32),(2224,'Dasuya','',2,32),(2225,'Dera Baba Nanak','',2,32),(2226,'Dera Bassi','',2,32),(2227,'Dhanaula','',2,32),(2228,'Dhariwal','',2,32),(2229,'Dhilwan','',2,32),(2230,'Dhudi','',2,32),(2231,'Dhuri','',2,32),(2232,'Dina Nagar','',2,32),(2233,'Dirba','',2,32),(2234,'Doraha','',2,32),(2235,'Faridkot','',2,32),(2236,'Fatehgarh Churian','',2,32),(2237,'Fatehgarh Sahib','',2,32),(2238,'Fazilka','',2,32),(2239,'Firozpur','',2,32),(2240,'Firozpur District','',2,32),(2241,'Gardhiwala','',2,32),(2242,'Garhshankar','',2,32),(2243,'Ghanaur','',2,32),(2244,'Giddarbaha','',2,32),(2245,'Gurdaspur','',2,32),(2246,'Guru Har Sahai','',2,32),(2247,'Hajipur','',2,32),(2248,'Hariana','',2,32),(2249,'Hoshiarpur','',2,32),(2250,'Ishanpur','',2,32),(2251,'Jagraon','',2,32),(2252,'Jaito','',2,32),(2253,'Jalalabad','',2,32),(2254,'Jalandhar','',1,32),(2255,'Jandiala','',2,32),(2256,'Jandiala Guru','',2,32),(2257,'Kalanaur','',2,32),(2258,'Kapurthala','',2,32),(2259,'Kartarpur','',2,32),(2260,'Khamanon','',2,32),(2261,'Khanna','',2,32),(2262,'Kharar','',2,32),(2263,'Khemkaran','',2,32),(2264,'Kot Isa Khan','',2,32),(2265,'Kotkapura','',2,32),(2266,'Laungowal','',2,32),(2267,'Ludhiana','',1,32),(2268,'Machhiwara','',2,32),(2269,'Majitha','',2,32),(2270,'Makhu','',2,32),(2271,'Malaut','',2,32),(2272,'Malerkotla','',2,32),(2273,'Mansa','',2,32),(2274,'Maur Mandi','',2,32),(2275,'Moga','',2,32),(2276,'Mohali','',2,32),(2277,'Morinda','',2,32),(2278,'Mukerian','',2,32),(2279,'Nabha','',2,32),(2280,'Nakodar','',2,32),(2281,'Nangal','',2,32),(2282,'Nawanshahr','',2,32),(2283,'Nurmahal','',2,32),(2284,'Nurpur Kalan','',2,32),(2285,'Pathankot','',2,32),(2286,'Patiala','',2,32),(2287,'Patti','',2,32),(2288,'Phagwara','',2,32),(2289,'Phillaur','',2,32),(2290,'Qadian','',2,32),(2291,'Rahon','',2,32),(2292,'Raikot','',2,32),(2293,'Rajasansi','',2,32),(2294,'Rajpura','',2,32),(2295,'Ram Das','',2,32),(2296,'Rampura','',2,32),(2297,'Rupnagar','',2,32),(2298,'Samrala','',2,32),(2299,'Sanaur','',2,32),(2300,'Sangrur','',2,32),(2301,'Sardulgarh','',2,32),(2302,'Shahid Bhagat Singh Nagar','',2,32),(2303,'Shahkot','',2,32),(2304,'Sham Churasi','',2,32),(2305,'Sirhind-Fategarh','',2,32),(2306,'Sri Muktsar Sahib','',2,32),(2307,'Sultanpur Lodhi','',2,32),(2308,'Sunam','',2,32),(2309,'Talwandi Bhai','',2,32),(2310,'Talwara','',2,32),(2311,'Tarn Taran Sahib','',2,32),(2312,'Zira','',2,32),(2313,'Abhaneri','',2,33),(2314,'Abu','',2,33),(2315,'Abu Road','',2,33),(2316,'Ajmer','',2,33),(2317,'Aklera','',2,33),(2318,'Alwar','',2,33),(2319,'Amet','',2,33),(2320,'Anta','',2,33),(2321,'Anupgarh','',2,33),(2322,'Asind','',2,33),(2323,'Bagar','',2,33),(2324,'Bakani','',2,33),(2325,'Bali','',2,33),(2326,'Balotra','',2,33),(2327,'Bandikui','',2,33),(2328,'Banswara','',2,33),(2329,'Baran','',2,33),(2330,'Bari','',2,33),(2331,'Bari Sadri','',2,33),(2332,'Barmer','',2,33),(2333,'Basi','',2,33),(2334,'Basni','',2,33),(2335,'Baswa','',2,33),(2336,'Bayana','',2,33),(2337,'Beawar','',2,33),(2338,'Begun','',2,33),(2339,'Behror','',2,33),(2340,'Bhadasar','',2,33),(2341,'Bhadra','',2,33),(2342,'Bharatpur','',2,33),(2343,'Bhasawar','',2,33),(2344,'Bhilwara','',2,33),(2345,'Bhindar','',2,33),(2346,'Bhinmal','',2,33),(2347,'Bhiwadi','',2,33),(2348,'Bhuma','',2,33),(2349,'Bikaner','',1,33),(2350,'Bilara','',2,33),(2351,'Bissau','',2,33),(2352,'Borkhera','',2,33),(2353,'Bundi','',2,33),(2354,'Chaksu','',2,33),(2355,'Chechat','',2,33),(2356,'Chhabra','',2,33),(2357,'Chhapar','',2,33),(2358,'Chhoti Sadri','',2,33),(2359,'Chidawa','',2,33),(2360,'Chittaurgarh','',2,33),(2361,'Churu','',2,33),(2362,'Dariba','',2,33),(2363,'Dausa','',2,33),(2364,'Deoli','',2,33),(2365,'Deshnoke','',2,33),(2366,'Devgarh','',2,33),(2367,'Dhaulpur','',2,33),(2368,'Didwana','',2,33),(2369,'Dig','',2,33),(2370,'Dungarpur','',2,33),(2371,'Fatehpur','',2,33),(2372,'Galiakot','',2,33),(2373,'Ganganagar','',2,33),(2374,'Gangapur','',2,33),(2375,'Govindgarh','',2,33),(2376,'Gulabpura','',2,33),(2377,'Hanumangarh','',2,33),(2378,'Hindaun','',2,33),(2379,'Jahazpur','',2,33),(2380,'Jaipur','',2,33),(2381,'Jaisalmer','',2,33),(2382,'Jaitaran','',2,33),(2383,'Jalor','',2,33),(2384,'Jalore','',2,33),(2385,'Jhalawar','',2,33),(2386,'Jhalrapatan','',2,33),(2387,'Jhunjhunun','',2,33),(2388,'Jobner','',2,33),(2389,'Jodhpur','',1,33),(2390,'Kaman','',2,33),(2391,'Kanor','',2,33),(2392,'Kapren','',2,33),(2393,'Karanpur','',2,33),(2394,'Karauli','',2,33),(2395,'Kekri','',2,33),(2396,'Keshorai Patan','',2,33),(2397,'Khandela','',2,33),(2398,'Khanpur','',2,33),(2399,'Khetri','',2,33),(2400,'Kishangarh','',2,33),(2401,'Kota','',1,33),(2402,'Kotputli','',2,33),(2403,'Kuchaman','',2,33),(2404,'Kuchera','',2,33),(2405,'Kumher','',2,33),(2406,'Kushalgarh','',2,33),(2407,'Lachhmangarh Sikar','',2,33),(2408,'Ladnun','',2,33),(2409,'Lakheri','',2,33),(2410,'Lalsot','',2,33),(2411,'Losal','',2,33),(2412,'Mahwah','',2,33),(2413,'Makrana','',2,33),(2414,'Malpura','',2,33),(2415,'Mandal','',2,33),(2416,'Mandalgarh','',2,33),(2417,'Mandawar','',2,33),(2418,'Mangrol','',2,33),(2419,'Manohar Thana','',2,33),(2420,'Manoharpur','',2,33),(2421,'Meethari Marwar','',2,33),(2422,'Merta','',2,33),(2423,'Mundwa','',2,33),(2424,'Nadbai','',2,33),(2425,'Nagar','',2,33),(2426,'Nagaur','',2,33),(2427,'Nainwa','',2,33),(2428,'Napasar','',2,33),(2429,'Naraina','',2,33),(2430,'Nasirabad','',2,33),(2431,'Nathdwara','',2,33),(2432,'Nawa','',2,33),(2433,'Nawalgarh','',2,33),(2434,'Neem ka Thana','',2,33),(2435,'Nimaj','',2,33),(2436,'Nimbahera','',2,33),(2437,'Niwai','',2,33),(2438,'Nohar','',2,33),(2439,'Nokha','',2,33),(2440,'Padampur','',2,33),(2441,'Pali','',2,33),(2442,'Partapur','',2,33),(2443,'Parvatsar','',2,33),(2444,'Phalodi','',2,33),(2445,'Phulera','',2,33),(2446,'Pilani','',2,33),(2447,'Pilibangan','',2,33),(2448,'Pindwara','',2,33),(2449,'Pipar','',2,33),(2450,'Pirawa','',2,33),(2451,'Pokaran','',2,33),(2452,'Pratapgarh','',2,33),(2453,'Pushkar','',2,33),(2454,'Raipur','',2,33),(2455,'Raisinghnagar','',2,33),(2456,'Rajakhera','',2,33),(2457,'Rajaldesar','',2,33),(2458,'Rajgarh','',2,33),(2459,'Rajsamand','',2,33),(2460,'Ramganj Mandi','',2,33),(2461,'Ramgarh','',2,33),(2462,'Rani','',2,33),(2463,'Ratangarh','',2,33),(2464,'Rawatbhata','',2,33),(2465,'Rawatsar','',2,33),(2466,'Ringas','',2,33),(2467,'Sadri','',2,33),(2468,'Salumbar','',2,33),(2469,'Sambhar','',2,33),(2470,'Samdari','',2,33),(2471,'Sanchor','',2,33),(2472,'Sangaria','',2,33),(2473,'Sangod','',2,33),(2474,'Sardarshahr','',2,33),(2475,'Sarwar','',2,33),(2476,'Sawai Madhopur','',2,33),(2477,'Shahpura','',2,33),(2478,'Sheoganj','',2,33),(2479,'Sikar','',2,33),(2480,'Sirohi','',2,33),(2481,'Siwana','',2,33),(2482,'Sojat','',2,33),(2483,'Sri Dungargarh','',2,33),(2484,'Sri Madhopur','',2,33),(2485,'Sujangarh','',2,33),(2486,'Suket','',2,33),(2487,'Sunel','',2,33),(2488,'Surajgarh','',2,33),(2489,'Suratgarh','',2,33),(2490,'Takhatgarh','',2,33),(2491,'Taranagar','',2,33),(2492,'Tijara','',2,33),(2493,'Todabhim','',2,33),(2494,'Todaraisingh','',2,33),(2495,'Tonk','',2,33),(2496,'Udaipur','',2,33),(2497,'Udpura','',2,33),(2498,'Uniara','',2,33),(2499,'Wer','',2,33),(2500,'East District','',2,34),(2501,'Gangtok','',2,34),(2502,'Gyalshing','',2,34),(2503,'Jorethang','',2,34),(2504,'Mangan','',2,34),(2505,'Namchi','',2,34),(2506,'Naya Bazar','',2,34),(2507,'North District','',2,34),(2508,'Rangpo','',2,34),(2509,'Singtam','',2,34),(2510,'South District','',2,34),(2511,'West District','',2,34),(2512,'Abiramam','',2,35),(2513,'Adirampattinam','',2,35),(2514,'Aduthurai','',2,35),(2515,'Alagapuram','',2,35),(2516,'Alandur','',2,35),(2517,'Alanganallur','',2,35),(2518,'Alangayam','',2,35),(2519,'Alangudi','',2,35),(2520,'Alangulam','',2,35),(2521,'Alappakkam','',2,35),(2522,'Alwa Tirunagari','',2,35),(2523,'Ambasamudram','',2,35),(2524,'Ambattur','',2,35),(2525,'Ambur','',2,35),(2526,'Ammapettai','',2,35),(2527,'Anamalais','',2,35),(2528,'Andippatti','',2,35),(2529,'Annamalainagar','',2,35),(2530,'Annavasal','',2,35),(2531,'Annur','',2,35),(2532,'Anthiyur','',2,35),(2533,'Arakkonam','',2,35),(2534,'Arantangi','',2,35),(2535,'Arcot','',2,35),(2536,'Arimalam','',2,35),(2537,'Ariyalur','',2,35),(2538,'Arni','',2,35),(2539,'Arumbavur','',2,35),(2540,'Arumuganeri','',2,35),(2541,'Aruppukkottai','',2,35),(2542,'Aruvankad','',2,35),(2543,'Attayyampatti','',2,35),(2544,'Attur','',2,35),(2545,'Auroville','',2,35),(2546,'Avadi','',2,35),(2547,'Avinashi','',2,35),(2548,'Ayakudi','',2,35),(2549,'Ayyampettai','',2,35),(2550,'Belur','',2,35),(2551,'Bhavani','',2,35),(2552,'Bodinayakkanur','',2,35),(2553,'Chengam','',2,35),(2554,'Chennai','',2,35),(2555,'Chennimalai','',2,35),(2556,'Chetput','',2,35),(2557,'Chettipalaiyam','',2,35),(2558,'Cheyyar','',2,35),(2559,'Cheyyur','',2,35),(2560,'Chidambaram','',2,35),(2561,'Chingleput','',2,35),(2562,'Chinna Salem','',2,35),(2563,'Chinnamanur','',2,35),(2564,'Chinnasekkadu','',2,35),(2565,'Cholapuram','',2,35),(2566,'Coimbatore','',1,35),(2567,'Colachel','',2,35),(2568,'Cuddalore','',2,35),(2569,'Cumbum','',2,35),(2570,'Denkanikota','',2,35),(2571,'Desur','',2,35),(2572,'Devadanappatti','',2,35),(2573,'Devakottai','',2,35),(2574,'Dhali','',2,35),(2575,'Dharapuram','',2,35),(2576,'Dharmapuri','',2,35),(2577,'Dindigul','',2,35),(2578,'Dusi','',2,35),(2579,'Elayirampannai','',2,35),(2580,'Elumalai','',2,35),(2581,'Eral','',2,35),(2582,'Eraniel','',2,35),(2583,'Erode','',2,35),(2584,'Erumaippatti','',2,35),(2585,'Ettaiyapuram','',2,35),(2586,'Gandhi Nagar','',2,35),(2587,'Gangaikondan','',2,35),(2588,'Gangavalli','',2,35),(2589,'Gingee','',2,35),(2590,'Gobichettipalayam','',2,35),(2591,'Gudalur','',2,35),(2592,'Gudiyatham','',2,35),(2593,'Guduvancheri','',2,35),(2594,'Gummidipundi','',2,35),(2595,'Harur','',2,35),(2596,'Hosur','',2,35),(2597,'Idappadi','',2,35),(2598,'Ilampillai','',2,35),(2599,'Iluppur','',2,35),(2600,'Injambakkam','',2,35),(2601,'Irugur','',2,35),(2602,'Jalakandapuram','',2,35),(2603,'Jalarpet','',2,35),(2604,'Jayamkondacholapuram','',2,35),(2605,'Kadambur','',2,35),(2606,'Kadayanallur','',2,35),(2607,'Kalakkadu','',2,35),(2608,'Kalavai','',2,35),(2609,'Kallakkurichchi','',2,35),(2610,'Kallidaikurichi','',2,35),(2611,'Kallupatti','',2,35),(2612,'Kalugumalai','',2,35),(2613,'Kamuthi','',2,35),(2614,'Kanadukattan','',2,35),(2615,'Kancheepuram','',2,35),(2616,'Kanchipuram','',2,35),(2617,'Kangayam','',2,35),(2618,'Kanniyakumari','',2,35),(2619,'Karaikkudi','',2,35),(2620,'Karamadai','',2,35),(2621,'Karambakkudi','',2,35),(2622,'Kariapatti','',2,35),(2623,'Karumbakkam','',2,35),(2624,'Karur','',2,35),(2625,'Katpadi','',2,35),(2626,'Kattivakkam','',2,35),(2627,'Kattupputtur','',2,35),(2628,'Kaveripatnam','',2,35),(2629,'Kayalpattinam','',2,35),(2630,'Kayattar','',2,35),(2631,'Keelakarai','',2,35),(2632,'Kelamangalam','',2,35),(2633,'Kil Bhuvanagiri','',2,35),(2634,'Kilvelur','',2,35),(2635,'Kiranur','',2,35),(2636,'Kodaikanal','',2,35),(2637,'Kodumudi','',2,35),(2638,'Kombai','',2,35),(2639,'Konganapuram','',2,35),(2640,'Koothanallur','',2,35),(2641,'Koradachcheri','',2,35),(2642,'Korampallam','',2,35),(2643,'Kotagiri','',2,35),(2644,'Kottaiyur','',2,35),(2645,'Kovilpatti','',2,35),(2646,'Krishnagiri','',2,35),(2647,'Kulattur','',2,35),(2648,'Kulittalai','',2,35),(2649,'Kumaralingam','',2,35),(2650,'Kumbakonam','',2,35),(2651,'Kunnattur','',2,35),(2652,'Kurinjippadi','',2,35),(2653,'Kuttalam','',2,35),(2654,'Kuzhithurai','',2,35),(2655,'Lalgudi','',2,35),(2656,'Madambakkam','',2,35),(2657,'Madipakkam','',2,35),(2658,'Madukkarai','',2,35),(2659,'Madukkur','',2,35),(2660,'Madurai','',1,35),(2661,'Madurantakam','',2,35),(2662,'Mallapuram','',2,35),(2663,'Mallasamudram','',2,35),(2664,'Mallur','',2,35),(2665,'Manali','',2,35),(2666,'Manalurpettai','',2,35),(2667,'Manamadurai','',2,35),(2668,'Manappakkam','',2,35),(2669,'Manapparai','',2,35),(2670,'Manavalakurichi','',2,35),(2671,'Mandapam','',2,35),(2672,'Mangalam','',2,35),(2673,'Mannargudi','',2,35),(2674,'Marakkanam','',2,35),(2675,'Marandahalli','',2,35),(2676,'Masinigudi','',2,35),(2677,'Mattur','',2,35),(2678,'Mayiladuthurai','',2,35),(2679,'Melur','',2,35),(2680,'Mettupalayam','',2,35),(2681,'Mettuppalaiyam','',2,35),(2682,'Mettur','',2,35),(2683,'Minjur','',2,35),(2684,'Mohanur','',2,35),(2685,'Mudukulattur','',2,35),(2686,'Mulanur','',2,35),(2687,'Musiri','',2,35),(2688,'Muttupet','',2,35),(2689,'Naduvattam','',2,35),(2690,'Nagapattinam','',2,35),(2691,'Nagercoil','',2,35),(2692,'Namagiripettai','',2,35),(2693,'Namakkal','',2,35),(2694,'Nambiyur','',2,35),(2695,'Nambutalai','',2,35),(2696,'Nandambakkam','',2,35),(2697,'Nangavalli','',2,35),(2698,'Nangilickondan','',2,35),(2699,'Nanguneri','',2,35),(2700,'Nannilam','',2,35),(2701,'Naravarikuppam','',2,35),(2702,'Nattam','',2,35),(2703,'Nattarasankottai','',2,35),(2704,'Needamangalam','',2,35),(2705,'Neelankarai','',2,35),(2706,'Negapatam','',2,35),(2707,'Nellikkuppam','',2,35),(2708,'Nilakottai','',2,35),(2709,'Nilgiris','',2,35),(2710,'Odugattur','',2,35),(2711,'Omalur','',2,35),(2712,'Ooty','',2,35),(2713,'Padmanabhapuram','',2,35),(2714,'Palakkodu','',2,35),(2715,'Palamedu','',2,35),(2716,'Palani','',2,35),(2717,'Palavakkam','',2,35),(2718,'Palladam','',2,35),(2719,'Pallappatti','',2,35),(2720,'Pallattur','',2,35),(2721,'Pallavaram','',2,35),(2722,'Pallikondai','',2,35),(2723,'Pallipattu','',2,35),(2724,'Pallippatti','',2,35),(2725,'Panruti','',2,35),(2726,'Papanasam','',2,35),(2727,'Papireddippatti','',2,35),(2728,'Papparappatti','',2,35),(2729,'Paramagudi','',2,35),(2730,'Pattukkottai','',2,35),(2731,'Pennadam','',2,35),(2732,'Pennagaram','',2,35),(2733,'Pennathur','',2,35),(2734,'Peraiyur','',2,35),(2735,'Perambalur','',2,35),(2736,'Peranamallur','',2,35),(2737,'Peranampattu','',2,35),(2738,'Peravurani','',2,35),(2739,'Periyakulam','',2,35),(2740,'Periyanayakkanpalaiyam','',2,35),(2741,'Periyanegamam','',2,35),(2742,'Periyapatti','',2,35),(2743,'Periyapattinam','',2,35),(2744,'Perundurai','',2,35),(2745,'Perungudi','',2,35),(2746,'Perur','',2,35),(2747,'Pollachi','',2,35),(2748,'Polur','',2,35),(2749,'Ponnamaravati','',2,35),(2750,'Ponneri','',2,35),(2751,'Poonamalle','',2,35),(2752,'Porur','',2,35),(2753,'Pudukkottai','',2,35),(2754,'Puduppatti','',2,35),(2755,'Pudur','',2,35),(2756,'Puduvayal','',2,35),(2757,'Puliyangudi','',2,35),(2758,'Puliyur','',2,35),(2759,'Pullambadi','',2,35),(2760,'Punjai Puliyampatti','',2,35),(2761,'Rajapalaiyam','',2,35),(2762,'Ramanathapuram','',2,35),(2763,'Rameswaram','',2,35),(2764,'Rasipuram','',2,35),(2765,'Saint Thomas Mount','',2,35),(2766,'Salem','',1,35),(2767,'Sathankulam','',2,35),(2768,'Sathyamangalam','',2,35),(2769,'Sattur','',2,35),(2770,'Sayalkudi','',2,35),(2771,'Seven Pagodas','',2,35),(2772,'Sholinghur','',2,35),(2773,'Singanallur','',2,35),(2774,'Singapperumalkovil','',2,35),(2775,'Sirkazhi','',2,35),(2776,'Sirumugai','',2,35),(2777,'Sivaganga','',2,35),(2778,'Sivagiri','',2,35),(2779,'Sivakasi','',2,35),(2780,'Srimushnam','',2,35),(2781,'Sriperumbudur','',2,35),(2782,'Srivaikuntam','',2,35),(2783,'Srivilliputhur','',2,35),(2784,'Suchindram','',2,35),(2785,'Sulur','',2,35),(2786,'Surandai','',2,35),(2787,'Swamimalai','',2,35),(2788,'Tambaram','',2,35),(2789,'Tanjore','',2,35),(2790,'Taramangalam','',2,35),(2791,'Tattayyangarpettai','',2,35),(2792,'Teni','',2,35),(2793,'Thanjavur','',2,35),(2794,'Tharangambadi','',2,35),(2795,'Theni','',2,35),(2796,'Thenkasi','',2,35),(2797,'Thirukattupalli','',2,35),(2798,'Thiruthani','',2,35),(2799,'Thiruvaiyaru','',2,35),(2800,'Thiruvallur','',2,35),(2801,'Thiruvarur','',2,35),(2802,'Thiruvidaimaruthur','',2,35),(2803,'Thoothukkudi','',2,35),(2804,'Thoothukudi','',2,35),(2805,'Tindivanam','',2,35),(2806,'Tinnanur','',2,35),(2807,'Tiruchchendur','',2,35),(2808,'Tiruchengode','',2,35),(2809,'Tiruchirappalli','',2,35),(2810,'Tirukkoyilur','',2,35),(2811,'Tirumullaivasal','',2,35),(2812,'Tirunelveli','',2,35),(2813,'Tirunelveli Kattabo','',2,35),(2814,'Tiruppalaikudi','',2,35),(2815,'Tirupparangunram','',2,35),(2816,'Tiruppur','',2,35),(2817,'Tiruppuvanam','',2,35),(2818,'Tiruttangal','',2,35),(2819,'Tiruvallur','',2,35),(2820,'Tiruvannamalai','',2,35),(2821,'Tiruvottiyur','',2,35),(2822,'Tisaiyanvilai','',2,35),(2823,'Tondi','',2,35),(2824,'Turaiyur','',2,35),(2825,'Udangudi','',2,35),(2826,'Udumalaippettai','',2,35),(2827,'Uppiliyapuram','',2,35),(2828,'Usilampatti','',2,35),(2829,'Uttamapalaiyam','',2,35),(2830,'Uttiramerur','',2,35),(2831,'Uttukkuli','',2,35),(2832,'V.S.K.Valasai (Dindigul-Dist.)','',2,35),(2833,'Vadakku Valliyur','',2,35),(2834,'Vadakku Viravanallur','',2,35),(2835,'Vadamadurai','',2,35),(2836,'Vadippatti','',2,35),(2837,'Valangaiman','',2,35),(2838,'Valavanur','',2,35),(2839,'Vallam','',2,35),(2840,'Valparai','',2,35),(2841,'Vandalur','',2,35),(2842,'Vandavasi','',2,35),(2843,'Vaniyambadi','',2,35),(2844,'Vasudevanallur','',2,35),(2845,'Vattalkundu','',2,35),(2846,'Vedaraniyam','',2,35),(2847,'Vedasandur','',2,35),(2848,'Velankanni','',2,35),(2849,'Vellanur','',2,35),(2850,'Vellore','',2,35),(2851,'Velur','',2,35),(2852,'Vengavasal','',2,35),(2853,'Vettaikkaranpudur','',2,35),(2854,'Vettavalam','',2,35),(2855,'Vijayapuri','',2,35),(2856,'Vikravandi','',2,35),(2857,'Vilattikulam','',2,35),(2858,'Villupuram','',2,35),(2859,'Viraganur','',2,35),(2860,'Virudhunagar','',2,35),(2861,'Virudunagar','',2,35),(2862,'Vriddhachalam','',2,35),(2863,'Walajapet','',2,35),(2864,'Wallajahbad','',2,35),(2865,'Wellington','',2,35),(2866,'Adilabad','',2,36),(2867,'Alampur','',2,36),(2868,'Andol','',2,36),(2869,'Asifabad','',2,36),(2870,'Balapur','',2,36),(2871,'Banswada','',2,36),(2872,'Bellampalli','',2,36),(2873,'Bhadrachalam','',2,36),(2874,'Bhadradri Kothagudem','',2,36),(2875,'Bhaisa','',2,36),(2876,'Bhongir','',2,36),(2877,'Bodhan','',2,36),(2878,'Chandur','',2,36),(2879,'Chatakonda','',2,36),(2880,'Dasnapur','',2,36),(2881,'Devarkonda','',2,36),(2882,'Dornakal','',2,36),(2883,'Farrukhnagar','',2,36),(2884,'Gaddi Annaram','',2,36),(2885,'Gadwal','',2,36),(2886,'Ghatkesar','',2,36),(2887,'Gopalur','',2,36),(2888,'Gudur','',2,36),(2889,'Hyderabad','',2,36),(2890,'Jagitial','',2,36),(2891,'Jagtial','',2,36),(2892,'Jangaon','',2,36),(2893,'Jangoan','',2,36),(2894,'Jayashankar Bhupalapally','',2,36),(2895,'Jogulamba Gadwal','',2,36),(2896,'Kagaznagar','',2,36),(2897,'Kamareddi','',2,36),(2898,'Kamareddy','',2,36),(2899,'Karimnagar','',2,36),(2900,'Khammam','',2,36),(2901,'Kodar','',2,36),(2902,'Koratla','',2,36),(2903,'Kothapet','',2,36),(2904,'Kottagudem','',2,36),(2905,'Kottapalli','',2,36),(2906,'Kukatpalli','',2,36),(2907,'Kyathampalle','',2,36),(2908,'Lakshettipet','',2,36),(2909,'Lal Bahadur Nagar','',2,36),(2910,'Mahabubabad','',2,36),(2911,'Mahbubabad','',2,36),(2912,'Mahbubnagar','',2,36),(2913,'Malkajgiri','',2,36),(2914,'Mancheral','',2,36),(2915,'Mandamarri','',2,36),(2916,'Manthani','',2,36),(2917,'Manuguru','',2,36),(2918,'Medak','',2,36),(2919,'Medchal','',2,36),(2920,'Medchal Malkajgiri','',2,36),(2921,'Mirialguda','',2,36),(2922,'Nagar Karnul','',2,36),(2923,'Nalgonda','',2,36),(2924,'Narayanpet','',2,36),(2925,'Narsingi','',2,36),(2926,'Naspur','',2,36),(2927,'Nirmal','',2,36),(2928,'Nizamabad','',2,36),(2929,'Paloncha','',2,36),(2930,'Palwancha','',2,36),(2931,'Patancheru','',2,36),(2932,'Peddapalli','',2,36),(2933,'Quthbullapur','',2,36),(2934,'Rajanna Sircilla','',2,36),(2935,'Ramagundam','',2,36),(2936,'Ramgundam','',2,36),(2937,'Rangareddi','',2,36),(2938,'Sadaseopet','',2,36),(2939,'Sangareddi','',2,36),(2940,'Sathupalli','',2,36),(2941,'Secunderabad','',2,36),(2942,'Serilingampalle','',2,36),(2943,'Siddipet','',2,36),(2944,'Singapur','',2,36),(2945,'Sirpur','',2,36),(2946,'Sirsilla','',2,36),(2947,'Sriramnagar','',2,36),(2948,'Suriapet','',2,36),(2949,'Tandur','',2,36),(2950,'Uppal Kalan','',2,36),(2951,'Vemalwada','',2,36),(2952,'Vikarabad','',2,36),(2953,'Wanparti','',2,36),(2954,'Warangal','',2,36),(2955,'Yellandu','',2,36),(2956,'Zahirabad','',2,36),(2957,'Agartala','',2,37),(2958,'Amarpur','',2,37),(2959,'Ambasa','',2,37),(2960,'Barjala','',2,37),(2961,'Belonia','',2,37),(2962,'Dhalai','',2,37),(2963,'Dharmanagar','',2,37),(2964,'Gomati','',2,37),(2965,'Kailashahar','',2,37),(2966,'Kamalpur','',2,37),(2967,'Khowai','',2,37),(2968,'North Tripura','',2,37),(2969,'Ranir Bazar','',2,37),(2970,'Sabrum','',2,37),(2971,'Sonamura','',2,37),(2972,'South Tripura','',2,37),(2973,'Udaipur','',2,37),(2974,'Unakoti','',2,37),(2975,'West Tripura','',2,37),(2976,'Achhnera','',2,38),(2977,'Afzalgarh','',2,38),(2978,'Agra','',1,38),(2979,'Ahraura','',2,38),(2980,'Ajodhya','',2,38),(2981,'Akbarpur','',2,38),(2982,'Aliganj','',2,38),(2983,'Aligarh','',1,38),(2984,'Allahabad','',1,38),(2985,'Allahganj','',2,38),(2986,'Amanpur','',2,38),(2987,'Ambahta','',2,38),(2988,'Ambedkar Nagar','',2,38),(2989,'Amethi','',2,38),(2990,'Amroha','',2,38),(2991,'Anandnagar','',2,38),(2992,'Antu','',2,38),(2993,'Anupshahr','',2,38),(2994,'Aonla','',2,38),(2995,'Atarra','',2,38),(2996,'Atrauli','',2,38),(2997,'Atraulia','',2,38),(2998,'Auraiya','',2,38),(2999,'Auras','',2,38),(3000,'Azamgarh','',2,38),(3001,'Baberu','',2,38),(3002,'Babina','',2,38),(3003,'Babrala','',2,38),(3004,'Babugarh','',2,38),(3005,'Bachhraon','',2,38),(3006,'Bachhrawan','',2,38),(3007,'Baghpat','',2,38),(3008,'Bah','',2,38),(3009,'Baheri','',2,38),(3010,'Bahjoi','',2,38),(3011,'Bahraich','',2,38),(3012,'Bahraigh','',2,38),(3013,'Bahsuma','',2,38),(3014,'Bahua','',2,38),(3015,'Bajna','',2,38),(3016,'Bakewar','',2,38),(3017,'Baldev','',2,38),(3018,'Ballia','',2,38),(3019,'Balrampur','',2,38),(3020,'Banat','',2,38),(3021,'Banbasa','',2,38),(3022,'Banda','',2,38),(3023,'Bangarmau','',2,38),(3024,'Bansdih','',2,38),(3025,'Bansgaon','',2,38),(3026,'Bansi','',2,38),(3027,'Bara Banki','',2,38),(3028,'Baragaon','',2,38),(3029,'Baraut','',2,38),(3030,'Bareilly','',1,38),(3031,'Barkhera Kalan','',2,38),(3032,'Barsana','',2,38),(3033,'Basti','',2,38),(3034,'Behat','',2,38),(3035,'Bela','',2,38),(3036,'Beniganj','',2,38),(3037,'Beswan','',2,38),(3038,'Bewar','',2,38),(3039,'Bhadohi','',2,38),(3040,'Bhagwantnagar','',2,38),(3041,'Bharthana','',2,38),(3042,'Bharwari','',2,38),(3043,'Bhinga','',2,38),(3044,'Bhongaon','',2,38),(3045,'Bidhuna','',2,38),(3046,'Bighapur Khurd','',2,38),(3047,'Bijnor','',2,38),(3048,'Bikapur','',2,38),(3049,'Bilari','',2,38),(3050,'Bilariaganj','',2,38),(3051,'Bilaspur','',2,38),(3052,'Bilgram','',2,38),(3053,'Bilhaur','',2,38),(3054,'Bilsanda','',2,38),(3055,'Bilsi','',2,38),(3056,'Bilthra','',2,38),(3057,'Bindki','',2,38),(3058,'Bisalpur','',2,38),(3059,'Bisauli','',2,38),(3060,'Bisenda Buzurg','',2,38),(3061,'Bishunpur Urf Maharajganj','',2,38),(3062,'Biswan','',2,38),(3063,'Bithur','',2,38),(3064,'Budaun','',2,38),(3065,'Budhana','',2,38),(3066,'Bulandshahr','',2,38),(3067,'Captainganj','',2,38),(3068,'Chail','',2,38),(3069,'Chakia','',2,38),(3070,'Chandauli','',2,38),(3071,'Chandauli District','',2,38),(3072,'Chandpur','',2,38),(3073,'Chanduasi','',2,38),(3074,'Charkhari','',2,38),(3075,'Charthawal','',2,38),(3076,'Chhaprauli','',2,38),(3077,'Chharra','',2,38),(3078,'Chhata','',2,38),(3079,'Chhibramau','',2,38),(3080,'Chhutmalpur','',2,38),(3081,'Chillupar','',2,38),(3082,'Chirgaon','',2,38),(3083,'Chitrakoot','',2,38),(3084,'Chopan','',2,38),(3085,'Chunar','',2,38),(3086,'Colonelganj','',2,38),(3087,'Dadri','',2,38),(3088,'Dalmau','',2,38),(3089,'Dankaur','',2,38),(3090,'Dasna','',2,38),(3091,'Dataganj','',2,38),(3092,'Daurala','',2,38),(3093,'Dayal Bagh','',2,38),(3094,'Deoband','',2,38),(3095,'Deoranian','',2,38),(3096,'Deoria','',2,38),(3097,'Dewa','',2,38),(3098,'Dhampur','',2,38),(3099,'Dhanaura','',2,38),(3100,'Dhaurahra','',2,38),(3101,'Dibai','',2,38),(3102,'Dohrighat','',2,38),(3103,'Dostpur','',2,38),(3104,'Dudhi','',2,38),(3105,'Etah','',2,38),(3106,'Etawah','',2,38),(3107,'Faizabad','',2,38),(3108,'Farah','',2,38),(3109,'Faridnagar','',2,38),(3110,'Faridpur','',2,38),(3111,'Farrukhabad','',2,38),(3112,'Fatehabad','',2,38),(3113,'Fatehganj West','',2,38),(3114,'Fatehgarh','',2,38),(3115,'Fatehpur','',2,38),(3116,'Fatehpur Chaurasi','',2,38),(3117,'Fatehpur Sikri','',2,38),(3118,'Firozabad','',2,38),(3119,'Fyzabad','',2,38),(3120,'Gajraula','',2,38),(3121,'Gangoh','',2,38),(3122,'Ganj Dundwara','',2,38),(3123,'Ganj Muradabad','',2,38),(3124,'Garautha','',2,38),(3125,'Garhi Pukhta','',2,38),(3126,'Garhmuktesar','',2,38),(3127,'Gautam Buddha Nagar','',2,38),(3128,'Gawan','',2,38),(3129,'Ghatampur','',2,38),(3130,'Ghaziabad','',1,38),(3131,'Ghazipur','',2,38),(3132,'Ghiror','',2,38),(3133,'Ghorawal','',2,38),(3134,'Ghosi','',2,38),(3135,'Gohand','',2,38),(3136,'Gokul','',2,38),(3137,'Gola Bazar','',2,38),(3138,'Gola Gokarannath','',2,38),(3139,'Gonda','',2,38),(3140,'Gonda City','',2,38),(3141,'Gopamau','',2,38),(3142,'Gorakhpur','',1,38),(3143,'Goshainganj','',2,38),(3144,'Govardhan','',2,38),(3145,'Greater Noida','',2,38),(3146,'Gulaothi','',2,38),(3147,'Gunnaur','',2,38),(3148,'Gursahaiganj','',2,38),(3149,'Gursarai','',2,38),(3150,'Gyanpur','',2,38),(3151,'Haldaur','',2,38),(3152,'Hamirpur','',2,38),(3153,'Handia','',2,38),(3154,'Hapur','',2,38),(3155,'Haraiya','',2,38),(3156,'Hardoi','',2,38),(3157,'Harduaganj','',2,38),(3158,'Hasanpur','',2,38),(3159,'Hastinapur','',2,38),(3160,'Hata','',2,38),(3161,'Hathras','',2,38),(3162,'Iglas','',2,38),(3163,'Ikauna','',2,38),(3164,'Indergarh','',2,38),(3165,'Islamnagar','',2,38),(3166,'Itaunja','',2,38),(3167,'Itimadpur','',2,38),(3168,'Jagdishpur','',2,38),(3169,'Jagnair','',2,38),(3170,'Jahanabad','',2,38),(3171,'Jahangirabad','',2,38),(3172,'Jahangirpur','',2,38),(3173,'Jainpur','',2,38),(3174,'Jais','',2,38),(3175,'Jalalabad','',2,38),(3176,'Jalali','',2,38),(3177,'Jalalpur','',2,38),(3178,'Jalaun','',2,38),(3179,'Jalesar','',2,38),(3180,'Jansath','',2,38),(3181,'Jarwal','',2,38),(3182,'Jasrana','',2,38),(3183,'Jaswantnagar','',2,38),(3184,'Jaunpur','',2,38),(3185,'Jewar','',2,38),(3186,'Jhalu','',2,38),(3187,'Jhansi','',2,38),(3188,'Jhinjhak','',2,38),(3189,'Jhinjhana','',2,38),(3190,'Jhusi','',2,38),(3191,'Jyotiba Phule Nagar','',2,38),(3192,'Kabrai','',2,38),(3193,'Kachhwa','',2,38),(3194,'Kadaura','',2,38),(3195,'Kadipur','',2,38),(3196,'Kaimganj','',2,38),(3197,'Kairana','',2,38),(3198,'Kakori','',2,38),(3199,'Kakrala','',2,38),(3200,'Kalinagar','',2,38),(3201,'Kalpi','',2,38),(3202,'Kamalganj','',2,38),(3203,'Kampil','',2,38),(3204,'Kandhla','',2,38),(3205,'Kannauj','',2,38),(3206,'Kanpur','',1,38),(3207,'Kanpur Dehat','',2,38),(3208,'Kant','',2,38),(3209,'Kanth','',2,38),(3210,'Karari','',2,38),(3211,'Karhal','',2,38),(3212,'Kasganj','',2,38),(3213,'Katra','',2,38),(3214,'Kaushambi District','',2,38),(3215,'Kemri','',2,38),(3216,'Khada','',2,38),(3217,'Khaga','',2,38),(3218,'Khair','',2,38),(3219,'Khairabad','',2,38),(3220,'Khalilabad','',2,38),(3221,'Khanpur','',2,38),(3222,'Kharela','',2,38),(3223,'Khargupur','',2,38),(3224,'Kharkhauda','',2,38),(3225,'Khatauli','',2,38),(3226,'Khekra','',2,38),(3227,'Kheri','',2,38),(3228,'Khudaganj','',2,38),(3229,'Khurja','',2,38),(3230,'Khutar','',2,38),(3231,'Kirakat','',2,38),(3232,'Kiraoli','',2,38),(3233,'Kiratpur','',2,38),(3234,'Kishanpur','',2,38),(3235,'Kishni','',2,38),(3236,'Kithor','',2,38),(3237,'Konch','',2,38),(3238,'Kopaganj','',2,38),(3239,'Kosi','',2,38),(3240,'Kota','',1,38),(3241,'Kotra','',2,38),(3242,'Kulpahar','',2,38),(3243,'Kunda','',2,38),(3244,'Kundarkhi','',2,38),(3245,'Kurara','',2,38),(3246,'Kushinagar','',2,38),(3247,'Laharpur','',2,38),(3248,'Lakhimpur','',2,38),(3249,'Lakhna','',2,38),(3250,'Lalganj','',2,38),(3251,'Lalitpur','',2,38),(3252,'Lar','',2,38),(3253,'Lawar Khas','',2,38),(3254,'Loni','',2,38),(3255,'Lucknow','',2,38),(3256,'Lucknow District','',2,38),(3257,'Machhlishahr','',2,38),(3258,'Madhoganj','',2,38),(3259,'Madhogarh','',2,38),(3260,'Maghar','',2,38),(3261,'Mahaban','',2,38),(3262,'Maharaganj','',2,38),(3263,'Maharajganj','',2,38),(3264,'Mahmudabad','',2,38),(3265,'Mahoba','',2,38),(3266,'Maholi','',2,38),(3267,'Mahroni','',2,38),(3268,'Mailani','',2,38),(3269,'Mainpuri','',2,38),(3270,'Malihabad','',2,38),(3271,'Mandawar','',2,38),(3272,'Maniar','',2,38),(3273,'Manikpur','',2,38),(3274,'Manjhanpur','',2,38),(3275,'Mankapur','',2,38),(3276,'Marahra','',2,38),(3277,'Mariahu','',2,38),(3278,'Mataundh','',2,38),(3279,'Mathura','',2,38),(3280,'Mau','',2,38),(3281,'Mau Aimma','',2,38),(3282,'Maudaha','',2,38),(3283,'Mauranwan','',2,38),(3284,'Mawana','',2,38),(3285,'Meerut','',1,38),(3286,'Mehnagar','',2,38),(3287,'Mehndawal','',2,38),(3288,'Milak','',2,38),(3289,'Miranpur','',2,38),(3290,'Miranpur Katra','',2,38),(3291,'Mirganj','',2,38),(3292,'Mirzapur','',2,38),(3293,'Misrikh','',2,38),(3294,'Mohan','',2,38),(3295,'Mohanpur','',2,38),(3296,'Moradabad','',1,38),(3297,'Moth','',2,38),(3298,'Mubarakpur','',2,38),(3299,'Mughal Sarai','',2,38),(3300,'Muhammadabad','',2,38),(3301,'Muradnagar','',2,38),(3302,'Mursan','',2,38),(3303,'Musafir-Khana','',2,38),(3304,'Muzaffarnagar','',2,38),(3305,'Nadigaon','',2,38),(3306,'Nagina','',2,38),(3307,'Nagram','',2,38),(3308,'Najibabad','',2,38),(3309,'Nakur','',2,38),(3310,'Nanauta','',2,38),(3311,'Nandgaon','',2,38),(3312,'Nanpara','',2,38),(3313,'Narauli','',2,38),(3314,'Naraura','',2,38),(3315,'Nautanwa','',2,38),(3316,'Nawabganj','',2,38),(3317,'Nichlaul','',2,38),(3318,'Nihtaur','',2,38),(3319,'Niwari','',2,38),(3320,'Nizamabad','',2,38),(3321,'Noida','',2,38),(3322,'Nurpur','',2,38),(3323,'Obra','',2,38),(3324,'Orai','',2,38),(3325,'Oran','',2,38),(3326,'Pachperwa','',2,38),(3327,'Padrauna','',2,38),(3328,'Pahasu','',2,38),(3329,'Pali','',2,38),(3330,'Palia Kalan','',2,38),(3331,'Parichha','',2,38),(3332,'Parichhatgarh','',2,38),(3333,'Parshadepur','',2,38),(3334,'Patiali','',2,38),(3335,'Patti','',2,38),(3336,'Pawayan','',2,38),(3337,'Phalauda','',2,38),(3338,'Phaphund','',2,38),(3339,'Phariha','',2,38),(3340,'Phulpur','',2,38),(3341,'Pihani','',2,38),(3342,'Pilibhit','',2,38),(3343,'Pilkhua','',2,38),(3344,'Pinahat','',2,38),(3345,'Pipraich','',2,38),(3346,'Pratapgarh','',2,38),(3347,'Pukhrayan','',2,38),(3348,'Puranpur','',2,38),(3349,'Purwa','',2,38),(3350,'Rabupura','',2,38),(3351,'Radhakund','',2,38),(3352,'Rae Bareli','',2,38),(3353,'Raebareli','',2,38),(3354,'Rajapur','',2,38),(3355,'Ramkola','',2,38),(3356,'Ramnagar','',2,38),(3357,'Rampur','',2,38),(3358,'Rampura','',2,38),(3359,'Ranipur','',2,38),(3360,'Rasra','',2,38),(3361,'Rasulabad','',2,38),(3362,'Rath','',2,38),(3363,'Raya','',2,38),(3364,'Renukut','',2,38),(3365,'Reoti','',2,38),(3366,'Richha','',2,38),(3367,'Robertsganj','',2,38),(3368,'Rudarpur','',2,38),(3369,'Rura','',2,38),(3370,'Sadabad','',2,38),(3371,'Sadat','',2,38),(3372,'Safipur','',2,38),(3373,'Saharanpur','',2,38),(3374,'Sahaspur','',2,38),(3375,'Sahaswan','',2,38),(3376,'Sahawar','',2,38),(3377,'Saidpur','',2,38),(3378,'Sakit','',2,38),(3379,'Salon','',2,38),(3380,'Sambhal','',2,38),(3381,'Samthar','',2,38),(3382,'Sandi','',2,38),(3383,'Sandila','',2,38),(3384,'Sant Kabir Nagar','',2,38),(3385,'Sant Ravi Das Nagar','',2,38),(3386,'Sarai Akil','',2,38),(3387,'Sarai Ekdil','',2,38),(3388,'Sarai Mir','',2,38),(3389,'Sarauli','',2,38),(3390,'Sardhana','',2,38),(3391,'Sarila','',2,38),(3392,'Sasni','',2,38),(3393,'Satrikh','',2,38),(3394,'Saurikh','',2,38),(3395,'Sector','',2,38),(3396,'Seohara','',2,38),(3397,'Shahabad','',2,38),(3398,'Shahganj','',2,38),(3399,'Shahi','',2,38),(3400,'Shahjahanpur','',2,38),(3401,'Shahjanpur','',2,38),(3402,'Shahpur','',2,38),(3403,'Shamli','',2,38),(3404,'Shamsabad','',2,38),(3405,'Shankargarh','',2,38),(3406,'Shergarh','',2,38),(3407,'Sherkot','',2,38),(3408,'Shikarpur','',2,38),(3409,'Shikohabad','',2,38),(3410,'Shishgarh','',2,38),(3411,'Shrawasti','',2,38),(3412,'Siddharthnagar','',2,38),(3413,'Sidhauli','',2,38),(3414,'Sidhpura','',2,38),(3415,'Sikandarabad','',2,38),(3416,'Sikandarpur','',2,38),(3417,'Sikandra','',2,38),(3418,'Sikandra Rao','',2,38),(3419,'Sirathu','',2,38),(3420,'Sirsa','',2,38),(3421,'Sirsaganj','',2,38),(3422,'Sirsi','',2,38),(3423,'Sisauli','',2,38),(3424,'Siswa Bazar','',2,38),(3425,'Sitapur','',2,38),(3426,'Sonbhadra','',2,38),(3427,'Soron','',2,38),(3428,'Suar','',2,38),(3429,'Sultanpur','',2,38),(3430,'Surianwan','',2,38),(3431,'Tajpur','',2,38),(3432,'Talbahat','',2,38),(3433,'Talgram','',2,38),(3434,'Tanda','',2,38),(3435,'Thakurdwara','',2,38),(3436,'Thana Bhawan','',2,38),(3437,'Tikaitnagar','',2,38),(3438,'Tikri','',2,38),(3439,'Tilhar','',2,38),(3440,'Tindwari','',2,38),(3441,'Titron','',2,38),(3442,'Tori-Fatehpur','',2,38),(3443,'Tulsipur','',2,38),(3444,'Tundla','',2,38),(3445,'Ugu','',2,38),(3446,'Ujhani','',2,38),(3447,'Un','',2,38),(3448,'Unnao','',2,38),(3449,'Usehat','',2,38),(3450,'Utraula','',2,38),(3451,'Varanasi','',1,38),(3452,'Vrindavan','',2,38),(3453,'Wazirganj','',2,38),(3454,'Zafarabad','',2,38),(3455,'Zaidpur','',2,38),(3456,'Zamania','',2,38),(3457,'Almora','',2,39),(3458,'Bageshwar','',2,39),(3459,'Barkot','',2,39),(3460,'Bazpur','',2,39),(3461,'Bhim Tal','',2,39),(3462,'Bhowali','',2,39),(3463,'Birbhaddar','',2,39),(3464,'Chakrata','',2,39),(3465,'Chamoli','',2,39),(3466,'Champawat','',2,39),(3467,'Clement Town','',2,39),(3468,'Dehra Dun','',2,39),(3469,'Dehradun','',2,39),(3470,'Devaprayag','',2,39),(3471,'Dharchula','',2,39),(3472,'Doiwala','',2,39),(3473,'Dugadda','',2,39),(3474,'Dwarahat','',2,39),(3475,'Garhwal','',2,39),(3476,'Haldwani','',2,39),(3477,'Harbatpur','',2,39),(3478,'Haridwar','',2,39),(3479,'Jaspur','',2,39),(3480,'Joshimath','',2,39),(3481,'Kaladhungi','',2,39),(3482,'Kalagarh Project Colony','',2,39),(3483,'Kashipur','',2,39),(3484,'Khatima','',2,39),(3485,'Kichha','',2,39),(3486,'Kotdwara','',2,39),(3487,'Laksar','',2,39),(3488,'Lansdowne','',2,39),(3489,'Lohaghat','',2,39),(3490,'Manglaur','',2,39),(3491,'Mussoorie','',2,39),(3492,'Naini Tal','',2,39),(3493,'Narendranagar','',2,39),(3494,'Pauri','',2,39),(3495,'Pipalkoti','',2,39),(3496,'Pithoragarh','',2,39),(3497,'Raipur','',2,39),(3498,'Raiwala Bara','',2,39),(3499,'Ramnagar','',2,39),(3500,'Ranikhet','',2,39),(3501,'Rishikesh','',2,39),(3502,'Roorkee','',2,39),(3503,'Rudraprayag','',2,39),(3504,'Sitarganj','',2,39),(3505,'Srinagar','',2,39),(3506,'Sultanpur','',2,39),(3507,'Tanakpur','',2,39),(3508,'Tehri','',2,39),(3509,'Tehri-Garhwal','',2,39),(3510,'Udham Singh Nagar','',2,39),(3511,'Uttarkashi','',2,39),(3512,'Vikasnagar','',2,39),(3513,'Ahmedpur','',2,40),(3514,'Aistala','',2,40),(3515,'Aknapur','',2,40),(3516,'Alipur Duar','',2,40),(3517,'Alipurduar','',2,40),(3518,'Amlagora','',2,40),(3519,'Amta','',2,40),(3520,'Amtala','',2,40),(3521,'Andal','',2,40),(3522,'Arambagh community development block','',2,40),(3523,'Asansol','',1,40),(3524,'Ashoknagar Kalyangarh','',2,40),(3525,'Badkulla','',2,40),(3526,'Baduria','',2,40),(3527,'Bagdogra','',2,40),(3528,'Bagnan','',2,40),(3529,'Bagula','',2,40),(3530,'Bahula','',2,40),(3531,'Baidyabati','',2,40),(3532,'Bakreswar','',2,40),(3533,'Balarampur','',2,40),(3534,'Bali Chak','',2,40),(3535,'Bally','',2,40),(3536,'Balurghat','',2,40),(3537,'Bamangola community development block','',2,40),(3538,'Baneswar','',2,40),(3539,'Bangaon','',2,40),(3540,'Bankra','',2,40),(3541,'Bankura','',2,40),(3542,'Bansberia','',2,40),(3543,'Bansihari community development block','',2,40),(3544,'Barabazar','',2,40),(3545,'Baranagar','',2,40),(3546,'Barasat','',2,40),(3547,'Bardhaman','',2,40),(3548,'Barjora','',2,40),(3549,'Barrackpore','',2,40),(3550,'Baruipur','',2,40),(3551,'Basanti','',2,40),(3552,'Basirhat','',2,40),(3553,'Bawali','',2,40),(3554,'Begampur','',2,40),(3555,'Belda','',2,40),(3556,'Beldanga','',2,40),(3557,'Beliatore','',2,40),(3558,'Berhampore','',2,40),(3559,'Bhadreswar','',2,40),(3560,'Bhandardaha','',2,40),(3561,'Bhatpara','',2,40),(3562,'Birbhum district','',2,40),(3563,'Birpara','',2,40),(3564,'Bishnupur','',2,40),(3565,'Bolpur','',2,40),(3566,'Budge Budge','',2,40),(3567,'Canning','',2,40),(3568,'Chakapara','',2,40),(3569,'Chakdaha','',2,40),(3570,'Champadanga','',2,40),(3571,'Champahati','',2,40),(3572,'Champdani','',2,40),(3573,'Chandannagar','',2,40),(3574,'Chandrakona','',2,40),(3575,'Chittaranjan','',2,40),(3576,'Churulia','',2,40),(3577,'Contai','',2,40),(3578,'Cooch Behar','',2,40),(3579,'Cossimbazar','',2,40),(3580,'Dakshin Dinajpur district','',2,40),(3581,'Dalkola','',2,40),(3582,'Dam Dam','',2,40),(3583,'Darjeeling','',2,40),(3584,'Daulatpur','',2,40),(3585,'Debagram','',2,40),(3586,'Debipur','',2,40),(3587,'Dhaniakhali community development block','',2,40),(3588,'Dhulagari','',2,40),(3589,'Dhulian','',2,40),(3590,'Dhupguri','',2,40),(3591,'Diamond Harbour','',2,40),(3592,'Digha','',2,40),(3593,'Dinhata','',2,40),(3594,'Domjur','',2,40),(3595,'Dubrajpur','',2,40),(3596,'Durgapur','',1,40),(3597,'Egra','',2,40),(3598,'Falakata','',2,40),(3599,'Farakka','',2,40),(3600,'Fort Gloster','',2,40),(3601,'Gaighata community development block','',2,40),(3602,'Gairkata','',2,40),(3603,'Gangadharpur','',2,40),(3604,'Gangarampur','',2,40),(3605,'Garui','',2,40),(3606,'Garulia','',2,40),(3607,'Ghatal','',2,40),(3608,'Giria','',2,40),(3609,'Gobardanga','',2,40),(3610,'Gobindapur','',2,40),(3611,'Gopalpur','',2,40),(3612,'Gopinathpur','',2,40),(3613,'Gorubathan','',2,40),(3614,'Gosaba','',2,40),(3615,'Gosanimari','',2,40),(3616,'Gurdaha','',2,40),(3617,'Guskhara','',2,40),(3618,'Habra','',2,40),(3619,'Haldia','',2,40),(3620,'Haldibari','',2,40),(3621,'Halisahar','',2,40),(3622,'Harindanga','',2,40),(3623,'Haringhata','',2,40),(3624,'Haripur','',2,40),(3625,'Hasimara','',2,40),(3626,'Hindusthan Cables Town','',2,40),(3627,'Hooghly district','',2,40),(3628,'Howrah','',2,40),(3629,'Ichapur','',2,40),(3630,'Indpur community development block','',2,40),(3631,'Ingraj Bazar','',2,40),(3632,'Islampur','',2,40),(3633,'Jafarpur','',2,40),(3634,'Jaigaon','',2,40),(3635,'Jalpaiguri','',2,40),(3636,'Jamuria','',2,40),(3637,'Jangipur','',2,40),(3638,'Jaynagar Majilpur','',2,40),(3639,'Jejur','',2,40),(3640,'Jhalida','',2,40),(3641,'Jhargram','',2,40),(3642,'Jhilimili','',2,40),(3643,'Kakdwip','',2,40),(3644,'Kalaikunda','',2,40),(3645,'Kaliaganj','',2,40),(3646,'Kalimpong','',2,40),(3647,'Kalna','',2,40),(3648,'Kalyani','',2,40),(3649,'Kamarhati','',2,40),(3650,'Kamarpukur','',2,40),(3651,'Kanchrapara','',2,40),(3652,'Kandi','',2,40),(3653,'Karimpur','',2,40),(3654,'Katwa','',2,40),(3655,'Kenda','',2,40),(3656,'Keshabpur','',2,40),(3657,'Kharagpur','',2,40),(3658,'Kharar','',2,40),(3659,'Kharba','',2,40),(3660,'Khardaha','',2,40),(3661,'Khatra','',2,40),(3662,'Kirnahar','',2,40),(3663,'Kolkata','',2,40),(3664,'Konnagar','',2,40),(3665,'Krishnanagar','',2,40),(3666,'Krishnapur','',2,40),(3667,'Kshirpai','',2,40),(3668,'Kulpi','',2,40),(3669,'Kultali','',2,40),(3670,'Kulti','',2,40),(3671,'Kurseong','',2,40),(3672,'Lalgarh','',2,40),(3673,'Lalgola','',2,40),(3674,'Loyabad','',2,40),(3675,'Madanpur','',2,40),(3676,'Madhyamgram','',2,40),(3677,'Mahiari','',2,40),(3678,'Mahishadal community development block','',2,40),(3679,'Mainaguri','',2,40),(3680,'Manikpara','',2,40),(3681,'Masila','',2,40),(3682,'Mathabhanga','',2,40),(3683,'Matiali community development block','',2,40),(3684,'Matigara community development block','',2,40),(3685,'Medinipur','',2,40),(3686,'Mejia community development block','',2,40),(3687,'Memari','',2,40),(3688,'Mirik','',2,40),(3689,'Mohanpur community development block','',2,40),(3690,'Monoharpur','',2,40),(3691,'Muragacha','',2,40),(3692,'Muri','',2,40),(3693,'Murshidabad','',2,40),(3694,'Nabadwip','',2,40),(3695,'Nabagram','',2,40),(3696,'Nadia district','',2,40),(3697,'Nagarukhra','',2,40),(3698,'Nagrakata','',2,40),(3699,'Naihati','',2,40),(3700,'Naksalbari','',2,40),(3701,'Nalhati','',2,40),(3702,'Nalpur','',2,40),(3703,'Namkhana community development block','',2,40),(3704,'Nandigram','',2,40),(3705,'Nangi','',2,40),(3706,'Nayagram community development block','',2,40),(3707,'North 24 Parganas district','',2,40),(3708,'Odlabari','',2,40),(3709,'Paikpara','',2,40),(3710,'Panagarh','',2,40),(3711,'Panchla','',2,40),(3712,'Panchmura','',2,40),(3713,'Pandua','',2,40),(3714,'Panihati','',2,40),(3715,'Panskura','',2,40),(3716,'Parbatipur','',2,40),(3717,'Paschim Medinipur district','',2,40),(3718,'Patiram','',2,40),(3719,'Patrasaer','',2,40),(3720,'Patuli','',2,40),(3721,'Pujali','',2,40),(3722,'Puncha community development block','',2,40),(3723,'Purba Medinipur district','',2,40),(3724,'Purulia','',2,40),(3725,'Raghudebbati','',2,40),(3726,'Raghunathpur','',2,40),(3727,'Raiganj','',2,40),(3728,'Rajmahal','',2,40),(3729,'Rajnagar community development block','',2,40),(3730,'Ramchandrapur','',2,40),(3731,'Ramjibanpur','',2,40),(3732,'Ramnagar','',2,40),(3733,'Rampur Hat','',2,40),(3734,'Ranaghat','',2,40),(3735,'Raniganj','',2,40),(3736,'Raypur','',2,40),(3737,'Rishra','',2,40),(3738,'Sahapur','',2,40),(3739,'Sainthia','',2,40),(3740,'Salanpur community development block','',2,40),(3741,'Sankarpur','',2,40),(3742,'Sankrail','',2,40),(3743,'Santipur','',2,40),(3744,'Santoshpur','',2,40),(3745,'Santuri community development block','',2,40),(3746,'Sarenga','',2,40),(3747,'Serampore','',2,40),(3748,'Serpur','',2,40),(3749,'Shyamnagar, West Bengal','',2,40),(3750,'Siliguri','',2,40),(3751,'Singur','',2,40),(3752,'Sodpur','',2,40),(3753,'Solap','',2,40),(3754,'Sonada','',2,40),(3755,'Sonamukhi','',2,40),(3756,'Sonarpur community development block','',2,40),(3757,'South 24 Parganas district','',2,40),(3758,'Srikhanda','',2,40),(3759,'Srirampur','',2,40),(3760,'Suri','',2,40),(3761,'Swarupnagar community development block','',2,40),(3762,'Takdah','',2,40),(3763,'Taki','',2,40),(3764,'Tamluk','',2,40),(3765,'Tarakeswar','',2,40),(3766,'Titagarh','',2,40),(3767,'Tufanganj','',2,40),(3768,'Tulin','',2,40),(3769,'Uchalan','',2,40),(3770,'Ula','',2,40),(3771,'Uluberia','',2,40),(3772,'Uttar Dinajpur district','',2,40),(3773,'Uttarpara Kotrung','',2,40);
/*!40000 ALTER TABLE `master_data_citymaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_companyinformation`
--

DROP TABLE IF EXISTS `master_data_companyinformation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_companyinformation` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` longtext NOT NULL,
  `pincode` varchar(10) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `website` varchar(200) NOT NULL,
  `email_address` varchar(254) NOT NULL,
  `logo` varchar(100) DEFAULT NULL,
  `header` varchar(255) NOT NULL,
  `footer` varchar(255) NOT NULL,
  `signature` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_companyinformation_name_93861747_uniq` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_companyinformation`
--

LOCK TABLES `master_data_companyinformation` WRITE;
/*!40000 ALTER TABLE `master_data_companyinformation` DISABLE KEYS */;
INSERT INTO `master_data_companyinformation` VALUES (1,'Tata Steel Foundation','Test Address','380051','','','','','','',''),(2,'Company-2','','','','','','','','','');
/*!40000 ALTER TABLE `master_data_companyinformation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_conveyanceratemaster`
--

DROP TABLE IF EXISTS `master_data_conveyanceratemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_conveyanceratemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `conveyance_type` varchar(30) NOT NULL,
  `rate_per_km` decimal(6,2) NOT NULL,
  `max_distance_per_day` int DEFAULT NULL,
  `requires_receipt` tinyint(1) NOT NULL,
  `max_claim_amount` decimal(8,2) DEFAULT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_conveyancera_conveyance_type_effectiv_06cc7637_uniq` (`conveyance_type`,`effective_from`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_conveyanceratemaster`
--

LOCK TABLES `master_data_conveyanceratemaster` WRITE;
/*!40000 ALTER TABLE `master_data_conveyanceratemaster` DISABLE KEYS */;
INSERT INTO `master_data_conveyanceratemaster` VALUES (6,'taxi_with_receipt',0.00,NULL,1,NULL,'2025-12-31',NULL,1),(7,'taxi_without_receipt',15.00,NULL,0,NULL,'2025-12-31',NULL,1),(8,'own_vehicle',15.00,NULL,0,NULL,'2025-12-31',NULL,1),(9,'auto_rickshaw',0.00,NULL,0,NULL,'2025-12-31',NULL,1),(10,'public_transport',0.00,NULL,1,NULL,'2025-12-31',NULL,1);
/*!40000 ALTER TABLE `master_data_conveyanceratemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_countrymaster`
--

DROP TABLE IF EXISTS `master_data_countrymaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_countrymaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `country_name` varchar(100) NOT NULL,
  `country_code` varchar(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `country_name` (`country_name`),
  UNIQUE KEY `country_code` (`country_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_countrymaster`
--

LOCK TABLES `master_data_countrymaster` WRITE;
/*!40000 ALTER TABLE `master_data_countrymaster` DISABLE KEYS */;
INSERT INTO `master_data_countrymaster` VALUES (3,'India','IN');
/*!40000 ALTER TABLE `master_data_countrymaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_daincidentalmaster`
--

DROP TABLE IF EXISTS `master_data_daincidentalmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_daincidentalmaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `da_full_day` decimal(8,2) NOT NULL,
  `da_half_day` decimal(8,2) NOT NULL,
  `incidental_full_day` decimal(8,2) NOT NULL,
  `incidental_half_day` decimal(8,2) NOT NULL,
  `stay_allowance_category_a` decimal(8,2) NOT NULL,
  `stay_allowance_category_b` decimal(8,2) NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `city_category_id` bigint NOT NULL,
  `grade_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_daincidental_grade_id_city_category_i_82bd6ee1_uniq` (`grade_id`,`city_category_id`,`effective_from`),
  KEY `master_data_daincide_city_category_id_6bb018b3_fk_master_da` (`city_category_id`),
  KEY `master_data_grade_i_e33ee4_idx` (`grade_id`,`city_category_id`,`effective_from`),
  KEY `master_data_effecti_0b3518_idx` (`effective_from`,`effective_to`,`is_active`),
  CONSTRAINT `master_data_daincide_city_category_id_6bb018b3_fk_master_da` FOREIGN KEY (`city_category_id`) REFERENCES `master_data_citycategoriesmaster` (`id`),
  CONSTRAINT `master_data_daincide_grade_id_90c77cbb_fk_master_da` FOREIGN KEY (`grade_id`) REFERENCES `master_data_grademaster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_daincidentalmaster`
--

LOCK TABLES `master_data_daincidentalmaster` WRITE;
/*!40000 ALTER TABLE `master_data_daincidentalmaster` DISABLE KEYS */;
INSERT INTO `master_data_daincidentalmaster` VALUES (1,810.00,405.00,243.00,121.50,1800.00,1000.00,'2026-01-08',NULL,1,1,1),(2,648.00,324.00,243.00,121.50,1800.00,1000.00,'2026-01-08',NULL,1,2,1),(3,680.00,340.00,255.00,127.50,1800.00,1000.00,'2026-01-08',NULL,1,3,1),(4,810.00,405.00,243.00,121.50,1200.00,800.00,'2026-01-08',NULL,1,1,2),(5,648.00,324.00,243.00,121.50,1200.00,800.00,'2026-01-08',NULL,1,2,2),(6,680.00,340.00,255.00,127.50,1200.00,800.00,'2026-01-08',NULL,1,3,2),(7,810.00,405.00,243.00,121.50,1000.00,600.00,'2026-01-08',NULL,1,1,3),(8,648.00,324.00,243.00,121.50,1000.00,600.00,'2026-01-08',NULL,1,2,3),(9,680.00,340.00,255.00,127.50,1000.00,600.00,'2026-01-08',NULL,1,3,3),(10,810.00,405.00,243.00,121.50,1000.00,600.00,'2026-01-08',NULL,1,1,4),(11,648.00,324.00,243.00,121.50,1000.00,600.00,'2026-01-08',NULL,1,2,4),(12,680.00,340.00,255.00,127.50,1000.00,600.00,'2026-01-08',NULL,1,3,4),(13,729.00,364.50,162.00,81.00,1000.00,600.00,'2026-01-08',NULL,1,1,5),(14,648.00,324.00,162.00,81.00,1000.00,600.00,'2026-01-08',NULL,1,2,5),(15,680.00,340.00,170.00,85.00,1000.00,600.00,'2026-01-08',NULL,1,3,5);
/*!40000 ALTER TABLE `master_data_daincidentalmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_departmentmaster`
--

DROP TABLE IF EXISTS `master_data_departmentmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_departmentmaster` (
  `department_id` int NOT NULL AUTO_INCREMENT,
  `dept_name` varchar(255) NOT NULL,
  `dept_code` varchar(50) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `company_id` bigint NOT NULL,
  PRIMARY KEY (`department_id`),
  UNIQUE KEY `dept_name` (`dept_name`),
  UNIQUE KEY `dept_code` (`dept_code`),
  UNIQUE KEY `unique_department_name_per_company` (`company_id`,`dept_name`),
  UNIQUE KEY `unique_department_code_per_company` (`company_id`,`dept_code`),
  CONSTRAINT `master_data_departme_company_id_a7c394f2_fk_master_da` FOREIGN KEY (`company_id`) REFERENCES `master_data_companyinformation` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_departmentmaster`
--

LOCK TABLES `master_data_departmentmaster` WRITE;
/*!40000 ALTER TABLE `master_data_departmentmaster` DISABLE KEYS */;
INSERT INTO `master_data_departmentmaster` VALUES (1,'Digital and Analytics','DIGITAL AN',NULL,2),(2,'Tribal Culture','TRIBAL CUL',NULL,1),(3,'Public Health','PUBLIC HEA',NULL,2),(4,'CSR','CSR',NULL,2),(5,'Gender and Community Enterprises','GENDER AND',NULL,2),(6,'Agriculture Engineer','AGRICULTUR',NULL,2);
/*!40000 ALTER TABLE `master_data_departmentmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_designationmaster`
--

DROP TABLE IF EXISTS `master_data_designationmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_designationmaster` (
  `designation_id` int NOT NULL AUTO_INCREMENT,
  `designation_name` varchar(255) NOT NULL,
  `designation_code` varchar(50) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  PRIMARY KEY (`designation_id`),
  UNIQUE KEY `designation_name` (`designation_name`),
  UNIQUE KEY `designation_code` (`designation_code`),
  KEY `master_data_designat_department_id_737eb360_fk_master_da` (`department_id`),
  CONSTRAINT `master_data_designat_department_id_737eb360_fk_master_da` FOREIGN KEY (`department_id`) REFERENCES `master_data_departmentmaster` (`department_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_designationmaster`
--

LOCK TABLES `master_data_designationmaster` WRITE;
/*!40000 ALTER TABLE `master_data_designationmaster` DISABLE KEYS */;
INSERT INTO `master_data_designationmaster` VALUES (1,'Lead IT (Programs)','LEAD IT (P',NULL,NULL),(2,'Sr. Manager','SR. MANAGE',NULL,NULL),(3,'Sr.Manager','SR.MANAGER',NULL,NULL),(4,'Assistant Manager Pharmacist','ASSISTANT ',NULL,NULL),(5,'Head','HEAD',NULL,NULL),(6,'Chief','CHIEF',NULL,NULL),(7,'Lead','LEAD',NULL,NULL),(8,'Project Engineer','PROJECT EN',NULL,NULL);
/*!40000 ALTER TABLE `master_data_designationmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_employeetypemaster`
--

DROP TABLE IF EXISTS `master_data_employeetypemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_employeetypemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_employeetypemaster`
--

LOCK TABLES `master_data_employeetypemaster` WRITE;
/*!40000 ALTER TABLE `master_data_employeetypemaster` DISABLE KEYS */;
INSERT INTO `master_data_employeetypemaster` VALUES (1,'On-Roll','Permanent employee on company payroll'),(2,'Fixed-Term Contract','Fixed-term contractual employee'),(3,'Consultant','External consultant associated with organization'),(4,'Deputation','Employee on deputation from another organization'),(5,'Intern','Intern or trainee');
/*!40000 ALTER TABLE `master_data_employeetypemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_glcodemaster`
--

DROP TABLE IF EXISTS `master_data_glcodemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_glcodemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `vertical_name` varchar(100) NOT NULL,
  `description` longtext,
  `sorting_no` int unsigned DEFAULT NULL,
  `gl_code` varchar(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `short_description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gl_code` (`gl_code`),
  CONSTRAINT `master_data_glcodemaster_chk_1` CHECK ((`sorting_no` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=239 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_glcodemaster`
--

LOCK TABLES `master_data_glcodemaster` WRITE;
/*!40000 ALTER TABLE `master_data_glcodemaster` DISABLE KEYS */;
INSERT INTO `master_data_glcodemaster` VALUES (2,'Public Health (Static Clinics and E Health Centre)','Static Clinics and E Health Centre',2,'5020002',1,NULL),(3,'Agriculture (Water Harvesting structure)','Water Harvesting structure',3,'5030001',1,NULL),(4,'Drinking Water','Solar Powered Drinking Water project',1,'5010001',1,'Solar Powered Drinki'),(5,'Drinking Water','Installation of piped drinking water supply system',1,'5010003',1,'Installation of pipe'),(6,'Drinking Water','Installation and repair of deep bores',1,'5010004',1,'Installation and rep'),(7,'Drinking Water','Installation and repair of hand tube wells',1,'5010005',1,'Installation and rep'),(8,'Drinking Water','Supply of drinking water through tanker',1,'5010007',1,'Supply of drinking w'),(9,'Drinking Water','Other Sources of Drinking water',1,'5010008',1,'Other Sources of Dri'),(10,'Drinking Water','Solar Drinking Water',1,'5010009',1,'Solar Drinking Water'),(11,'Drinking Water','GenAdmin,HR,IT( DW)',1,'5010105',1,'GenAdmin,HR,IT( DW)'),(12,'Drinking Water','Drinking Water project - TSBSL',1,'5010501',1,'DW Project - TSBSL'),(13,'Drinking Water','HRDP-Drinking Water -HDFC',1,'5010502',1,'HRDP-Drinking Water'),(14,'Public Health','Healthcare infrastructure',1,'5020003',1,'Healthcare infrastru'),(15,'Public Health','HIV / AIDS',1,'5020004',1,'HIV / AIDS'),(16,'Public Health','MCH activities',1,'5020005',1,'MCH activities'),(17,'Public Health','Cataract',1,'5020006',1,'Cataract'),(18,'Public Health','Tribal healthcare initiative',1,'5020007',1,'Tribal healthcare in'),(19,'Public Health','Other Health Programe(malaria,SPARSH,Prev.,etc)',1,'5020008',1,'Other Health Program'),(20,'Public Health','Provide fin assist-waivers for needy, case-to-case',1,'5020009',1,'Provide fin assist-w'),(21,'Public Health','Mobile medical vans and ambulances',1,'5020010',1,'Mobile medical vans'),(22,'Public Health','Health Camps',1,'5020013',1,'Health Camps'),(23,'Public Health','Research in health',1,'5020014',1,'Research in health'),(24,'Public Health','JARMA & ARMAR',1,'5020015',1,'JARMA & ARMAR'),(25,'Public Health','Cancer Project',1,'5020017',1,'Cancer Project'),(26,'Public Health','MANSI PLUS - AIF Matching 65%',1,'5020018',1,'MANSI PLUS -AIF Matc'),(27,'Public Health','COVID 19',1,'5020019',1,'COVID 19'),(28,'Public Health','Tata Medica hospital Gopalpur',1,'5020020',1,'Gopalpur Hospital'),(29,'Public Health','Kitchen Garden (Health)',1,'5020021',1,'Kitchen Garden (H)'),(30,'Public Health','Prev.of Disabilities & School Health (Public Healt',1,'5020022',1,'Prev.of Disab.& Sch.'),(31,'Public Health','Prevention of Communicable Diseases & mitigating',1,'5020023',1,'Prev.Comm.Disa & mig'),(32,'Public Health','BCC and Health Promotion (Public Health)',1,'5020024',1,'BCC and Health Promo'),(33,'Public Health','Support in response to Govt./External request (Pub',1,'5020025',1,'Supp.in External Req'),(34,'Public Health','Public Health Initiatives in Proximate Communities',1,'5020026',1,'Public Health- Commu'),(35,'Public Health','Support to Under-privileged Community',1,'5020027',1,'Supp. to Unp. Commu'),(36,'Public Health','Screening and management of Congenital Heart Disea',1,'5020028',1,'Screening of Heart D'),(37,'Public Health','Non Communicable Diseases (NCD) Control Program',1,'5020029',1,'NCD Control Program'),(38,'Public Health','Mobile Public Health Unit mPHUs',1,'5020030',1,'Mobile Public Health'),(39,'Public Health','Comprehensive Community Eye Health Programme',1,'5020031',1,'Project DRISHTI'),(40,'Public Health','Rare & Neglected Congenital Diseases',1,'5020035',1,'Rare & Neglected Con'),(41,'Public Health','Project Poshan - A Nutrition Project',1,'5020036',1,'Project Poshan'),(42,'Public Health','Mansi  Plus - TSF - Self',1,'5020037',1,'Mansi Plus-TSF-Self'),(43,'Public Health','Basic Life Support - CPR Training',1,'5020038',1,'Basic Life Support'),(44,'Public Health','Mansi  Plus - Tata Steel Foundation- Salary - 65%',1,'5020039',1,'Mansi PlusTSF Sal-65'),(45,'Public Health','Mansi - Tata Steel Foundation- Salary- 100%',1,'5020040',1,'Mansi TSF Sal-100%'),(46,'Public Health','Mansi  Plus - TSF- Salary -65%',1,'5020041',1,'Mansi Sal- TSF -65%'),(47,'Public Health','Mansi  Plus - TSF Salary 100%',1,'5020042',1,'Mansi +TSF Sal 100%'),(48,'Public Health','Diya Project - Dev. Initiative for Youth and Adole',1,'5020043',1,'Diya Project'),(49,'Public Health','Mobile Cancer Screening Programme',1,'5020050',1,'Mobile Cancer Screen'),(50,'Public Health','Sanitation - Domestic Toilets',1,'5020201',1,'Sanitation - Domesti'),(51,'Public Health','Eradicating Poverty availing Govt. Schemes',1,'5020250',1,'Eradicating Poverty'),(52,'Public Health','Mansi - AIF',1,'5020501',1,'Mansi - AIF'),(53,'Public Health','RISHTA',1,'5020502',1,'RISHTA'),(54,'Public Health','Therapeutic Healing Garden - SSF',1,'5020503',1,'Therapeutic Healing'),(55,'Public Health','Mobility Intervention - HSBC',1,'5020504',1,'Mobility Interv.HSBC'),(56,'Public Health','Mansi  Plus - AIF- Salary 35%',1,'5020505',1,'Mansi Plus AIF-S-35%'),(57,'Agricultue','Agriculture Activities (Paddy & Dry Land crops)',1,'5030002',1,'Agriculture Activiti'),(58,'Agricultue','Promote second crops',1,'5030003',1,'Promote second crops'),(59,'Agricultue','Livelihd-Agri,Allied, Livo,Pisci,Tassr,Diary,Poult',1,'5030004',1,'Livelihd-Agri,Allied'),(60,'Agricultue','Capacity Building of Farmers Institutions',1,'5030005',1,'Capacity Building of'),(61,'Agricultue','Agri resource centers ,trng and info. centers',1,'5030006',1,'Agri resource center'),(62,'Agricultue','Enterprise Development Programmes',1,'5030007',1,'Enterprise Developme'),(63,'Agricultue','Promote horti in wastelands and dry land crops',1,'5030008',1,'Promote horti in was'),(64,'Agricultue','Kitchen Garden',1,'5030009',1,'Kitchen Garden'),(65,'Agricultue','Irrigation  Structures',1,'5030014',1,'Irrigation  Structur'),(66,'Agricultue','Watershed Projects',1,'5030015',1,'Watershed Projects'),(67,'Agricultue','Integrated Farming System',1,'5030016',1,'Inte. Farming System'),(68,'Agricultue','Livelihood Agri allied Tassr',1,'5030020',1,'Livel. Agri. Tassar'),(69,'Agricultue','Livelihood Infrastructure',1,'5030021',1,'Livelihood Infrastru'),(70,'Agricultue','ARUNIMA- Water conservation Intiative',1,'5030022',1,'ARUNIMA'),(71,'Agricultue','Dagdung Watershed-Matching Fund(TSF)',1,'5030023',1,'Dagdung Watershed-M'),(72,'Agricultue','Kuiani Watershed Project - Matching',1,'5030024',1,'Kuiani Watershed-M'),(73,'Agricultue','Integrated Watershed &Climate Proofing-SC',1,'5030025',1,'WS & CP - SC'),(74,'Agricultue','Formation & Strengthening of FPC',1,'5030026',1,'For & Str of FPC'),(75,'Agricultue','Birsa Rural Initiative for Sustainable Enterprise',1,'5030027',1,'Birsa - RISE'),(76,'Agricultue','Climate change Watershed Project - SC',1,'5030028',1,'C Change -WS-SC'),(77,'Agricultue','Potka watershed Projects - HDFC',1,'5030501',1,'Potka Watershed Proj'),(78,'Agricultue','Integrated Farming System - HDFC',1,'5030504',1,'Integrated Farming'),(79,'Agricultue','Formation of Farmer Producer Organisation - NABARD',1,'5030505',1,'Form.of FPO - NABARD'),(80,'Agricultue','Integ.MicroWS Mgt.Climate Proofing-Kalahandi-HDFC',1,'5030506',1,'HDFC -WS - Kalahandi'),(81,'Agricultue','Integ.MicroWS Mgt.Climate Proofing-Tundi-HDFC',1,'5030507',1,'HDFC -WS - Tundi'),(82,'Agricultue','Agri-Allied(Horti,IFS,Livestock,Crops)-CITI BANK',1,'5030508',1,'Agri-Allied-CITI Ban'),(83,'Agricultue','Const.Water Harvesting Structures -CITI BANK',1,'5030509',1,'WHS - CITI Bank'),(84,'Agricultue','HRDP-Agriculture-HDFC',1,'5030510',1,'HRDP-Agri-HDFC'),(85,'Agricultue','NRM & Income Enhancement Project - HDFC',1,'5030511',1,'NRM-IEP-HDFC'),(86,'Agricultue','Dungdung Watershed Project- NABARD',1,'5031001',1,'Dungdung Watershead'),(87,'Agricultue','Watershed Project Kuiani-NABARD',1,'5031002',1,'Watershed Proj Kuian'),(88,'Agricultue','Kuiani Watershed Project - Matching',1,'5031004',1,'Watershed Pro-Matchi'),(89,'Agricultue','Kukru Watershed project',1,'5031005',1,'Kukru Watershed proj'),(90,'Agricultue','Dungdung Watershed-Matching Fund(TSF)',1,'5031007',1,'Dungdung Watershead'),(91,'Agricultue','Watershed Project Dangdung -NABARD',1,'5031008',1,'NABARD W.P. Dangdung'),(92,'Agricultue','Watershed Project Kuiani-NABARD',1,'5031009',1,'NABARD W.P.Kuiani'),(93,'Skill Developemnt','Sponsorship to Trainees fr vocational courses',1,'5040001',1,'Sponsorship toTraine'),(94,'Skill Developemnt','Short term course fr Employment/Capacity building',1,'5040002',1,'STC fr Emp./Cap.buil'),(95,'Skill Developemnt','ITI Jagannathpur',1,'5040004',1,'ITI Jagannathpur'),(96,'Skill Developemnt','Tata Steel Technical Institute Burmamines',1,'5040005',1,'Tech.Inst.Burmamines'),(97,'Skill Developemnt','Multi Skill Center',1,'5040006',1,'Multi Skill Center'),(98,'Skill Developemnt','Support girls in Nursing training',1,'5040008',1,'Support girls in Nur'),(99,'Skill Developemnt','coaching  programmes',1,'5040009',1,'coaching  programmes'),(100,'Skill Developemnt','ITC Tamar',1,'5040010',1,'ITC Tamar'),(101,'Skill Developemnt','Model Career Center',1,'5040011',1,'Model Career Center'),(102,'Skill Developemnt','Entrepreneurship Development',1,'5040012',1,'Entrepreneurship Dev'),(103,'Skill Developemnt','Disability linked programmes',1,'5040013',1,'Disability programm'),(104,'Skill Developemnt','JN Tata Technical Education Center Gopalpur',1,'5040014',1,'JNTTEC Gopalpur'),(105,'Skill Developemnt','Contributor Intervention',1,'5040015',1,'Contributor Interven'),(106,'Skill Developemnt','Apparel Training',1,'5040016',1,'Apparel Training'),(107,'Skill Developemnt','Industrial Training Institute Chandil',1,'5040017',1,'ITI Chandil'),(108,'Skill Developemnt','TSF Skill Development center chaibasa',1,'5040018',1,'TSFSDC Chaibasa'),(109,'Skill Developemnt','Running of ITI Banspal',1,'5040019',1,'ITI Banspal'),(110,'Skill Developemnt','Skill Training Programme at Dharwad Karnatka',1,'5040020',1,'Skill Train. Prog.-K'),(111,'Skill Developemnt','Motor Driving Training',1,'5040021',1,'Motor Driving Traini'),(112,'Skill Developemnt','Kaushalyan Project - Class Room On Wheel',1,'5040022',1,'Kaushalyan Project'),(113,'Skill Developemnt','Support to Organisation working for PwDs',1,'5040023',1,'Supp. Org. for PwDs'),(114,'Skill Developemnt','RD Tata Technical Eduction Centre - Golmuri',1,'5040024',1,'RDTTEC-Golmuri'),(115,'Skill Developemnt','PM-Internship',1,'5041001',1,'PM-Internship'),(116,'Education','Pre-Matric Coaching',1,'5050001',1,'Pre-Matric Coaching'),(117,'Education','Fellowship programme',1,'5050002',1,'Fellowship programme'),(118,'Education','Support for Schools/Institutions (educational infr',1,'5050005',1,'Support for Schools/'),(119,'Education','Mid-Day meal to students',1,'5050006',1,'Mid-Day meals'),(120,'Education','Coaching for matric fail students',1,'5050007',1,'Coaching for matric'),(121,'Education','Learning Support Program - Ongoing',1,'5050008',1,'Learning Support Pro'),(122,'Education','Mast Ki Pathshala',1,'5050009',1,'Mast Ki Pathshala'),(123,'Education','Camp School',1,'5050010',1,'Camp School'),(124,'Education','Support to SC/ST students in education',1,'5050011',1,'Support to SC/ST stu'),(125,'Education','Support to SC/ST students in Higher education',1,'5050012',1,'Support to SC/ST stu'),(126,'Education','Spoken English & Soft Skill Dev. & Library initiat',1,'5050013',1,'Spoken English & Sof'),(127,'Education','ICT intervention in schools',1,'5050014',1,'ICT intervention in'),(128,'Education','Residential school for Tribals',1,'5050015',1,'Residential school f'),(129,'Education','Support to selected schools',1,'5050017',1,'Support to selected'),(130,'Education','Other Intervention Education (technology, pilots e',1,'5050018',1,'Other Intervention E'),(131,'Education','Quality secondary education Project',1,'5050020',1,'Quality secondary Ed'),(132,'Education','The Green School Project',1,'5050021',1,'Green School Project'),(133,'Education','Support to SC/ST Youths for Educational Coaching',1,'5050022',1,'Supp.ST/SC Edu Coach'),(134,'Education','Model School',1,'5050025',1,'Model school'),(135,'Education','MO School Project',1,'5050026',1,'MO School Project'),(136,'Education','support to EBS youth for education',1,'5050027',1,'supp. to EBS fr Edu'),(137,'Education','School Support Program and Youth Empowerment',1,'5050028',1,'Integrated Dev.(IDIA'),(138,'Education','Running Community Centre Libraries',1,'5050029',1,'Run. C C Libraries'),(139,'Education','Higher Secondary Coaching',1,'5050030',1,'High Secondery Coach'),(140,'Education','Mainstreaming BPL Children',1,'5050031',1,'Mainst BPL Child'),(141,'Education','Bridge Course - Learning Initiative',1,'5050032',1,'Bridge Cource'),(142,'Education','Centre for Equitable Learning',1,'5050033',1,'Centre f Equi. Learn'),(143,'Education','IISc (special commitment)',1,'5050034',1,'IISc (special commit'),(144,'Education','Education Project - TSBSL',1,'5050501',1,'Edu.Project - TSBSL'),(145,'Education','West Singbhum Education Program, Jharkhand - HDFC',1,'5050502',1,'WS Edu Prog - HDFC'),(146,'Education','Education Program - Odapada - Axis Bank',1,'5050503',1,'Edu-Odapada - Axis'),(147,'Education','West Singhbhum Education Project - HSBC',1,'5050506',1,'WS Edu.Project -HSBC'),(148,'Education','Collaboration for enabling social perspective-CESP',1,'5050507',1,'Enabling social pers'),(149,'Education','Quality Higher Education fr Youth - Axis',1,'5050508',1,'Quality Higher Edu-A'),(150,'Education','Education Signature Prog- Axis Dilse',1,'5050509',1,'Edu Sig-Axis Dilse'),(151,'Education','School Improv. Project -1000 Schools',1,'5051002',1,'School Imp.Project'),(152,'Rural Immersion','Rural Immersion Program',1,'5051003',1,'Rural Immersion Prog'),(153,'Gender & Community Enterprises','Women Empowerment Programmes',1,'5060001',1,'Women Empowerment Pr'),(154,'Gender & Community Enterprises','Business Development of SHGs',1,'5060002',1,'Business Development'),(155,'Gender & Community Enterprises','Youth Empowerment',1,'5060003',1,'Youth Empowerment'),(156,'Gender & Community Enterprises','Women Empowerment Programs - WEE Project',1,'5060004',1,'Women Emp. -WEE Pr.'),(157,'Gender & Community Enterprises','Mission Shakti',1,'5060005',1,'Mission Shakti'),(158,'Gender & Community Enterprises','Digital Literacy Program',1,'5060006',1,'Digital Literacy Pro'),(159,'Gender & Community Enterprises','Women Empowerment Programmes - TSBSL',1,'5060501',1,'Women Emp.Pr-TSBSL'),(160,'Gender & Community Enterprises','HRDP - Empowerment',1,'5060502',1,'HRDP - Emp.'),(161,'Enviornment','Plantation',1,'5070001',1,'Plantation'),(162,'Enviornment','Roof Rain Water Harvesting',1,'5070002',1,'Roof Rain Water Harv'),(163,'Enviornment','Renewable Energy (Solar Light)',1,'5070003',1,'Renewable Energy (So'),(164,'Enviornment','Protection of flora and fauna',1,'5070004',1,'Protection of flora'),(165,'Enviornment','Maintenance of parks and gardens',1,'5070005',1,'Maintenance of parks'),(166,'Enviornment','Naturenomics - Ecology is Economy',1,'5070007',1,'Naturenomics'),(167,'Enviornment','HRDP -Environment -HDFC',1,'5070501',1,'HRDP -Envir -HDFC'),(168,'Enviornment','Citi Bank N.A.-Energy for Progress',1,'5070502',1,'Citi B - Energy f Pr'),(169,'Tribal Identity','Tribal language and literature',1,'5080001',1,'Tribal language and'),(170,'Tribal Identity','Preserve & Promote Art and Culture',1,'5080002',1,'Preserve & Promote A'),(171,'Tribal Identity','Tribal Sports',1,'5080003',1,'Tribal Sports'),(172,'Tribal Identity','Soci economic development of PTG villagers',1,'5080005',1,'Soci economic develo'),(173,'Tribal Identity','Tribal Meet',1,'5080007',1,'Tribal Meet'),(174,'Tribal Identity','Stakeholder Meeting',1,'5080008',1,'Stakeholder Meeting'),(175,'Tribal Identity','Infrastructure Support',1,'5080009',1,'Infrastructure Suppo'),(176,'Tribal Identity','Tribal Identity',1,'5080010',1,'Tribal Identity'),(177,'Tribal Identity','Support to SC Community',1,'5080012',1,'Support to SC Commun'),(178,'Tribal Identity','Support to ST/SC org. for assets and amenities',1,'5080013',1,'Supp.ST/SC org.Asset'),(179,'Tribal Identity','Upkeep of Tribal Culture Center',1,'5080014',1,'Tribal Culture Centr'),(180,'Tribal Identity','Preserve & Pramote Literature,Art and Culture',1,'5080015',1,'P & P Lit.Art & Cult'),(181,'Tribal Identity','Johar Haat - Pramotion of Art,Culture & Cuisne',1,'5080016',1,'Johar Haat'),(182,'Tribal Identity','Tribal Culture Centre',1,'5080017',1,'Tribal Culture Centr'),(183,'Tribal Identity','Samvaad Ecosystem Elements',1,'5080018',1,'Samvaad Ecosystem'),(184,'Tribal Identity','Community Socio-Cultural Enhancement',1,'5080019',1,'Community Socio-Cult'),(185,'Tribal Identity','Tribal Music Centres',1,'5080020',1,'Tribal Music Centres'),(186,'Sports','Rural Sports',1,'5100001',1,'Rural Sports'),(187,'Sports','Support to Sportsman & associatons',1,'5100002',1,'Support to Sportsman'),(188,'Sports','Sports infrastructures',1,'5100004',1,'Sports infrastructur'),(189,'Sports','Organising sports tournaments and coaching camps',1,'5100005',1,'Organising sports to'),(190,'Sports','Running Sports Centers',1,'5100007',1,'Running Sports Cente'),(191,'Sports','Organising outdoor and leadership camps',1,'5100009',1,'Organising outdoor a'),(192,'Disaster Relief','Disaster Relief Management',1,'5110001',1,'Disaster Relief Mgt.'),(193,'Rural Development','Infrastructural support for Rural Development',1,'5130001',1,'Infrastructural supp'),(194,'Rural Development','Construction and maintenance of drain and roads',1,'5130002',1,'Construction and mai'),(195,'Rural Development','Community Safety Initiatives',1,'5130003',1,'Commu.Safety Initiat'),(196,'Rural Development','Water Harvesting Structure - Infra',1,'5130004',1,'Water Harvesting-Inf'),(197,'Rural Development','Development Corridor Project',1,'5135001',1,'Development Corridor'),(198,'Rural Development','Panchayat Governance and Fellowship',1,'5135002',1,'Panchayat Governance'),(199,'Rural Development','Technical Support Unit for Holistic Development',1,'5135003',1,'Tec.Sup.f Holistic D'),(200,'Common Support','Travelling Exp. (TA/DA to administrative staff)',1,'5140001',1,'Travelling Exp. (TA/'),(201,'Common Support','Meeting Exp(including get together ,retreats etc)',1,'5140002',1,'Meeting Exp(includin'),(202,'Common Support','Postage , Printing & Stationery',1,'5140003',1,'Postage , Printing &'),(203,'Common Support','Insurance, Rent & Taxes',1,'5140005',1,'Insurance, Rent & Ta'),(204,'Common Support','Legal Exp.',1,'5140006',1,'Legal Exp.'),(205,'Common Support','Audit Exp.',1,'5140007',1,'Audit Exp.'),(206,'Common Support','Telephone',1,'5140008',1,'Telephone'),(207,'Common Support','Staff Recruitment cost',1,'5140009',1,'Staff Recruitment co'),(208,'Common Support','Transportation-General',1,'5140010',1,'Transportation-Gener'),(209,'IT','I T Development Expenses',1,'5140011',1,'I T Development Expe'),(210,'Common Support','Communication (Common)',1,'5140012',1,'Communication (Commo'),(211,'Common Support','Administrative exp.',1,'5140013',1,'Administrative exp.'),(212,'Common Support','Power & Fuel',1,'5140015',1,'Power & Fuel'),(213,'Common Support','Advertisement',1,'5140016',1,'Advertisement'),(214,'Common Support','Transportation-General',1,'5140020',1,'Transportation-Gener'),(215,'Common Support','Volunteerism',1,'5140022',1,'Volunteerism'),(216,'Common Support','Office Maintenance Expenses',1,'5140202',1,'Office Maintenance'),(217,'Common Support','General Repair & Maintt. (including center maint.)',1,'5140203',1,'General Repair & Mai'),(218,'Safety','Safety Expenses',1,'5140204',1,'Safety Expenses'),(219,'TQM','Total Quality Management',1,'5140205',1,'Total Quality Mgt.'),(220,'Ethics','Admin Exp. for Ethics Program',1,'5140206',1,'Ethics - Admin Exp.'),(221,'Common Support','Services - Manpower Outsourcing',1,'5140307',1,'Services - Manpower'),(222,'Common Support','TSL Deputation Expenses',1,'5140308',1,'TSL Deputation Exp.'),(223,'Common Support','Freight Charges',1,'5140312',1,'Freight Charges'),(224,'Common Support','Capital Expenditure ( Assets)',1,'5140401',1,'Capital Expenditure'),(225,'Partnership','Partnership Management Expenses',1,'5140501',1,'Partnership Mgt. Exp'),(226,'Common Support','Admin- Urban Devlopment',1,'5140502',1,'Admin- Urban Devlop.'),(227,'Common Support','Impact Assessment of CSR programmes',1,'5140600',1,'Impact Assessment'),(228,'Employee Engagement','Shabasi Award',1,'5150001',1,'Shabasi Award'),(229,'Employee Engagement','Staff Training',1,'5150002',1,'Staff Training'),(230,'Employee Engagement','Medical exp. for staff',1,'5150003',1,'Medical exp. for sta'),(231,'Employee Engagement','Uniform',1,'5150004',1,'Uniform'),(232,'Employee Engagement','Scholarship - Employee ward',1,'5150005',1,'Scholarship - Employ'),(233,'Employee Engagement','Employee Engagement & Welfare Expenses',1,'5150006',1,'Emp.Eng.&Welfare Exp'),(234,'Employee Engagement','TSL Deputation Expenses',1,'5150105',1,'TSL Deputation Exp.'),(235,'Slum Area Development','Slum Area Development (Jaga Mission)',1,'5170001',1,'Slum Area Developmen'),(236,'Slum Area Development','Awareness Camp, Community fr various Social Issue',1,'5170002',1,'Awareness Program'),(237,'Slum Area Development','Youth Leadership Program',1,'5170003',1,'Youth Leadership'),(238,'Slum Area Development','Slum Development -Infrastructure',1,'5170004',1,'Slum Dev.-Infra');
/*!40000 ALTER TABLE `master_data_glcodemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_gradeentitlementmaster`
--

DROP TABLE IF EXISTS `master_data_gradeentitlementmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_gradeentitlementmaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `max_amount` decimal(10,2) DEFAULT NULL,
  `is_allowed` tinyint(1) NOT NULL,
  `city_category_id` bigint DEFAULT NULL,
  `grade_id` bigint NOT NULL,
  `sub_option_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_gradeentitle_grade_id_sub_option_id_c_d13fa6fd_uniq` (`grade_id`,`sub_option_id`,`city_category_id`),
  KEY `master_data_gradeent_city_category_id_60ae46dc_fk_master_da` (`city_category_id`),
  KEY `master_data_gradeent_sub_option_id_6a7185a8_fk_master_da` (`sub_option_id`),
  CONSTRAINT `master_data_gradeent_city_category_id_60ae46dc_fk_master_da` FOREIGN KEY (`city_category_id`) REFERENCES `master_data_citycategoriesmaster` (`id`),
  CONSTRAINT `master_data_gradeent_grade_id_58ed2622_fk_master_da` FOREIGN KEY (`grade_id`) REFERENCES `master_data_grademaster` (`id`),
  CONSTRAINT `master_data_gradeent_sub_option_id_6a7185a8_fk_master_da` FOREIGN KEY (`sub_option_id`) REFERENCES `master_data_travelsuboptionmaster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_gradeentitlementmaster`
--

LOCK TABLES `master_data_gradeentitlementmaster` WRITE;
/*!40000 ALTER TABLE `master_data_gradeentitlementmaster` DISABLE KEYS */;
INSERT INTO `master_data_gradeentitlementmaster` VALUES (1,NULL,1,NULL,1,1),(2,NULL,1,NULL,1,2),(3,NULL,1,NULL,1,3),(4,NULL,1,NULL,1,4),(5,NULL,1,NULL,1,5),(6,NULL,1,NULL,1,6),(7,NULL,1,NULL,1,7),(8,NULL,1,NULL,1,8),(9,NULL,1,NULL,2,1),(10,NULL,1,NULL,2,2),(11,NULL,1,NULL,2,3),(12,NULL,1,NULL,2,4),(13,NULL,1,NULL,2,5),(14,NULL,1,NULL,2,6),(15,NULL,1,NULL,2,7),(16,NULL,1,NULL,2,8),(17,NULL,1,NULL,3,1),(18,NULL,1,NULL,3,2),(19,NULL,1,NULL,3,3),(20,NULL,1,NULL,3,4),(21,NULL,1,NULL,3,5),(22,NULL,1,NULL,3,6),(23,NULL,1,NULL,3,7),(24,NULL,1,NULL,3,8),(25,NULL,1,NULL,4,1),(26,NULL,1,NULL,4,2),(27,NULL,1,NULL,4,3),(28,NULL,1,NULL,4,4),(29,NULL,1,NULL,4,5),(30,NULL,1,NULL,4,6),(31,NULL,1,NULL,4,7),(32,NULL,1,NULL,4,8),(33,NULL,1,NULL,5,1),(34,NULL,1,NULL,5,2),(35,NULL,1,NULL,5,3),(36,NULL,1,NULL,5,4),(37,NULL,1,NULL,5,5),(38,NULL,1,NULL,5,6),(39,NULL,1,NULL,5,7),(40,NULL,1,NULL,5,8),(71,7000.00,1,1,1,9),(72,7000.00,1,1,1,10),(73,7000.00,1,1,2,9),(74,7000.00,1,1,2,10),(77,1800.00,1,1,1,11),(78,1200.00,1,1,2,11),(79,5000.00,1,2,1,10),(80,5000.00,1,2,2,10),(81,5000.00,1,2,1,9),(82,5000.00,1,2,2,9),(83,1000.00,1,2,1,11),(84,800.00,1,2,2,11),(85,6500.00,1,1,3,9),(86,6500.00,1,1,3,10),(87,6500.00,1,1,4,9),(88,6500.00,1,1,4,10),(89,6500.00,1,1,5,9),(90,6500.00,1,1,5,10),(91,4000.00,1,2,3,9),(92,4000.00,1,2,4,9),(93,4000.00,1,2,5,9),(94,4000.00,1,2,3,10),(95,4000.00,1,2,4,10),(96,4000.00,1,2,5,10),(97,1000.00,1,1,3,11),(98,1000.00,1,1,4,11),(99,1000.00,1,1,5,11),(100,600.00,1,2,3,11),(101,600.00,1,2,4,11),(102,600.00,1,2,5,11),(103,NULL,1,NULL,1,12),(104,NULL,1,NULL,1,13);
/*!40000 ALTER TABLE `master_data_gradeentitlementmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_grademaster`
--

DROP TABLE IF EXISTS `master_data_grademaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_grademaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `sorting_no` int unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `glcode_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `master_data_grademas_glcode_id_7b0e660c_fk_master_da` (`glcode_id`),
  CONSTRAINT `master_data_grademas_glcode_id_7b0e660c_fk_master_da` FOREIGN KEY (`glcode_id`) REFERENCES `master_data_glcodemaster` (`id`),
  CONSTRAINT `master_data_grademaster_chk_1` CHECK ((`sorting_no` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_grademaster`
--

LOCK TABLES `master_data_grademaster` WRITE;
/*!40000 ALTER TABLE `master_data_grademaster` DISABLE KEYS */;
INSERT INTO `master_data_grademaster` VALUES (1,'B-2A','',1,1,NULL),(2,'B-2B','',2,1,NULL),(3,'B-3','',3,1,NULL),(4,'B-4A','',4,1,NULL),(5,'B-4B','',5,1,NULL),(6,'IL4','',6,1,NULL),(7,'IL2','',7,1,NULL);
/*!40000 ALTER TABLE `master_data_grademaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_guesthousemaster`
--

DROP TABLE IF EXISTS `master_data_guesthousemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_guesthousemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `property_type` varchar(30) DEFAULT NULL,
  `ownership_type` varchar(20) DEFAULT NULL,
  `gstin` varchar(15) NOT NULL,
  `registration_number` varchar(50) NOT NULL,
  `vendor_code` varchar(50) NOT NULL,
  `cost_center` varchar(50) NOT NULL,
  `rate_card` decimal(10,2) DEFAULT NULL,
  `billing_type` varchar(20) DEFAULT NULL,
  `address` longtext NOT NULL,
  `district` varchar(100) NOT NULL,
  `pin_code` varchar(10) DEFAULT NULL,
  `contact_person` varchar(100) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `email` varchar(254) DEFAULT NULL,
  `emergency_contact` varchar(100) NOT NULL,
  `total_rooms` int unsigned DEFAULT NULL,
  `room_types` json NOT NULL,
  `max_occupancy` int unsigned DEFAULT NULL,
  `amenities` json NOT NULL,
  `check_in_time` time(6) DEFAULT NULL,
  `check_out_time` time(6) DEFAULT NULL,
  `booking_window_days` int unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `city_id` bigint DEFAULT NULL,
  `country_id` bigint DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `gl_code_id` bigint DEFAULT NULL,
  `manager_id` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `state_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_data_guesthou_country_id_051da3f7_fk_master_da` (`country_id`),
  KEY `master_data_guesthou_created_by_id_be19a971_fk_authentic` (`created_by_id`),
  KEY `master_data_guesthou_gl_code_id_72f41780_fk_master_da` (`gl_code_id`),
  KEY `master_data_guesthou_manager_id_65202376_fk_authentic` (`manager_id`),
  KEY `master_data_guesthou_updated_by_id_309df758_fk_authentic` (`updated_by_id`),
  KEY `master_data_city_id_de5f65_idx` (`city_id`,`is_active`),
  KEY `master_data_state_i_fc6cd9_idx` (`state_id`,`city_id`),
  CONSTRAINT `master_data_guesthou_city_id_4d1e4e45_fk_master_da` FOREIGN KEY (`city_id`) REFERENCES `master_data_citymaster` (`id`),
  CONSTRAINT `master_data_guesthou_country_id_051da3f7_fk_master_da` FOREIGN KEY (`country_id`) REFERENCES `master_data_countrymaster` (`id`),
  CONSTRAINT `master_data_guesthou_created_by_id_be19a971_fk_authentic` FOREIGN KEY (`created_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `master_data_guesthou_gl_code_id_72f41780_fk_master_da` FOREIGN KEY (`gl_code_id`) REFERENCES `master_data_glcodemaster` (`id`),
  CONSTRAINT `master_data_guesthou_manager_id_65202376_fk_authentic` FOREIGN KEY (`manager_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `master_data_guesthou_state_id_f94a13e1_fk_master_da` FOREIGN KEY (`state_id`) REFERENCES `master_data_statemaster` (`id`),
  CONSTRAINT `master_data_guesthou_updated_by_id_309df758_fk_authentic` FOREIGN KEY (`updated_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `master_data_guesthousemaster_chk_1` CHECK ((`total_rooms` >= 0)),
  CONSTRAINT `master_data_guesthousemaster_chk_2` CHECK ((`max_occupancy` >= 0)),
  CONSTRAINT `master_data_guesthousemaster_chk_3` CHECK ((`booking_window_days` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_guesthousemaster`
--

LOCK TABLES `master_data_guesthousemaster` WRITE;
/*!40000 ALTER TABLE `master_data_guesthousemaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_guesthousemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_locationmaster`
--

DROP TABLE IF EXISTS `master_data_locationmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_locationmaster` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) NOT NULL,
  `location_code` varchar(10) NOT NULL,
  `address` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `city_id` bigint NOT NULL,
  `company_id` bigint NOT NULL,
  `country_id` bigint NOT NULL,
  `state_id` bigint NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_code` (`location_code`),
  UNIQUE KEY `master_data_locationmast_location_name_company_id_c628d692_uniq` (`location_name`,`company_id`),
  KEY `master_data_location_city_id_71f8e44e_fk_master_da` (`city_id`),
  KEY `master_data_location_company_id_ba0f4928_fk_master_da` (`company_id`),
  KEY `master_data_location_country_id_7a0dcce3_fk_master_da` (`country_id`),
  KEY `master_data_location_state_id_adadae5c_fk_master_da` (`state_id`),
  CONSTRAINT `master_data_location_city_id_71f8e44e_fk_master_da` FOREIGN KEY (`city_id`) REFERENCES `master_data_citymaster` (`id`),
  CONSTRAINT `master_data_location_company_id_ba0f4928_fk_master_da` FOREIGN KEY (`company_id`) REFERENCES `master_data_companyinformation` (`id`),
  CONSTRAINT `master_data_location_country_id_7a0dcce3_fk_master_da` FOREIGN KEY (`country_id`) REFERENCES `master_data_countrymaster` (`id`),
  CONSTRAINT `master_data_location_state_id_adadae5c_fk_master_da` FOREIGN KEY (`state_id`) REFERENCES `master_data_statemaster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_locationmaster`
--

LOCK TABLES `master_data_locationmaster` WRITE;
/*!40000 ALTER TABLE `master_data_locationmaster` DISABLE KEYS */;
INSERT INTO `master_data_locationmaster` VALUES (2,'Jamshedpur','JAMSHEDPUR','',1,1051,2,3,19);
/*!40000 ALTER TABLE `master_data_locationmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_locationspoc`
--

DROP TABLE IF EXISTS `master_data_locationspoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_locationspoc` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `spoc_type` varchar(20) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `backup_spoc_id` bigint DEFAULT NULL,
  `location_id` int NOT NULL,
  `spoc_user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_locationspoc_location_id_spoc_type_ce41c478_uniq` (`location_id`,`spoc_type`),
  KEY `master_data_location_backup_spoc_id_697b0014_fk_authentic` (`backup_spoc_id`),
  KEY `master_data_location_spoc_user_id_7025b0d5_fk_authentic` (`spoc_user_id`),
  KEY `master_data_locatio_e2f2d1_idx` (`location_id`,`spoc_type`,`is_active`),
  CONSTRAINT `master_data_location_backup_spoc_id_697b0014_fk_authentic` FOREIGN KEY (`backup_spoc_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `master_data_location_location_id_9024de53_fk_master_da` FOREIGN KEY (`location_id`) REFERENCES `master_data_locationmaster` (`location_id`),
  CONSTRAINT `master_data_location_spoc_user_id_7025b0d5_fk_authentic` FOREIGN KEY (`spoc_user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_locationspoc`
--

LOCK TABLES `master_data_locationspoc` WRITE;
/*!40000 ALTER TABLE `master_data_locationspoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_locationspoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_permissiontypemaster`
--

DROP TABLE IF EXISTS `master_data_permissiontypemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_permissiontypemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_permissiontypemaster`
--

LOCK TABLES `master_data_permissiontypemaster` WRITE;
/*!40000 ALTER TABLE `master_data_permissiontypemaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_permissiontypemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_statemaster`
--

DROP TABLE IF EXISTS `master_data_statemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_statemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `state_name` varchar(100) NOT NULL,
  `state_code` varchar(3) NOT NULL,
  `country_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_statemaster_state_name_country_id_1527f536_uniq` (`state_name`,`country_id`),
  KEY `master_data_statemas_country_id_cc51bc4b_fk_master_da` (`country_id`),
  CONSTRAINT `master_data_statemas_country_id_cc51bc4b_fk_master_da` FOREIGN KEY (`country_id`) REFERENCES `master_data_countrymaster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_statemaster`
--

LOCK TABLES `master_data_statemaster` WRITE;
/*!40000 ALTER TABLE `master_data_statemaster` DISABLE KEYS */;
INSERT INTO `master_data_statemaster` VALUES (4,'Andaman and Nicobar Islands','',3),(5,'Andhra Pradesh','',3),(6,'Arunachal Pradesh','',3),(7,'Assam','',3),(8,'Bihar','',3),(9,'Chandigarh','',3),(10,'Chhattisgarh','',3),(11,'Dadra and Nagar Haveli','',3),(12,'Daman and Diu','',3),(13,'Delhi','',3),(14,'Goa','',3),(15,'Gujarat','',3),(16,'Haryana','',3),(17,'Himachal Pradesh','',3),(18,'Jammu and Kashmir','',3),(19,'Jharkhand','',3),(20,'Karnataka','',3),(21,'Kerala','',3),(22,'Ladakh','',3),(23,'Lakshadweep','',3),(24,'Madhya Pradesh','',3),(25,'Maharashtra','',3),(26,'Manipur','',3),(27,'Meghalaya','',3),(28,'Mizoram','',3),(29,'Nagaland','',3),(30,'Odisha','',3),(31,'Puducherry','',3),(32,'Punjab','',3),(33,'Rajasthan','',3),(34,'Sikkim','',3),(35,'Tamil Nadu','',3),(36,'Telangana','',3),(37,'Tripura','',3),(38,'Uttar Pradesh','',3),(39,'Uttarakhand','',3),(40,'West Bengal','',3);
/*!40000 ALTER TABLE `master_data_statemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_travelmodemaster`
--

DROP TABLE IF EXISTS `master_data_travelmodemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_travelmodemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` longtext,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_travelmodemaster`
--

LOCK TABLES `master_data_travelmodemaster` WRITE;
/*!40000 ALTER TABLE `master_data_travelmodemaster` DISABLE KEYS */;
INSERT INTO `master_data_travelmodemaster` VALUES (1,'Flight','Flight',1),(2,'Train','Train',1),(3,'Pick-up and Drop','Pick-up and Drop',1),(4,'Radio Taxi','Radio Taxi',1),(5,'Car at Disposal','Car at Disposal',1),(6,'Own Car','Own Car',1),(7,'Accommodation','Accommodation',1);
/*!40000 ALTER TABLE `master_data_travelmodemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_travelpolicymaster`
--

DROP TABLE IF EXISTS `master_data_travelpolicymaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_travelpolicymaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `policy_type` varchar(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `rule_parameters` json NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `effective_from` date NOT NULL,
  `effective_to` date DEFAULT NULL,
  `employee_grade_id` bigint DEFAULT NULL,
  `travel_mode_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `master_data_travelpo_employee_grade_id_9e14ed68_fk_master_da` (`employee_grade_id`),
  KEY `master_data_travelpo_travel_mode_id_f48cda3b_fk_master_da` (`travel_mode_id`),
  KEY `master_data_policy__4e965f_idx` (`policy_type`,`is_active`),
  KEY `master_data_effecti_6148ea_idx` (`effective_from`,`effective_to`),
  CONSTRAINT `master_data_travelpo_employee_grade_id_9e14ed68_fk_master_da` FOREIGN KEY (`employee_grade_id`) REFERENCES `master_data_grademaster` (`id`),
  CONSTRAINT `master_data_travelpo_travel_mode_id_f48cda3b_fk_master_da` FOREIGN KEY (`travel_mode_id`) REFERENCES `master_data_travelmodemaster` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_travelpolicymaster`
--

LOCK TABLES `master_data_travelpolicymaster` WRITE;
/*!40000 ALTER TABLE `master_data_travelpolicymaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_travelpolicymaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_travelsuboptionmaster`
--

DROP TABLE IF EXISTS `master_data_travelsuboptionmaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_travelsuboptionmaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` longtext,
  `is_active` tinyint(1) NOT NULL,
  `mode_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `master_data_travelsuboptionmaster_mode_id_name_166d4d2a_uniq` (`mode_id`,`name`),
  CONSTRAINT `master_data_travelsu_mode_id_7c6c1737_fk_master_da` FOREIGN KEY (`mode_id`) REFERENCES `master_data_travelmodemaster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_travelsuboptionmaster`
--

LOCK TABLES `master_data_travelsuboptionmaster` WRITE;
/*!40000 ALTER TABLE `master_data_travelsuboptionmaster` DISABLE KEYS */;
INSERT INTO `master_data_travelsuboptionmaster` VALUES (1,'Economy Class','Economy Class for Flight',1,1),(2,'1st AC','1st AC for Train',1,2),(3,'2nd AC','2nd AC for Train',1,2),(4,'Pick-up/Drop Only','Pick-up/Drop Only for Pick-up and Drop',1,3),(5,'Radio Taxi','Radio Taxi for Radio Taxi',1,4),(6,'Company Arranged Car','Company Arranged Car for Car at Disposal',1,5),(7,'Self-Arranged','Car at Disposal for Self-Arranged Vehicle',1,5),(8,'Own Car','Own Car for Personal Car',1,6),(9,'Guest House','Guest House for Accommodation',1,7),(10,'Company-tied Hotel','Company-tied Hotel for Accommodation',1,7),(11,'Self-arranged Stay','Self-arranged Stay for Accommodation',1,7),(12,'Executive Chair Car','Executive Chair Car',1,2),(13,'Chair Car','Chair Car',1,2);
/*!40000 ALTER TABLE `master_data_travelsuboptionmaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_vehicletypemaster`
--

DROP TABLE IF EXISTS `master_data_vehicletypemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `master_data_vehicletypemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `capacity` int NOT NULL,
  `rate_per_km` decimal(8,2) DEFAULT NULL,
  `rate_per_day` decimal(8,2) DEFAULT NULL,
  `minimum_charge` decimal(8,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_vehicletypemaster`
--

LOCK TABLES `master_data_vehicletypemaster` WRITE;
/*!40000 ALTER TABLE `master_data_vehicletypemaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_vehicletypemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications_emailtemplatemaster`
--

DROP TABLE IF EXISTS `notifications_emailtemplatemaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications_emailtemplatemaster` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `body_html` longtext NOT NULL,
  `body_text` longtext,
  `cc_emails` json NOT NULL,
  `bcc_emails` json NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `template_key` varchar(150) NOT NULL,
  `template_name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_key` (`template_key`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_emailtemplatemaster`
--

LOCK TABLES `notifications_emailtemplatemaster` WRITE;
/*!40000 ALTER TABLE `notifications_emailtemplatemaster` DISABLE KEYS */;
INSERT INTO `notifications_emailtemplatemaster` VALUES (14,'Cancellation Request for Travel Application ??? {{ request_id }}','<p>Dear {{ approver_name }},</p>\n<p><strong>{{ employee_name }}</strong> has submitted a request to cancel their approved travel application.</p>\n<p><strong>Request ID:</strong> {{ request_id }}</p>\n<p><strong>Purpose:</strong> {{ purpose }}</p>\n<p><strong>Travel Dates:</strong> {{ travel_dates }}</p>\n<p><strong>Cancellation Reason:</strong> {{ cancellation_reason }}</p>\n<p>Please log in to the Travel Management System to review this cancellation request and approve or reject it.</p>\n<p>Thank you,<br>Travel Management System</p>','Dear {{ approver_name }}, {{ employee_name }} has requested to cancel travel application {{ request_id }}. Reason: {{ cancellation_reason }}. Please review and take action.','[]','[]',1,'2025-12-31 05:25:25.134374','2025-12-31 05:25:25.134401','travel.cancellation.requested','Travel Cancellation Request Submitted'),(15,'Your Travel Cancellation Has Been Approved ??? {{ request_id }}','<p>Dear {{ employee_name }},</p>\n<p>Your cancellation request for travel application <strong>{{ request_id }}</strong> has been <strong>approved</strong> by {{ approver_name }}.</p>\n<p><strong>Purpose:</strong> {{ purpose }}</p>\n<p><strong>Travel Dates:</strong> {{ travel_dates }}</p>\n<p><strong>Approver Notes:</strong> {{ notes }}</p>\n<p>Your travel application has been successfully cancelled. All associated bookings have been marked as cancelled.</p>\n<p>If you had any advance payment for this travel, the finance team will process the refund accordingly.</p>\n<p>Thank you,<br>Travel Management System</p>','Dear {{ employee_name }}, your cancellation request for travel application {{ request_id }} has been approved by {{ approver_name }}.','[]','[]',1,'2025-12-31 05:25:25.136652','2025-12-31 05:25:25.136676','travel.cancellation.approved','Travel Cancellation Approved'),(16,'Your Cancellation Request Has Been Rejected ??? {{ request_id }}','<p>Dear {{ employee_name }},</p>\n<p>Your cancellation request for travel application <strong>{{ request_id }}</strong> has been <strong>rejected</strong> by {{ approver_name }}.</p>\n<p><strong>Rejection Reason:</strong> {{ rejection_reason }}</p>\n<p>Your travel application has been restored to its previous status: <strong>{{ previous_status }}</strong>. You may proceed with your travel as originally planned.</p>\n<p>If you still wish to cancel, please contact your approver ({{ approver_name }}) for clarification or submit a new cancellation request with additional justification.</p>\n<p>Thank you,<br>Travel Management System</p>','Dear {{ employee_name }}, your cancellation request for travel application {{ request_id }} has been rejected by {{ approver_name }}. Reason: {{ rejection_reason }}.','[]','[]',1,'2025-12-31 05:25:25.139324','2025-12-31 05:25:25.139353','travel.cancellation.rejected','Travel Cancellation Rejected'),(17,'Travel Booking Cancelled ??? {{ request_id }}','<p>Dear {{ booking_agent_name }},</p>\n<p>The travel application <strong>{{ request_id }}</strong> that was assigned to you for booking has been <strong>cancelled</strong>.</p>\n<p><strong>Employee:</strong> {{ employee_name }}</p>\n<p><strong>Purpose:</strong> {{ purpose }}</p>\n<p><strong>Cancellation Reason:</strong> {{ cancellation_reason }}</p>\n<p><strong>Important:</strong> All booking actions for this travel application have been disabled. Please do not proceed with any bookings or confirmations for this request.</p>\n<p>If you have already initiated any booking processes, please halt them immediately and notify the Travel Desk.</p>\n<p>Thank you,<br>Travel Management System</p>','Dear {{ booking_agent_name }}, travel application {{ request_id }} assigned to you has been cancelled. Please halt all booking activities.','[]','[]',1,'2025-12-31 05:25:25.142117','2025-12-31 05:25:25.142144','travel.cancellation.booking_agent','Travel Cancellation - Booking Agent Notification'),(18,'Travel Application Cancelled ??? {{ request_id }}','<p>Dear {{ travel_desk_name }},</p>\n<p>The travel application <strong>{{ request_id }}</strong> that was pending in your queue has been <strong>cancelled</strong>.</p>\n<p><strong>Employee:</strong> {{ employee_name }}</p>\n<p><strong>Purpose:</strong> {{ purpose }}</p>\n<p><strong>Travel Dates:</strong> {{ travel_dates }}</p>\n<p><strong>Cancellation Reason:</strong> {{ cancellation_reason }}</p>\n<p><strong>Important:</strong> This application cannot be forwarded to booking agents. All processing for this request must be halted immediately.</p>\n<p>Please ensure this application is removed from your active queue.</p>\n<p>Thank you,<br>Travel Management System</p>','Dear {{ travel_desk_name }}, travel application {{ request_id }} has been cancelled. Do not forward to booking agents.','[]','[]',1,'2025-12-31 05:25:25.144774','2025-12-31 05:25:25.144801','travel.cancellation.travel_desk','Travel Cancellation - Travel Desk Notification');
/*!40000 ALTER TABLE `notifications_emailtemplatemaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications_notificationevent`
--

DROP TABLE IF EXISTS `notifications_notificationevent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications_notificationevent` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_name` varchar(150) NOT NULL,
  `reference_type` varchar(50) NOT NULL,
  `reference_id` bigint NOT NULL,
  `data` json NOT NULL,
  `next_reminder_at` datetime(6) DEFAULT NULL,
  `reminder_index` int NOT NULL,
  `is_resolved` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `rule_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifi_rule_id_4b5782a2_fk_notificat` (`rule_id`),
  KEY `notificatio_event_n_617ce5_idx` (`event_name`),
  KEY `notificatio_next_re_458cf9_idx` (`next_reminder_at`),
  CONSTRAINT `notifications_notifi_rule_id_4b5782a2_fk_notificat` FOREIGN KEY (`rule_id`) REFERENCES `notifications_notificationrule` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_notificationevent`
--

LOCK TABLES `notifications_notificationevent` WRITE;
/*!40000 ALTER TABLE `notifications_notificationevent` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications_notificationevent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications_notificationlog`
--

DROP TABLE IF EXISTS `notifications_notificationlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications_notificationlog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_name` varchar(150) NOT NULL,
  `channel` varchar(20) NOT NULL,
  `recipient` varchar(255) NOT NULL,
  `subject` varchar(512) DEFAULT NULL,
  `body` longtext,
  `payload` json NOT NULL,
  `status` varchar(20) NOT NULL,
  `attempts` int NOT NULL,
  `last_error` longtext,
  `created_at` datetime(6) NOT NULL,
  `sent_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_notificationlog`
--

LOCK TABLES `notifications_notificationlog` WRITE;
/*!40000 ALTER TABLE `notifications_notificationlog` DISABLE KEYS */;
INSERT INTO `notifications_notificationlog` VALUES (1,'travel.cancellation.requested','email','ronak.k@orangewebtech.com','Cancellation Request for Travel Application ??? TSF-TR-2026-000001','Dear Dr. Anuj Bhatnagar, Mr. Syed Jamil Ahmad has requested to cancel travel application TSF-TR-2026-000001. Reason: Need to update befor 7 days. Please review and take action.','{\"purpose\": \"प्रवास अर्ज फॉर्म _ आपली प्रवास विनंती सादर करा\", \"request_id\": \"TSF-TR-2026-000001\", \"approver_id\": 7, \"employee_id\": 6, \"request_date\": \"2026-01-05 13:08\", \"travel_dates\": \"2026-01-06 to 2026-01-07\", \"approver_name\": \"Dr. Anuj Bhatnagar\", \"employee_name\": \"Mr. Syed Jamil Ahmad\", \"current_status\": \"Cancellation Requested\", \"travel_desk_id\": null, \"booking_agent_ids\": [], \"cancellation_reason\": \"Need to update befor 7 days\"}','sent',1,NULL,'2026-01-05 13:08:53.349476','2026-01-05 13:08:58.224930'),(2,'travel.cancellation.requested','in_app','7','Cancellation Request for Travel Application ??? TSF-TR-2026-000001','Dear Dr. Anuj Bhatnagar, Mr. Syed Jamil Ahmad has requested to cancel travel application TSF-TR-2026-000001. Reason: Need to update befor 7 days. Please review and take action.','{\"purpose\": \"प्रवास अर्ज फॉर्म _ आपली प्रवास विनंती सादर करा\", \"request_id\": \"TSF-TR-2026-000001\", \"approver_id\": 7, \"employee_id\": 6, \"request_date\": \"2026-01-05 13:08\", \"travel_dates\": \"2026-01-06 to 2026-01-07\", \"approver_name\": \"Dr. Anuj Bhatnagar\", \"employee_name\": \"Mr. Syed Jamil Ahmad\", \"current_status\": \"Cancellation Requested\", \"travel_desk_id\": null, \"booking_agent_ids\": [], \"cancellation_reason\": \"Need to update befor 7 days\"}','sent',1,NULL,'2026-01-05 13:08:53.534863','2026-01-05 13:08:58.277050'),(3,'travel.cancellation.approved','email','trainee@orangewebtech.com','Your Travel Cancellation Has Been Approved ??? TSF-TR-2026-000001','Dear Mr. Syed Jamil Ahmad, your cancellation request for travel application TSF-TR-2026-000001 has been approved by Dr. Anuj Bhatnagar.','{\"notes\": \"No additional notes provided.\", \"purpose\": \"प्रवास अर्ज फॉर्म _ आपली प्रवास विनंती सादर करा\", \"request_id\": \"TSF-TR-2026-000001\", \"approver_id\": 7, \"employee_id\": 6, \"travel_dates\": \"2026-01-06 to 2026-01-07\", \"approval_date\": \"2026-01-05 13:09\", \"approver_name\": \"Dr. Anuj Bhatnagar\", \"employee_name\": \"Mr. Syed Jamil Ahmad\"}','sent',1,NULL,'2026-01-05 13:09:33.562921','2026-01-05 13:09:37.047333'),(4,'travel.cancellation.approved','in_app','6','Your Travel Cancellation Has Been Approved ??? TSF-TR-2026-000001','Dear Mr. Syed Jamil Ahmad, your cancellation request for travel application TSF-TR-2026-000001 has been approved by Dr. Anuj Bhatnagar.','{\"notes\": \"No additional notes provided.\", \"purpose\": \"प्रवास अर्ज फॉर्म _ आपली प्रवास विनंती सादर करा\", \"request_id\": \"TSF-TR-2026-000001\", \"approver_id\": 7, \"employee_id\": 6, \"travel_dates\": \"2026-01-06 to 2026-01-07\", \"approval_date\": \"2026-01-05 13:09\", \"approver_name\": \"Dr. Anuj Bhatnagar\", \"employee_name\": \"Mr. Syed Jamil Ahmad\"}','sent',1,NULL,'2026-01-05 13:09:33.573245','2026-01-05 13:09:37.119399');
/*!40000 ALTER TABLE `notifications_notificationlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications_notificationrule`
--

DROP TABLE IF EXISTS `notifications_notificationrule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications_notificationrule` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `event_name` varchar(150) NOT NULL,
  `description` varchar(255) NOT NULL,
  `channels` json NOT NULL,
  `recipient_resolver` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `send_reminder` tinyint(1) NOT NULL,
  `reminder_intervals` json NOT NULL,
  `escalation_resolver` varchar(100) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `template_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_name` (`event_name`),
  KEY `notifications_notifi_template_id_ec287d0e_fk_notificat` (`template_id`),
  CONSTRAINT `notifications_notifi_template_id_ec287d0e_fk_notificat` FOREIGN KEY (`template_id`) REFERENCES `notifications_emailtemplatemaster` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications_notificationrule`
--

LOCK TABLES `notifications_notificationrule` WRITE;
/*!40000 ALTER TABLE `notifications_notificationrule` DISABLE KEYS */;
INSERT INTO `notifications_notificationrule` VALUES (1,'travel.cancellation.requested','Notification sent to approver when employee requests travel cancellation','[\"email\", \"in_app\"]','approver_and_stakeholders',1,0,'[]',NULL,'2025-12-31 05:25:25.231063','2025-12-31 05:25:25.231092',14),(2,'travel.cancellation.approved','Notification sent to employee when cancellation request is approved','[\"email\", \"in_app\"]','employee',1,0,'[]',NULL,'2025-12-31 05:25:25.234653','2025-12-31 05:25:25.234680',15),(3,'travel.cancellation.rejected','Notification sent to employee when cancellation request is rejected','[\"email\", \"in_app\"]','employee',1,0,'[]',NULL,'2025-12-31 05:25:25.237807','2025-12-31 05:25:25.237833',16),(4,'travel.cancellation.booking_agent','Notification sent to booking agents when travel is cancelled during booking phase','[\"email\", \"in_app\"]','booking_agents',1,0,'[]',NULL,'2025-12-31 05:25:25.240888','2025-12-31 05:25:25.240915',17),(5,'travel.cancellation.travel_desk','Notification sent to travel desk when travel is cancelled while pending with them','[\"email\", \"in_app\"]','travel_desk',1,0,'[]',NULL,'2025-12-31 05:25:25.244273','2025-12-31 05:25:25.244331',18);
/*!40000 ALTER TABLE `notifications_notificationrule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organizational_profiles`
--

DROP TABLE IF EXISTS `organizational_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `organizational_profiles` (
  `user_id` bigint NOT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `base_location_id` int DEFAULT NULL,
  `company_id` bigint DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `designation_id` int DEFAULT NULL,
  `employee_type_id` bigint DEFAULT NULL,
  `grade_id` bigint DEFAULT NULL,
  `reporting_manager_id` bigint DEFAULT NULL,
  `employee_code` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  UNIQUE KEY `employee_code` (`employee_code`),
  KEY `organizational_profi_base_location_id_9df90d02_fk_master_da` (`base_location_id`),
  KEY `organizational_profi_designation_id_228720f2_fk_master_da` (`designation_id`),
  KEY `organizational_profi_employee_type_id_481cc90f_fk_master_da` (`employee_type_id`),
  KEY `organizational_profi_grade_id_dd89cff5_fk_master_da` (`grade_id`),
  KEY `organizational_profi_reporting_manager_id_1aefae91_fk_auth_user` (`reporting_manager_id`),
  KEY `organizatio_employe_104b31_idx` (`employee_id`),
  KEY `organizatio_company_9223b3_idx` (`company_id`),
  KEY `organizatio_departm_ba2b08_idx` (`department_id`),
  CONSTRAINT `organizational_profi_base_location_id_9df90d02_fk_master_da` FOREIGN KEY (`base_location_id`) REFERENCES `master_data_locationmaster` (`location_id`),
  CONSTRAINT `organizational_profi_company_id_5f300851_fk_master_da` FOREIGN KEY (`company_id`) REFERENCES `master_data_companyinformation` (`id`),
  CONSTRAINT `organizational_profi_department_id_d31fcbfc_fk_master_da` FOREIGN KEY (`department_id`) REFERENCES `master_data_departmentmaster` (`department_id`),
  CONSTRAINT `organizational_profi_designation_id_228720f2_fk_master_da` FOREIGN KEY (`designation_id`) REFERENCES `master_data_designationmaster` (`designation_id`),
  CONSTRAINT `organizational_profi_employee_type_id_481cc90f_fk_master_da` FOREIGN KEY (`employee_type_id`) REFERENCES `master_data_employeetypemaster` (`id`),
  CONSTRAINT `organizational_profi_grade_id_dd89cff5_fk_master_da` FOREIGN KEY (`grade_id`) REFERENCES `master_data_grademaster` (`id`),
  CONSTRAINT `organizational_profi_reporting_manager_id_1aefae91_fk_auth_user` FOREIGN KEY (`reporting_manager_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `organizational_profiles_user_id_988521df_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organizational_profiles`
--

LOCK TABLES `organizational_profiles` WRITE;
/*!40000 ALTER TABLE `organizational_profiles` DISABLE KEYS */;
INSERT INTO `organizational_profiles` VALUES (1,NULL,'2026-01-07 11:33:39.665964','2026-01-07 11:33:39.665983',NULL,NULL,NULL,NULL,NULL,1,1,NULL),(2,'','2026-01-01 05:09:05.905031','2026-01-01 06:32:55.227785',NULL,NULL,NULL,NULL,NULL,1,2,'SSO-2'),(3,'11','2026-01-01 06:43:04.936641','2026-01-07 07:33:02.766106',NULL,2,1,1,NULL,3,4,'00262'),(4,'672','2026-01-01 06:43:05.658607','2026-01-07 07:33:02.760763',NULL,2,1,2,NULL,6,NULL,'149971'),(5,'152','2026-01-01 06:46:51.852007','2026-01-01 06:46:51.853916',NULL,1,2,3,NULL,6,NULL,'113707'),(6,'8','2026-01-05 09:41:12.264150','2026-01-08 13:40:25.318687',2,2,3,4,NULL,5,7,'00245'),(7,'673','2026-01-05 09:41:12.926614','2026-01-08 13:40:25.303464',2,2,3,5,NULL,2,8,'01353'),(8,'464','2026-01-05 12:58:03.373745','2026-01-08 13:26:33.179385',2,2,4,6,NULL,7,NULL,'197582'),(9,'26','2026-01-05 13:22:47.905523','2026-01-08 09:23:04.894577',2,2,5,7,NULL,3,8,'00292'),(10,'824','2026-01-06 10:16:15.313993','2026-01-07 14:40:50.995404',2,2,6,8,NULL,1,NULL,'97587');
/*!40000 ALTER TABLE `organizational_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `codename` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `description` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `codename` (`codename`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `granted_at` datetime(6) DEFAULT NULL,
  `permission_id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authentication_rolepermi_role_id_permission_id_54443e60_uniq` (`role_id`,`permission_id`),
  KEY `authentication_rolep_permission_id_b453cbda_fk_authentic` (`permission_id`),
  CONSTRAINT `authentication_rolep_permission_id_b453cbda_fk_authentic` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`),
  CONSTRAINT `authentication_rolep_role_id_93bf005a_fk_authentic` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `role_type` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `description` longtext NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin','admin',1,'System administrator with full access','2025-12-31 08:37:10.330818','2025-12-31 08:37:10.330925'),(2,'Manager','manager',1,'Reporting manager and approver','2025-12-31 08:37:10.341635','2025-12-31 08:37:10.341687'),(3,'Employee','employee',1,'Regular organizational user','2025-12-31 08:37:10.365924','2025-12-31 08:37:10.365956'),(4,'CEO','ceo',1,'Chief Executive Officer','2025-12-31 08:37:10.375919','2026-01-08 11:47:44.215155'),(5,'CHRO','chro',1,'Chief Human Resources Officer','2025-12-31 08:37:10.382981','2026-01-08 11:47:51.418883'),(6,'Travel Desk','travel_desk',1,'Internal travel desk user','2025-12-31 08:37:10.404690','2026-01-08 11:48:05.742082'),(7,'Booking Agent','booking_agent',1,'External booking and vendor agent','2025-12-31 08:37:10.411727','2026-01-08 11:47:38.134662');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_blacklist_blacklistedtoken`
--

DROP TABLE IF EXISTS `token_blacklist_blacklistedtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_blacklist_blacklistedtoken` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `blacklisted_at` datetime(6) NOT NULL,
  `token_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_id` (`token_id`),
  CONSTRAINT `token_blacklist_blacklistedtoken_token_id_3cc7fe56_fk` FOREIGN KEY (`token_id`) REFERENCES `token_blacklist_outstandingtoken` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_blacklist_blacklistedtoken`
--

LOCK TABLES `token_blacklist_blacklistedtoken` WRITE;
/*!40000 ALTER TABLE `token_blacklist_blacklistedtoken` DISABLE KEYS */;
INSERT INTO `token_blacklist_blacklistedtoken` VALUES (1,'2025-12-31 08:40:54.391267',2),(2,'2025-12-31 10:36:01.368683',6),(3,'2025-12-31 11:17:20.445954',8),(4,'2026-01-01 06:06:30.176497',12),(9,'2026-01-01 10:43:47.949875',19),(11,'2026-01-02 07:15:08.588202',25),(13,'2026-01-05 06:14:21.305496',32),(14,'2026-01-05 06:18:26.475148',35),(15,'2026-01-05 06:50:36.444879',34),(16,'2026-01-05 09:13:14.754247',37),(17,'2026-01-05 09:41:28.634894',39),(18,'2026-01-05 10:11:53.366049',38),(22,'2026-01-05 12:28:56.427767',55),(23,'2026-01-05 12:34:31.662219',59),(24,'2026-01-05 12:38:03.053775',60),(25,'2026-01-05 12:55:52.744265',62),(26,'2026-01-05 13:11:08.719713',64),(27,'2026-01-05 13:13:12.018396',65),(28,'2026-01-05 13:22:11.518417',66),(29,'2026-01-05 13:23:55.266714',67),(30,'2026-01-05 13:25:22.934884',68),(31,'2026-01-05 13:26:24.063574',69),(32,'2026-01-05 13:29:59.078663',70),(33,'2026-01-05 13:35:35.159071',71),(34,'2026-01-05 13:36:33.555923',72),(35,'2026-01-05 13:46:18.003484',74),(36,'2026-01-06 06:23:28.224769',76),(38,'2026-01-06 07:02:38.618273',81),(39,'2026-01-06 07:16:07.125982',84),(40,'2026-01-06 07:17:00.177839',53),(44,'2026-01-06 08:33:07.908712',91),(46,'2026-01-06 08:33:22.247822',92),(48,'2026-01-06 08:33:22.685879',85),(50,'2026-01-06 08:33:39.037124',93),(51,'2026-01-06 10:01:14.916683',102),(52,'2026-01-06 10:06:15.076786',107),(53,'2026-01-06 10:07:19.154666',108),(54,'2026-01-06 10:15:24.994577',109),(55,'2026-01-06 10:53:01.492919',105),(59,'2026-01-06 10:55:43.328873',110),(61,'2026-01-06 12:19:25.992147',122),(62,'2026-01-06 12:36:33.821632',123),(63,'2026-01-06 12:43:07.190970',118),(64,'2026-01-07 06:50:50.112692',128),(65,'2026-01-07 08:39:21.218409',133),(66,'2026-01-07 11:36:00.081679',138),(67,'2026-01-07 11:38:53.005458',129),(68,'2026-01-07 11:43:28.783595',135),(69,'2026-01-07 12:13:19.072572',141),(74,'2026-01-08 05:34:59.822011',150),(75,'2026-01-08 05:58:52.368200',152),(76,'2026-01-08 06:00:09.957609',153),(77,'2026-01-08 06:09:47.666069',155),(79,'2026-01-08 07:54:26.451765',165),(80,'2026-01-08 08:17:30.511644',169),(81,'2026-01-08 08:40:35.988798',159),(83,'2026-01-08 08:40:45.762089',166),(85,'2026-01-08 09:21:04.947565',106),(87,'2026-01-08 09:39:00.501592',168),(89,'2026-01-08 09:59:49.973470',184),(90,'2026-01-08 12:00:52.921093',187),(92,'2026-01-08 12:12:56.308105',190),(93,'2026-01-08 12:14:49.365007',191),(94,'2026-01-08 12:21:24.702535',193),(95,'2026-01-08 12:40:50.265415',192),(96,'2026-01-08 12:41:23.247549',194),(97,'2026-01-08 12:57:29.559395',149),(102,'2026-01-08 13:19:13.619678',196),(103,'2026-01-08 14:04:06.254624',202);
/*!40000 ALTER TABLE `token_blacklist_blacklistedtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token_blacklist_outstandingtoken`
--

DROP TABLE IF EXISTS `token_blacklist_outstandingtoken`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `token_blacklist_outstandingtoken` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `token` longtext NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `jti` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_blacklist_outstandingtoken_jti_hex_d9bdf6f7_uniq` (`jti`),
  KEY `token_blacklist_outs_user_id_83bc629a_fk_auth_user` (`user_id`),
  CONSTRAINT `token_blacklist_outs_user_id_83bc629a_fk_auth_user` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token_blacklist_outstandingtoken`
--

LOCK TABLES `token_blacklist_outstandingtoken` WRITE;
/*!40000 ALTER TABLE `token_blacklist_outstandingtoken` DISABLE KEYS */;
INSERT INTO `token_blacklist_outstandingtoken` VALUES (1,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc2ODE2OSwiaWF0IjoxNzY3MTYzMzY5LCJqdGkiOiIzNjI5NmIwZDU4YmE0NTFkYWI2YzdmYzI1ZjViM2Q4MiIsInVzZXJfaWQiOiIxIn0.D2lVs2T0TL0HRiSRVfwAe7BLf6_yMrxiJSCBSFY5-AY','2025-12-31 06:42:49.561661','2026-01-07 06:42:49.000000',1,'36296b0d58ba451dab6c7fc25f5b3d82'),(2,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc2ODc2MCwiaWF0IjoxNzY3MTYzOTYwLCJqdGkiOiI2YmRhYjEwNWM1NmI0NjVjODVjNGRkNDA5ZDEzODEyMCIsInVzZXJfaWQiOiIxIn0.N0TYKMDIJDtXADBN7QTVjB4RgNOO88u2nymEyEmhhgo','2025-12-31 06:52:40.152963','2026-01-07 06:52:40.000000',1,'6bdab105c56b465c85c4dd409d138120'),(3,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc3NTI1NCwiaWF0IjoxNzY3MTcwNDU0LCJqdGkiOiI4MzMxNGY3MzE1Zjc0YzNjOGU5MDAwYjlmNDgxOWMxYSIsInVzZXJfaWQiOiIxIn0.oowap63k7abphVDifyhZP6tLx5MSnnTexE3u-MKFW4g','2025-12-31 08:40:54.370482','2026-01-07 08:40:54.000000',1,'83314f7315f74c3c8e9000b9f4819c1a'),(4,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc3NTI2MCwiaWF0IjoxNzY3MTcwNDYwLCJqdGkiOiJhYmRmMjBjMzg0ZDA0MzFjYjczZTg2ZmU4YTI2MWZjZCIsInVzZXJfaWQiOiIxIn0.crLaVHfonG_0MFzeCcwWiBNuWmUFWewaktArO4N-B6Q','2025-12-31 08:41:00.108089','2026-01-07 08:41:00.000000',1,'abdf20c384d0431cb73e86fe8a261fcd'),(5,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc3NzA1OSwiaWF0IjoxNzY3MTcyMjU5LCJqdGkiOiJkZTYyZjA4NDkxM2E0YjU3OGNjNjgwMDRjMDUyZTVhZSIsInVzZXJfaWQiOiIxIn0.m7ufUw2mRjtkC2yzn5rSvpNaqi-SUm21ehjQceoMhZs','2025-12-31 09:10:59.434850','2026-01-07 09:10:59.000000',1,'de62f084913a4b578cc68004c052e5ae'),(6,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc3Nzc3NywiaWF0IjoxNzY3MTcyOTc3LCJqdGkiOiI2MTRiMjRiM2ZlNjU0ZjUwOWQ2ODMyYTNmOTRhZjk1MiIsInVzZXJfaWQiOiIxIn0.o2cWBYDwxC7fAq4MylkemN4tWZI7tj8T7WjAQnDDqD8','2025-12-31 09:22:57.424916','2026-01-07 09:22:57.000000',1,'614b24b3fe654f509d6832a3f94af952'),(7,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc4MjE2MSwiaWF0IjoxNzY3MTc3MzYxLCJqdGkiOiIyMDMxMzkzNGZkM2E0ZDgzOTgzNDkzYjAwNzEzNmJhNCIsInVzZXJfaWQiOiIxIn0.HDVQWfyaeEBXlnYH_QgZXsMM-5OXV3CKnAf7zUP6XNk','2025-12-31 10:36:01.217574','2026-01-07 10:36:01.000000',1,'20313934fd3a4d83983493b007136ba4'),(8,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc4MjE2MywiaWF0IjoxNzY3MTc3MzYzLCJqdGkiOiIwNmU5ZDE2NTRiZTM0MTc1OGE1MjM5YjBlNmNmMmQ2MyIsInVzZXJfaWQiOiIxIn0.VrB64TsZrx_1ZTBmIETWCD9JmZdaJyloZWjE9f6QQg8','2025-12-31 10:36:03.170908','2026-01-07 10:36:03.000000',1,'06e9d1654be341758a5239b0e6cf2d63'),(9,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc4NDY0MCwiaWF0IjoxNzY3MTc5ODQwLCJqdGkiOiJiNzJlYzA3OTVjZWM0ODIxOWU3NDY2N2I1MGM4ZGY2MiIsInVzZXJfaWQiOiIxIn0.U4BvXlzY2SRdkBpB451mQwhLqyUlkQA2xSx9OXDv25w','2025-12-31 11:17:20.371220','2026-01-07 11:17:20.000000',1,'b72ec0795cec48219e74667b50c8df62'),(10,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzc4NDY0MywiaWF0IjoxNzY3MTc5ODQzLCJqdGkiOiJkZmM3YzRlNDA3OGE0MWRhYThhMmM5OWExNWM2NDlhZiIsInVzZXJfaWQiOiIxIn0.5UZLz_SmJ1iuUmlZx_nH7SWofb_dWCZ4OOcL3sZUvnE','2025-12-31 11:17:23.236065','2026-01-07 11:17:23.000000',1,'dfc7c4e4078a41daa8a2c99a15c649af'),(11,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg0ODk0NSwiaWF0IjoxNzY3MjQ0MTQ1LCJqdGkiOiJlODBiMDI2YmYzYTA0ZTQ5YTc0ZDRjZDRmYjcxMzFjYSIsInVzZXJfaWQiOiIyIn0.zLRDDrhJ-vJUFI-57-1kplThoNB7-_mbUz1BNEVORKk','2026-01-01 05:09:05.934158','2026-01-08 05:09:05.000000',2,'e80b026bf3a04e49a74d4cd4fb7131ca'),(12,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg1MjMyMywiaWF0IjoxNzY3MjQ3NTIzLCJqdGkiOiI0MGY3MmMzYzY3OWY0ZWUwOWRlZGFiNTQxZWIwNGNhMSIsInVzZXJfaWQiOiIxIn0.Mqo8wgDYygrrdJn3itq9f1cM4tKCgvHQGsxlLM-lTtE','2026-01-01 06:05:23.163009','2026-01-08 06:05:23.000000',1,'40f72c3c679f4ee09dedab541eb04ca1'),(13,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg1MzkwOCwiaWF0IjoxNzY3MjQ5MTA4LCJqdGkiOiIwYzFiNzdiZDE4MWE0ODUzYjBhNjA1NWJlYTgzZDE3NyIsInVzZXJfaWQiOiIxIn0.7RLUawl-UDZjooUuhUD3l_8jjMgZcv8EYyTU0Rb6kCM','2026-01-01 06:31:48.380621','2026-01-08 06:31:48.000000',1,'0c1b77bd181a4853b0a6055bea83d177'),(14,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg1NDMxMywiaWF0IjoxNzY3MjQ5NTEzLCJqdGkiOiIyOTdhMDFlMTcyY2U0MzkzYWE2Zjk4MzYxNzM5ZjEzMiIsInVzZXJfaWQiOiIyIn0.K1-XuX1pONv8JDqClbXgJNDqNGdLzDX_UDjh3yfY92Y','2026-01-01 06:38:33.938096','2026-01-08 06:38:33.000000',2,'297a01e172ce4393aa6f98361739f132'),(15,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg1NDU4NSwiaWF0IjoxNzY3MjQ5Nzg1LCJqdGkiOiJlZTIwMmIyNWIzYTI0NTdkOWM5NGVhYjY5OGVmMmYyMSIsInVzZXJfaWQiOiIzIn0.YkwHfHXJQ1vXXQTmA1xOGXAt4uSSGOFyHQJXrFXxuZg','2026-01-01 06:43:05.695710','2026-01-08 06:43:05.000000',3,'ee202b25b3a2457d9c94eab698ef2f21'),(16,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg1NDc0MCwiaWF0IjoxNzY3MjQ5OTQwLCJqdGkiOiIzZjQ2YTkyYTAwZjc0MThlYTY4MTYzMjhkNjc4MjE1MSIsInVzZXJfaWQiOiIyIn0.6UrXGruN0To48sfa0XzRC-O8svGhC1_zrW4bkMbzhEY','2026-01-01 06:45:40.819256','2026-01-08 06:45:40.000000',2,'3f46a92a00f7418ea6816328d6782151'),(17,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg1NDc2NiwiaWF0IjoxNzY3MjQ5OTY2LCJqdGkiOiJlYmM0MGMxMTBiYTA0ZGZkOThhNWVhZWEyNWZiOWE1MSIsInVzZXJfaWQiOiIxIn0.cYOWaq-bJAmq7soqUL6pmAGhCpMTXMhjvU-DsyBmB38','2026-01-01 06:46:06.694172','2026-01-08 06:46:06.000000',1,'ebc40c110ba04dfd98a5eaea25fb9a51'),(18,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg1NDgxMSwiaWF0IjoxNzY3MjUwMDExLCJqdGkiOiIzM2YyNDg2MGM1MjE0NjA2OGFhNjhiMTQ2ZThmZWQxMSIsInVzZXJfaWQiOiI1In0.Pd30mCduw0ZlchK67Aa5N4HCdCZkocowcAWJF5ggK0E','2026-01-01 06:46:51.882666','2026-01-08 06:46:51.000000',5,'33f24860c52146068aa68b146e8fed11'),(19,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg1NjI1NCwiaWF0IjoxNzY3MjUxNDU0LCJqdGkiOiJiZjA0ODIyYjkwYjQ0ZmFjYWE3ZGU4N2NlNGI3MDUwNyIsInVzZXJfaWQiOiIzIn0.IgzKZos9lEkysOUypVcxU2R8zKC74GuSZkMJddvXCeM','2026-01-01 07:10:54.745094','2026-01-08 07:10:54.000000',3,'bf04822b90b44facaa7de87ce4b70507'),(20,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg2OTAyNywiaWF0IjoxNzY3MjY0MjI3LCJqdGkiOiJlM2M1OTBiZjcwOTQ0YmU2OTMwNGJkYTM5OTdiMjljNyIsInVzZXJfaWQiOiIzIn0.RgIgqgiHkPlKXEAOE-_atYsbo6FoIKtYpVpid_Npw_0','2026-01-01 10:43:47.795292','2026-01-08 10:43:47.000000',3,'e3c590bf70944be69304bda3997b29c7'),(21,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg2OTAyNywiaWF0IjoxNzY3MjY0MjI3LCJqdGkiOiIyY2NmYTA2OTgwZTM0NTFmYjFjYWUzZDdkYTUzMzNiOCIsInVzZXJfaWQiOiIzIn0.Bve-ZIOWvr3HtQX01QUA0tmrOkNh3GYwy68kx0mQI_0','2026-01-01 10:43:47.764051','2026-01-08 10:43:47.000000',3,'2ccfa06980e3451fb1cae3d7da5333b8'),(22,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg2OTAyNywiaWF0IjoxNzY3MjY0MjI3LCJqdGkiOiI1NzRkNzViMzg1MDM0ODhlYTZmZTkzMDQ3ZTE5OGVmZSIsInVzZXJfaWQiOiIzIn0.IhpRYUrtKk4BlXCtJ8u9fN_XtAP4hKgxZix1leR8pf4','2026-01-01 10:43:47.800553','2026-01-08 10:43:47.000000',3,'574d75b38503488ea6fe93047e198efe'),(23,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg2OTAyNywiaWF0IjoxNzY3MjY0MjI3LCJqdGkiOiJiMzYxYWNjMjY0NDE0NDc0YjFhZjAxNGVkMTBhMWI4YiIsInVzZXJfaWQiOiIzIn0.VDz2COcsmg8jA9gtYf0Tn734Xd5eEpMSVVcT83hw7hI','2026-01-01 10:43:47.799543','2026-01-08 10:43:47.000000',3,'b361acc264414474b1af014ed10a1b8b'),(24,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzg2OTAyNywiaWF0IjoxNzY3MjY0MjI3LCJqdGkiOiI2YzJmMzIzOTQxNDI0ZDY5ODFmY2I5YTdmNWZiOTRlZiIsInVzZXJfaWQiOiIzIn0.zCEU_5h3OSK9xQ5zo6Z2hRNn0UGM7-JXb8qgit6MSas','2026-01-01 10:43:47.724642','2026-01-08 10:43:47.000000',3,'6c2f323941424d6981fcb9a7f5fb94ef'),(25,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2NzkzOTc0NSwiaWF0IjoxNzY3MzM0OTQ1LCJqdGkiOiIxODEzNjMwZjU4OTM0OWNmOGU1MTQyOTg5ZjdmOWI0ZCIsInVzZXJfaWQiOiIxIn0.DhU2kVDkrV8DLAZrnzBN8VVfS4pMorYsphYLkUWhZ5U','2026-01-02 06:22:25.739071','2026-01-09 06:22:25.000000',1,'1813630f589349cf8e5142989f7f9b4d'),(26,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzk0MjkwOCwiaWF0IjoxNzY3MzM4MTA4LCJqdGkiOiJlZDdiYTgxODA3Njg0MGFkYTNlY2E2NjZjMWJiNDgwOSIsInVzZXJfaWQiOiIxIn0.8FxWzf2UwA1AKUXKdYHHXG9AwxXWqVtgeXwCRUqXbpU','2026-01-02 07:15:08.476954','2026-01-09 07:15:08.000000',1,'ed7ba818076840ada3eca666c1bb4809'),(27,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzk0MjkwOCwiaWF0IjoxNzY3MzM4MTA4LCJqdGkiOiI1YmY5MmNkZmI2N2E0MmY4YjdmODMxMGU5OWQ3MjU0YSIsInVzZXJfaWQiOiIxIn0.CTzrinBE03hTUaAJKxxmRkzSGodSA4ijxYOlbpvobew','2026-01-02 07:15:08.486611','2026-01-09 07:15:08.000000',1,'5bf92cdfb67a42f8b7f8310e99d7254a'),(28,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzk0MjkwOCwiaWF0IjoxNzY3MzM4MTA4LCJqdGkiOiJjMjZkZDhiMzQ5MWE0OGU1YWM5ZTVkNjYyZDlkZTQ0OSIsInVzZXJfaWQiOiIxIn0.Wg_RqWmadE1mL1sgmE0EBtpFejGxSEXsKZN_-Co8wNo','2026-01-02 07:15:08.471279','2026-01-09 07:15:08.000000',1,'c26dd8b3491a48e5ac9e5d662d9de449'),(29,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzk0MjkwOCwiaWF0IjoxNzY3MzM4MTA4LCJqdGkiOiI1MzJiNzkwOWRiMmI0NGE4ODdhZGYyM2FhYjAyNzk1ZCIsInVzZXJfaWQiOiIxIn0.Qmu7kjVt5gIcK51QIUKGYusFzSmF3W_4PzsT-Ja_8o4','2026-01-02 07:15:08.455965','2026-01-09 07:15:08.000000',1,'532b7909db2b44a887adf23aab02795d'),(30,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzk0NTMzNywiaWF0IjoxNzY3MzQwNTM3LCJqdGkiOiJiYWRjM2ZlOTVlY2E0Y2JkODJhZjU1YWEyYzY4NWZmZiIsInVzZXJfaWQiOiIxIn0.akWi5Ug71yNHf7gJzqY_y7_8M6UdcTDlUL3JyqqNyz0','2026-01-02 07:55:37.866640','2026-01-09 07:55:37.000000',1,'badc3fe95eca4cbd82af55aa2c685fff'),(31,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzk0NjQwNCwiaWF0IjoxNzY3MzQxNjA0LCJqdGkiOiIyZGY0ZTNjYTUyN2I0ODI0YTZkNGIxM2ExNTliMmZkMyIsInVzZXJfaWQiOiIxIn0.7PE3fmPVmsP0yp7fxe5JSZHD3efG14w98McwCMoDMV4','2026-01-02 08:13:24.833025','2026-01-09 08:13:24.000000',1,'2df4e3ca527b4824a6d4b13a159b2fd3'),(32,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2Nzk0Nzg5NywiaWF0IjoxNzY3MzQzMDk3LCJqdGkiOiI5OGQ1YjRkNjRiMDQ0NjE5OWYzNWU1MWYwNzJkNzdiNyIsInVzZXJfaWQiOiIxIn0.V_U5zrjl8AOYwKnsKvSkZS6yy8L459-OpWkKOWkV_5k','2026-01-02 08:38:17.251575','2026-01-09 08:38:17.000000',1,'98d5b4d64b0446199f35e51f072d77b7'),(33,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODE5ODQ2MSwiaWF0IjoxNzY3NTkzNjYxLCJqdGkiOiJiMDA5NzA5MDRkOWI0MDVjODQzMzVmMmI5MDdlYTQ2YiIsInVzZXJfaWQiOiIxIn0.BR66JzdIWLsezbPDY7823JHYu_eaaGozo03mPDLcEVY','2026-01-05 06:14:21.222033','2026-01-12 06:14:21.000000',1,'b00970904d9b405c84335f2b907ea46b'),(34,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODE5ODQ2MiwiaWF0IjoxNzY3NTkzNjYyLCJqdGkiOiI0OWNlZDcyNjUyZmE0YTJmOWM2MzdlMzdjYTdlOGI4MSIsInVzZXJfaWQiOiIxIn0.p_E1WpPjRTjYOT4FbO-vvsGjvm_jYAZWq1L_r3mAXoU','2026-01-05 06:14:22.128085','2026-01-12 06:14:22.000000',1,'49ced72652fa4a2f9c637e37ca7e8b81'),(35,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODE5ODY3NywiaWF0IjoxNzY3NTkzODc3LCJqdGkiOiJjNmFlYzVhMWI4YzE0NDk1OGIyZmMwNjRhYWI3MzIxZSIsInVzZXJfaWQiOiIxIn0.YGft4a-I_eZgr1OhYW3Mp8YnbiuekhuNI71jEZqN-XI','2026-01-05 06:17:57.572561','2026-01-12 06:17:57.000000',1,'c6aec5a1b8c144958b2fc064aab7321e'),(36,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIwMDYzNiwiaWF0IjoxNzY3NTk1ODM2LCJqdGkiOiJmZDQ1Njc1YjViODM0NWM3OTRmYmEyNzExZjdkYWRhNyIsInVzZXJfaWQiOiIxIn0.ArEKNIeF_zlYbPNCjQGEEbLYoDEo_MPhbt8zO_dspcg','2026-01-05 06:50:36.326839','2026-01-12 06:50:36.000000',1,'fd45675b5b8345c794fba2711f7dada7'),(37,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIwODk5MywiaWF0IjoxNzY3NjA0MTkzLCJqdGkiOiI3YjljNjYwYWY3MDE0M2UxYjU0MWRkZWQ2YzQ3OTVmZiIsInVzZXJfaWQiOiIxIn0.mwW5ZsvxE4hBplDW8I0Lko7poQTT0DrU0wcx5HGg1yY','2026-01-05 09:09:53.693497','2026-01-12 09:09:53.000000',1,'7b9c660af70143e1b541dded6c4795ff'),(38,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMDU3MSwiaWF0IjoxNzY3NjA1NzcxLCJqdGkiOiI1NGJiZGJmMTRlZjA0YmZkOWM0Y2FmNDZlZDg4NGE5NSIsInVzZXJfaWQiOiIyIn0.p_9x-pm6fc_iXBf_6VDncIJdZZ1W7ttarBg7ONdPH60','2026-01-05 09:36:11.733611','2026-01-12 09:36:11.000000',2,'54bbdbf14ef04bfd9c4caf46ed884a95'),(39,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMDg3MywiaWF0IjoxNzY3NjA2MDczLCJqdGkiOiJlNzNkNGU1ZGFiYTA0NWI4YjI1ZGZiN2MxYTJkZWYyZSIsInVzZXJfaWQiOiI2In0.yB4Oj5bkSRAShNqz85VtHl3afrL9-p6o4t_SUG1SE1U','2026-01-05 09:41:13.314753','2026-01-12 09:41:13.000000',6,'e73d4e5daba045b8b25dfb7c1a2def2e'),(40,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMDg5NiwiaWF0IjoxNzY3NjA2MDk2LCJqdGkiOiJhMDU5MGRmNWRkYTc0Y2I3YjU4OGIxN2E3NjU5ZDM2YSIsInVzZXJfaWQiOiIxIn0.82Q81oJsI43iQ2XEx--vrbEkscMX0y800JCJRrR1QTU','2026-01-05 09:41:36.297387','2026-01-12 09:41:36.000000',1,'a0590df5dda74cb7b588b17a7659d36a'),(41,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMTA4OSwiaWF0IjoxNzY3NjA2Mjg5LCJqdGkiOiI4NjAwNDg5ZDFmMmQ0MzUyYWNkN2IxNWVhNDFiNzBjYSIsInVzZXJfaWQiOiIzIn0.Thge6wZaHPxXdtY2TZtlJXhRoavPF1pBVdc5quLzhiY','2026-01-05 09:44:49.532034','2026-01-12 09:44:49.000000',3,'8600489d1f2d4352acd7b15ea41b70ca'),(42,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMTMzOCwiaWF0IjoxNzY3NjA2NTM4LCJqdGkiOiI5MzY1ODEyMzZiNzY0YzJiYTlhMDRkZDU4NWY4NzdjZiIsInVzZXJfaWQiOiI2In0.BM_xArT8zJppH7peQj3EyY7RXPNSHDnwHMSx0jwXFFE','2026-01-05 09:48:58.577374','2026-01-12 09:48:58.000000',6,'936581236b764c2ba9a04dd585f877cf'),(43,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMTg3OCwiaWF0IjoxNzY3NjA3MDc4LCJqdGkiOiI2NTZmMGVlYWU4Yjc0OWJhYjA1ZWJlNjQ2ZDkyMGQ0OSIsInVzZXJfaWQiOiIxIn0.KV909VNkr9b7jIvOiTOoCrZFceQIUeTsWiey-CLpYfQ','2026-01-05 09:57:58.729357','2026-01-12 09:57:58.000000',1,'656f0eeae8b749bab05ebe646d920d49'),(44,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMjcxMywiaWF0IjoxNzY3NjA3OTEzLCJqdGkiOiJhZWJmNTJkMDFhZDg0Nzk3YWVlZDFjMTA4OWJiY2IyZSIsInVzZXJfaWQiOiIyIn0.X4jZmsAJMGKompWdQQfbyOhsQba3Xlp5qCD5YFYiu_E','2026-01-05 10:11:53.332078','2026-01-12 10:11:53.000000',2,'aebf52d01ad84797aeed1c1089bbcb2e'),(45,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMjcxMywiaWF0IjoxNzY3NjA3OTEzLCJqdGkiOiJjN2ZkNTY3OGJhNjA0MTcxOGVkMGIwOWM0ZDVkZGNjNiIsInVzZXJfaWQiOiIyIn0.WJ5QMUwQFz7qsAQeHpCGzl-DeqIs3lV7bvssDoyxBvo','2026-01-05 10:11:53.349975','2026-01-12 10:11:53.000000',2,'c7fd5678ba6041718ed0b09c4d5ddcc6'),(46,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMjcxMywiaWF0IjoxNzY3NjA3OTEzLCJqdGkiOiIzNDdjYWExMzE1Zjc0MzBjYWRmNmRiYTIwNzhlOTk2MSIsInVzZXJfaWQiOiIyIn0.4Zfdpk4kbyq5xxIywipoY3RaTH9CWesANDsLM7z_E30','2026-01-05 10:11:53.347044','2026-01-12 10:11:53.000000',2,'347caa1315f7430cadf6dba2078e9961'),(47,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMjcxMywiaWF0IjoxNzY3NjA3OTEzLCJqdGkiOiJjNGI4NzU5ZmVjOTQ0MjJmYjIxZGRjMzU5MTkwMGRmOSIsInVzZXJfaWQiOiIyIn0.hb_MRXYj_6Qwxtqxr2IPyw6MOZIP5oKiCSlQKzoTf10','2026-01-05 10:11:53.344068','2026-01-12 10:11:53.000000',2,'c4b8759fec94422fb21ddc3591900df9'),(48,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMjcxMywiaWF0IjoxNzY3NjA3OTEzLCJqdGkiOiJkMTJjMDc2NThjNzc0MjcyYTU0YTgzZjBmZWZmNzc5NCIsInVzZXJfaWQiOiIyIn0.EdtWO5xw9FABaiCRPuBuco1-ZL7HCdVCks5h-qFX5Wc','2026-01-05 10:11:53.336872','2026-01-12 10:11:53.000000',2,'d12c07658c774272a54a83f0feff7794'),(49,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMjkyMiwiaWF0IjoxNzY3NjA4MTIyLCJqdGkiOiIzZDA0NzI4Zjc4NWE0MTNmODBiNGVjZDhmYTY4NzU4OSIsInVzZXJfaWQiOiI2In0.yT-bTLxYB-4HsKFO0Kcrl9FaLTKAWTnlnNbYgkwaxbY','2026-01-05 10:15:22.468596','2026-01-12 10:15:22.000000',6,'3d04728f785a413f80b4ecd8fa687589'),(50,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMzA0OSwiaWF0IjoxNzY3NjA4MjQ5LCJqdGkiOiI5YzBkY2I3OWU5MmY0YWY3OGQwZjRkOWRlNTUzYmE5OCIsInVzZXJfaWQiOiI2In0.M5YvOPrkSwgduUuACuyEKX-7cPa5yiWlXlRZBEOztZk','2026-01-05 10:17:29.452233','2026-01-12 10:17:29.000000',6,'9c0dcb79e92f4af78d0f4d9de553ba98'),(51,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxMzQxNywiaWF0IjoxNzY3NjA4NjE3LCJqdGkiOiIwOTBjYjZlMGI2Y2Y0ZWU0ODVhYWMzMGUxNzUzOGMxOSIsInVzZXJfaWQiOiIzIn0.5MmJrIbQrfwo0n40Zw09OD8odaS3yH-AGeVdc5_gD98','2026-01-05 10:23:37.340163','2026-01-12 10:23:37.000000',3,'090cb6e0b6cf4ee485aac30e17538c19'),(52,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxNDc0MCwiaWF0IjoxNzY3NjA5OTQwLCJqdGkiOiI3MjFhMTcyYzgwNDQ0NzJkOTRiOTg3NjVhMzRlM2U4MCIsInVzZXJfaWQiOiI2In0.KHYYQyDe-YtOqiOO4x7Ju_w5yEXsrAf4CZ--WNCUtTI','2026-01-05 10:45:40.682835','2026-01-12 10:45:40.000000',6,'721a172c8044472d94b98765a34e3e80'),(53,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIxOTM4NSwiaWF0IjoxNzY3NjE0NTg1LCJqdGkiOiJkMTNhNDM2MzlmOTM0YTk3ODg0NzIyMjRmZjY5NTU0OSIsInVzZXJfaWQiOiIzIn0.QpnEd2Zdz9W7eE8fSxn9ivHJRsotgCX-txOgP83kUUA','2026-01-05 12:03:05.994577','2026-01-12 12:03:05.000000',3,'d13a43639f934a9788472224ff695549'),(54,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMDU3OCwiaWF0IjoxNzY3NjE1Nzc4LCJqdGkiOiJjZTMxMWNhYzlkMzI0MDEwYjA2N2I2Yzg5ZGNlMDg3YyIsInVzZXJfaWQiOiI2In0.7yMH-E8-zXa5vCH5Lk-M-qrNpAM7SErfoG7IxkDVvAw','2026-01-05 12:22:58.223821','2026-01-12 12:22:58.000000',6,'ce311cac9d324010b067b6c89dce087c'),(55,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMDczNCwiaWF0IjoxNzY3NjE1OTM0LCJqdGkiOiIwY2I0Y2IzMGRjM2U0MTU5OTVlNTdmZjE1NWU2NzhkMiIsInVzZXJfaWQiOiI2In0.DQKyU12WG6q1608f5rTB7MwQUnxciccqds2RwNTnEFM','2026-01-05 12:25:34.712158','2026-01-12 12:25:34.000000',6,'0cb4cb30dc3e415995e57ff155e678d2'),(56,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMDg3OSwiaWF0IjoxNzY3NjE2MDc5LCJqdGkiOiIyMmQyYzkwZGMyNzY0ZjAxODE1YzRjYmY4YjMzMjQxYiIsInVzZXJfaWQiOiI2In0.ZDeLPm9UlfkY4HSDF_C0NSYGzFUmGyoG9TpikBpIncw','2026-01-05 12:27:59.817196','2026-01-12 12:27:59.000000',6,'22d2c90dc2764f01815c4cbf8b33241b'),(57,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMDkwNSwiaWF0IjoxNzY3NjE2MTA1LCJqdGkiOiIxYjI2NDIzMDliZGI0MzEwYjBiMTE5ODkyNmY1YzVlYyIsInVzZXJfaWQiOiI2In0.X2moRdTbK_ND9ppCOnXXJ8nDFvzdJEN473J4wQPnMe8','2026-01-05 12:28:25.223240','2026-01-12 12:28:25.000000',6,'1b2642309bdb4310b0b1198926f5c5ec'),(58,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMTAwMCwiaWF0IjoxNzY3NjE2MjAwLCJqdGkiOiJkNzZiNTZkOTRmOWM0ODU5YmUwNmRmMjE5MjFkODBmMyIsInVzZXJfaWQiOiI2In0.RgsM1DKAFf8q6abA3gKxBKvyR-HnLubzs2rg0oep_fY','2026-01-05 12:30:00.192767','2026-01-12 12:30:00.000000',6,'d76b56d94f9c4859be06df21921d80f3'),(59,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMTIwNiwiaWF0IjoxNzY3NjE2NDA2LCJqdGkiOiJiZDFiOGUyMjg1OGE0MDA3OTAyZmIzMzY2MjI2NTQ1NyIsInVzZXJfaWQiOiI2In0.JdvDqNcIvwZXRpOBFKl7rCQi23M4OuslDiniajuC370','2026-01-05 12:33:26.328691','2026-01-12 12:33:26.000000',6,'bd1b8e22858a4007902fb33662265457'),(60,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMTQwNSwiaWF0IjoxNzY3NjE2NjA1LCJqdGkiOiI0ZjM0Y2M2Yjc3OTM0NWY2YTUzYzI5YzZhZWUyMTNhZSIsInVzZXJfaWQiOiIzIn0.jjdGVV41-UOGK8iJaRPDF6OZ32CPkca6fP6eIAAg-1c','2026-01-05 12:36:45.262231','2026-01-12 12:36:45.000000',3,'4f34cc6b779345f6a53c29c6aee213ae'),(61,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMTQ5MywiaWF0IjoxNzY3NjE2NjkzLCJqdGkiOiI3ZjQyMGQ1YTViMGY0YmQ3YTVkZDNjNjU2NTg2NjRkMCIsInVzZXJfaWQiOiIxIn0.VBiQT312BLk4NbJNttiij-zEzxUFSp1ijuax8nozg4M','2026-01-05 12:38:13.502618','2026-01-12 12:38:13.000000',1,'7f420d5a5b0f4bd7a5dd3c65658664d0'),(62,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMjM2NiwiaWF0IjoxNzY3NjE3NTY2LCJqdGkiOiI1ZTA2M2UwODM0OTI0ZDg0OTFhNTVmNzBiZGY3MmRjNCIsInVzZXJfaWQiOiI2In0.PJkbu9Z1iG1B612J4to1KVGDkF6MFNHjOvs6we3VGFs','2026-01-05 12:52:46.750213','2026-01-12 12:52:46.000000',6,'5e063e0834924d8491a55f70bdf72dc4'),(63,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMjY4MywiaWF0IjoxNzY3NjE3ODgzLCJqdGkiOiJlMTBkZDlmODUwZmQ0MTNmOTU5N2IwY2Q5MTAyOGVjMiIsInVzZXJfaWQiOiI3In0.kyDz37n-tOKGv7gnxJ1Yy_GVXK4lLGpphqPcbWdnduk','2026-01-05 12:58:03.411541','2026-01-12 12:58:03.000000',7,'e10dd9f850fd413f9597b0cd91028ec2'),(64,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMjkxMSwiaWF0IjoxNzY3NjE4MTExLCJqdGkiOiIwZGJkMzQzNjVhOTI0NDBkOTY2MDM0OWEyMzU5MDQ3OCIsInVzZXJfaWQiOiI2In0.InNp89HLwVlGnWE6xTSmvxVNq4VTayAg8rlsaVwjlj0','2026-01-05 13:01:51.601676','2026-01-12 13:01:51.000000',6,'0dbd34365a92440d9660349a23590478'),(65,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyMzQ4MCwiaWF0IjoxNzY3NjE4NjgwLCJqdGkiOiI0NTBhNDRhZGZmYjc0ZmJhYmM3MDAzY2E1N2MwN2VjYSIsInVzZXJfaWQiOiIxIn0.3TpR0BeknDTkMH5O0hH_dUhwSlCJPsF3WDU96cUOHdI','2026-01-05 13:11:20.454748','2026-01-12 13:11:20.000000',1,'450a44adffb74fbabc7003ca57c07eca'),(66,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNDA0OCwiaWF0IjoxNzY3NjE5MjQ4LCJqdGkiOiI1NjM1YTlmODIzZTI0MWRjOTkyYzRjMzU3ZGQ3NWJlMiIsInVzZXJfaWQiOiI3In0.txMLq8MZhZ0_jYrscjWLKkZX_a4GSVvNhEiYqQfXSLw','2026-01-05 13:20:48.112929','2026-01-12 13:20:48.000000',7,'5635a9f823e241dc992c4c357dd75be2'),(67,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNDE2OCwiaWF0IjoxNzY3NjE5MzY4LCJqdGkiOiJhYTNlNWI4NmE0MWU0NDhjYTRhNmEzZmU0NTgzODQ2NSIsInVzZXJfaWQiOiI5In0.WEwYVW9LiQhD61t6naYjLLfOWZelDJF4PyBjPuR5ZAQ','2026-01-05 13:22:48.577858','2026-01-12 13:22:48.000000',9,'aa3e5b86a41e448ca4a6a3fe45838465'),(68,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNDI2OCwiaWF0IjoxNzY3NjE5NDY4LCJqdGkiOiJmMmUyZjIwMGYxYjI0YTFhYjhjN2JiMjg3ZWYzZGRlZSIsInVzZXJfaWQiOiI5In0.wgrOA4iprSKkoCRprnc6Wqz48-HtPyVh2udDyVWySPc','2026-01-05 13:24:28.499098','2026-01-12 13:24:28.000000',9,'f2e2f200f1b24a1ab8c7bb287ef3ddee'),(69,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNDM3NSwiaWF0IjoxNzY3NjE5NTc1LCJqdGkiOiJlZjgyNGNkZDQyMDY0NjdmOTg1OTUyNTk3NDc2MGE4OCIsInVzZXJfaWQiOiIzIn0.MRNotVmb2iE93uWeb7Klip_1OmE21FVZXe1okVkFq3I','2026-01-05 13:26:15.394160','2026-01-12 13:26:15.000000',3,'ef824cdd4206467f9859525974760a88'),(70,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNDM5MywiaWF0IjoxNzY3NjE5NTkzLCJqdGkiOiIwOTE0MDU2ODY1YWI0MGQ3YmJjZjE4YzgxOTI0NjkxYSIsInVzZXJfaWQiOiIxIn0.6zYg9DuXY1EM2LnVMGb-Z5pJq9EoHRtT-NVJK4HCD1o','2026-01-05 13:26:33.543964','2026-01-12 13:26:33.000000',1,'0914056865ab40d7bbcf18c81924691a'),(71,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNDY0MywiaWF0IjoxNzY3NjE5ODQzLCJqdGkiOiIxZGZjYTdhNGQ2Y2E0MDQ4ODUxNjBlODcyZWYyZmNmYSIsInVzZXJfaWQiOiI2In0.U0m41WMVk4ZO9p9mGP0Ofjhns6CBk09ZvJQx3JkpUug','2026-01-05 13:30:43.552932','2026-01-12 13:30:43.000000',6,'1dfca7a4d6ca404885160e872ef2fcfa'),(72,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNDk2MiwiaWF0IjoxNzY3NjIwMTYyLCJqdGkiOiJlODUxMmIwNjNkMGY0ZDgzODAwYjRkZWQ4OGQ5MDZlMSIsInVzZXJfaWQiOiI3In0.O4OIVk6vtm7R-BhE2iVnkqZKfsty4-gVcf_Yo286Wjw','2026-01-05 13:36:02.557006','2026-01-12 13:36:02.000000',7,'e8512b063d0f4d83800b4ded88d906e1'),(73,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNTA1MiwiaWF0IjoxNzY3NjIwMjUyLCJqdGkiOiJiYTU4ZWMxNTQwOGI0NzA0YjM2YWY2OWZiY2Y5MDNkNSIsInVzZXJfaWQiOiI5In0.w8WDbj66g26sKouUM0HpHQJkEF0V7L_61sJiSeAAXfY','2026-01-05 13:37:32.669511','2026-01-12 13:37:32.000000',9,'ba58ec15408b4704b36af69fbcf903d5'),(74,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNTQ4OSwiaWF0IjoxNzY3NjIwNjg5LCJqdGkiOiIxODVkOTIxMTdhZmY0ZjcxOWE0ZjcxY2MyM2NmMjdjZCIsInVzZXJfaWQiOiI2In0.mS4EdpEAWURmIPIQzZqfOC_E96rlUWuFt-4oIdA7Gf8','2026-01-05 13:44:49.930233','2026-01-12 13:44:49.000000',6,'185d92117aff4f719a4f71cc23cf27cd'),(75,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODIyNjI0MSwiaWF0IjoxNzY3NjIxNDQxLCJqdGkiOiI5Njg2NGMwZWI5Y2M0ODg5YWMzNjQ1YTJlMjQxODUxZiIsInVzZXJfaWQiOiI5In0.S6C_auwQfO_G4uNZMAPQEm3Np6sfEAgZDpbxo4oWV9Q','2026-01-05 13:57:21.028151','2026-01-12 13:57:21.000000',9,'96864c0eb9cc4889ac3645a2e241851f'),(76,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4MTY3MCwiaWF0IjoxNzY3Njc2ODcwLCJqdGkiOiI2Njk1YTJiNDQ1YjI0OWRhOTQyOTg2NmYxZWUxN2Q0MyIsInVzZXJfaWQiOiI2In0.SLHx1XdSJhMzVPaDW8tNNc4_z6MNsp16Rtm9kSJP0aU','2026-01-06 05:21:10.380501','2026-01-13 05:21:10.000000',6,'6695a2b445b249da9429866f1ee17d43'),(77,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4NDI5MCwiaWF0IjoxNzY3Njc5NDkwLCJqdGkiOiJhMTFjMzdkNTI4ZTA0YThhYmQ1MTkwOGM4MjdkYzM4NCIsInVzZXJfaWQiOiI2In0.l1cuXnTwPK-RnEzxD5Bcyn8qukvmLCxsn9QIZEtO_54','2026-01-06 06:04:50.990165','2026-01-13 06:04:50.000000',6,'a11c37d528e04a8abd51908c827dc384'),(78,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4NTQwOCwiaWF0IjoxNzY3NjgwNjA4LCJqdGkiOiJiYTJkNjY1NGFiOTE0NjhkYWYyYjhkYjAyNTczNTdiZiIsInVzZXJfaWQiOiI2In0.nY3Pt9bIJEJmZrGdmqbg4RlJOo1DQRsrkPBAettU2pc','2026-01-06 06:23:28.208104','2026-01-13 06:23:28.000000',6,'ba2d6654ab91468daf2b8db0257357bf'),(79,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4NTQwOCwiaWF0IjoxNzY3NjgwNjA4LCJqdGkiOiJhMGEzZDU1ZThhYzM0MTA4YTY0OTBhODk2OGZmOWQ0YSIsInVzZXJfaWQiOiI2In0.Wwi7YvmqzJx7HUHf2TbYiDhuWX5_eMidVvcKUI86MBY','2026-01-06 06:23:28.213805','2026-01-13 06:23:28.000000',6,'a0a3d55e8ac34108a6490a8968ff9d4a'),(80,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4NzYwNywiaWF0IjoxNzY3NjgyODA3LCJqdGkiOiI0YmIwOTEwODExNTM0NGRkODhkNjEyNGQwYWQxN2MzYSIsInVzZXJfaWQiOiI2In0.jRTNn5Fz2t66Jhk7wK9QqrMSXCn9ewHj701wxWmGUyk','2026-01-06 07:00:07.999128','2026-01-13 07:00:07.000000',6,'4bb09108115344dd88d6124d0ad17c3a'),(81,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4NzY4OCwiaWF0IjoxNzY3NjgyODg4LCJqdGkiOiIzNzQzNTAxOWUyZmQ0NzkyYmZhOTkyNDE0MzA2YmQ4ZiIsInVzZXJfaWQiOiI2In0.AGtozMfikj_YawUVlD3CHst4rSQdMOSiHisnU3EtuNg','2026-01-06 07:01:28.969694','2026-01-13 07:01:28.000000',6,'37435019e2fd4792bfa992414306bd8f'),(82,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4Nzc2NiwiaWF0IjoxNzY3NjgyOTY2LCJqdGkiOiJmODY5ZTFiYjIwYzk0YTgzYmIxMWY2YjYxY2QzZTgyYiIsInVzZXJfaWQiOiIxIn0.xx_HzOrsUeBJGLYZgPOc89chgKwW77nOLORXvllzLOo','2026-01-06 07:02:46.826020','2026-01-13 07:02:46.000000',1,'f869e1bb20c94a83bb11f6b61cd3e82b'),(83,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODMxMSwiaWF0IjoxNzY3NjgzNTExLCJqdGkiOiJhNzMyMTkwNGEwZjc0NWRiYmI0YzE1MTIxZWQwNjQ5OCIsInVzZXJfaWQiOiI2In0.zkG6Lw2xwoEJIjDWRHB3QH1h43_ty1e9b9Jj0V46NeE','2026-01-06 07:11:51.244308','2026-01-13 07:11:51.000000',6,'a7321904a0f745dbbb4c15121ed06498'),(84,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODU1NCwiaWF0IjoxNzY3NjgzNzU0LCJqdGkiOiJmMmFhY2IwMGM3NGU0Y2MzOGYxMjEwN2MzNzUzODQ5NiIsInVzZXJfaWQiOiI3In0.emCZS9Qck6HZK-KfEMZrg5ieoXzsEuKtWwF0IBOY8WE','2026-01-06 07:15:54.342166','2026-01-13 07:15:54.000000',7,'f2aacb00c74e4cc38f12107c37538496'),(85,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODU3OCwiaWF0IjoxNzY3NjgzNzc4LCJqdGkiOiIxNzYzMWIzNmRhN2I0NDE3OWJkZGI4NDI3OGE5ZWExZiIsInVzZXJfaWQiOiIxIn0.d37hMT3NR_mHpsuyNuvREjnMEgNehdHHIntU4PtAfo8','2026-01-06 07:16:18.034201','2026-01-13 07:16:18.000000',1,'17631b36da7b44179bddb84278a9ea1f'),(86,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODYyMCwiaWF0IjoxNzY3NjgzODIwLCJqdGkiOiI1MzRhNTU1YWVkMTE0OGY3ODc0YjkwNmVjNDc1MjBjNSIsInVzZXJfaWQiOiIzIn0.lTgmwaNp7rTdrNQjWH1_B9IndFredYwS_q72lKbxLhE','2026-01-06 07:17:00.156799','2026-01-13 07:17:00.000000',3,'534a555aed1148f7874b906ec47520c5'),(87,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODYyMCwiaWF0IjoxNzY3NjgzODIwLCJqdGkiOiJmZGU0MGEyNTExMTA0ZGVlYWU5OGM2OTRlMTMxMzA3ZSIsInVzZXJfaWQiOiIzIn0.tymQRtnKkSZvlHdrShHY7uut311pay4tZl5IfnieCdM','2026-01-06 07:17:00.210824','2026-01-13 07:17:00.000000',3,'fde40a2511104deeae98c694e131307e'),(88,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODYyMCwiaWF0IjoxNzY3NjgzODIwLCJqdGkiOiI5MjFkZGNlN2NhYmU0MGUwODYwNzcyZGQ1M2Y4NGU0MCIsInVzZXJfaWQiOiIzIn0.fFAnFguRQw0Kv25kCZBp40oKZnzSZKJpDEOFw7AZlzc','2026-01-06 07:17:00.164802','2026-01-13 07:17:00.000000',3,'921ddce7cabe40e0860772dd53f84e40'),(89,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODYyMCwiaWF0IjoxNzY3NjgzODIwLCJqdGkiOiJiMDRlM2M4NzMxYmU0MTNiYjhmYmRhNzM4ZTMwNDQ2ZiIsInVzZXJfaWQiOiIzIn0.aVtp1z4iuQYcSzSJypAJ6IHJ7_gH2FckFus2q5mZGHM','2026-01-06 07:17:00.167930','2026-01-13 07:17:00.000000',3,'b04e3c8731be413bb8fbda738e30446f'),(90,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODYyMCwiaWF0IjoxNzY3NjgzODIwLCJqdGkiOiJkODMwNThiMjc2YTQ0MjY3ODA2Njg3MjAxZGYzY2ZjYyIsInVzZXJfaWQiOiIzIn0.33o41CqayJfC3EDeMAZfVS9vdRblj7LoE6WOwuV18QM','2026-01-06 07:17:00.166813','2026-01-13 07:17:00.000000',3,'d83058b276a44267806687201df3cfcc'),(91,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4ODYyNSwiaWF0IjoxNzY3NjgzODI1LCJqdGkiOiIxNjdmN2Q3YjgyNWY0MjUwYjYyZGE0NGE3OThhZWI1MCIsInVzZXJfaWQiOiI2In0.Qz3W52PdSYRUKRvTYVhAzOB18qxgbxB-l9oXy7yBpzc','2026-01-06 07:17:05.513851','2026-01-13 07:17:05.000000',6,'167f7d7b825f4250b62da44a798aeb50'),(92,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4OTEzNCwiaWF0IjoxNzY3Njg0MzM0LCJqdGkiOiJjNTdhODdkNTIxYTg0YWU4YmM0OTNhMzBkNmNlMmJjNyIsInVzZXJfaWQiOiI5In0.35i4MmUmZ5xYNXqOEr34DbQviwazHNIZ_YpYpKxqsME','2026-01-06 07:25:34.453131','2026-01-13 07:25:34.000000',9,'c57a87d521a84ae8bc493a30d6ce2bc7'),(93,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI4OTIxNCwiaWF0IjoxNzY3Njg0NDE0LCJqdGkiOiI0YjZjM2Q5MjQwZGM0OTVhODE2YjU0Mzk0ZTQwODRjMiIsInVzZXJfaWQiOiI5In0.5Pmi1NzkLbExzgmCoKplEWKKKR9Gov7hrPJ1pSYUXus','2026-01-06 07:26:54.915302','2026-01-13 07:26:54.000000',9,'4b6c3d9240dc495a816b54394e4084c2'),(94,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5MzE4NywiaWF0IjoxNzY3Njg4Mzg3LCJqdGkiOiIxNTc2MDFmZWE2NTk0NmVjOGRkYzcwNWVkODc3NmI3ZiIsInVzZXJfaWQiOiI2In0.BcwalQzSXMZlN_oPnG572GPMdQBCyNSL5K-9G-ykcDo','2026-01-06 08:33:07.874831','2026-01-13 08:33:07.000000',6,'157601fea65946ec8ddc705ed8776b7f'),(95,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5MzE4NywiaWF0IjoxNzY3Njg4Mzg3LCJqdGkiOiIyZTk1ZTFkYTk5ODk0NWVmODNkMjFhYzJkMzY5NDg4OSIsInVzZXJfaWQiOiI2In0.Vsu8byzwSstXY5GnzFIOJOWVPtJWN_iUm9LE3V3Ee3w','2026-01-06 08:33:07.880651','2026-01-13 08:33:07.000000',6,'2e95e1da998945ef83d21ac2d3694889'),(96,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5MzIwMiwiaWF0IjoxNzY3Njg4NDAyLCJqdGkiOiI2NWZhY2Q5NWRlZTY0ZjU5YWRkMzBlN2QwZWM5NDMyYyIsInVzZXJfaWQiOiI5In0.3k_g-Z6QNTsRY4mIemM7avxvStypfAQGggvX8lUgZl8','2026-01-06 08:33:22.224275','2026-01-13 08:33:22.000000',9,'65facd95dee64f59add30e7d0ec9432c'),(97,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5MzIwMiwiaWF0IjoxNzY3Njg4NDAyLCJqdGkiOiI3OGYwNmExMjcwMmM0MzE5YTg1ZmY2MGQ4MmUzYTMyMyIsInVzZXJfaWQiOiI5In0.4Hbc-BNwkP6tf6XwQ0UJpVtHV_WLp222woOQ4WdvUs8','2026-01-06 08:33:22.235671','2026-01-13 08:33:22.000000',9,'78f06a12702c4319a85ff60d82e3a323'),(98,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5MzIwMiwiaWF0IjoxNzY3Njg4NDAyLCJqdGkiOiI5Zjk4OTM2Yzk5NGY0NWNjOTU4NmM4MzVkZmRiYTYzNyIsInVzZXJfaWQiOiIxIn0._bYOZr3ib6rSVkKXij7sq1NpLVg8GnTZiojeBYhg9tY','2026-01-06 08:33:22.675072','2026-01-13 08:33:22.000000',1,'9f98936c994f45cc9586c835dfdba637'),(99,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5MzIwMiwiaWF0IjoxNzY3Njg4NDAyLCJqdGkiOiI3ZDNlOWQ1NTQ2MTI0NjhmYTM0ZDgxY2FkOWM1NTgzNSIsInVzZXJfaWQiOiIxIn0.Qmd-HeQ6m-WZXcVFihr_gJNpwhNhmngAOmILIypIlEw','2026-01-06 08:33:22.682437','2026-01-13 08:33:22.000000',1,'7d3e9d554612468fa34d81cad9c55835'),(100,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5MzIxOSwiaWF0IjoxNzY3Njg4NDE5LCJqdGkiOiJjM2FkNTMyMjMwOWM0ZTFiYTE2OTkwYTNkYjU3NTUxMiIsInVzZXJfaWQiOiI5In0.GjEjrdNh6xaif_fwb8p2TXZmiuXUoOSgYhNtRoUUs2M','2026-01-06 08:33:39.025801','2026-01-13 08:33:39.000000',9,'c3ad5322309c4e1ba16990a3db575512'),(101,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5NDAyMywiaWF0IjoxNzY3Njg5MjIzLCJqdGkiOiI3NzI3MzM3ZmVmMDg0ZmQxODNjNGVmNWQyZmEzMTVkOSIsInVzZXJfaWQiOiI5In0.y-434CxmYG1CFVtqnGmpDzSHlH03AV0tdWjcQmFFy2U','2026-01-06 08:47:03.082914','2026-01-13 08:47:03.000000',9,'7727337fef084fd183c4ef5d2fa315d9'),(102,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5NDcwOCwiaWF0IjoxNzY3Njg5OTA4LCJqdGkiOiJmNTQ2ZjkzYmM1OTI0NDAyYmRmZjY1YmM4YmFhNjIzYyIsInVzZXJfaWQiOiI5In0.OixEwt94db1a61QsL4dDW1I2kpX42sJBtIh4mBMdaS0','2026-01-06 08:58:28.204780','2026-01-13 08:58:28.000000',9,'f546f93bc5924402bdff65bc8baa623c'),(103,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5NjM4MiwiaWF0IjoxNzY3NjkxNTgyLCJqdGkiOiIzYzEwNTA3NjMyMjI0NmU4OWYzMTQ2MzQ2ZDlkNzkwYSIsInVzZXJfaWQiOiI2In0.Vx0k5can6uj7sTR4DOkcET0V5Fb1CvuG0COAgpVgNi8','2026-01-06 09:26:22.759741','2026-01-13 09:26:22.000000',6,'3c105076322246e89f3146346d9d790a'),(104,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5ODQ3NCwiaWF0IjoxNzY3NjkzNjc0LCJqdGkiOiJmZmNkNDJkNWY2NWE0MDQ5ODgwZGM5NjlmZTY5NjU0MSIsInVzZXJfaWQiOiI5In0.dEc2u8eztVXUeTw7njG5Zkg3GuynTeRnC4HCVgVOS08','2026-01-06 10:01:14.902069','2026-01-13 10:01:14.000000',9,'ffcd42d5f65a4049880dc969fe696541'),(105,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5ODQ4MywiaWF0IjoxNzY3NjkzNjgzLCJqdGkiOiI1MGQxNDc0NWZjOTY0YTM5YWQ0OWMwMDIwNWYwZDU3MiIsInVzZXJfaWQiOiIxIn0.aMoEGQlazjUxrnS9i1yaQbDaOd3HSRcwzzPn0YTOgv0','2026-01-06 10:01:23.914196','2026-01-13 10:01:23.000000',1,'50d14745fc964a39ad49c00205f0d572'),(106,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5ODU3MywiaWF0IjoxNzY3NjkzNzczLCJqdGkiOiJhYjA1MmJiNjg0Njk0ODljODMxZDM4NjA2YTllNDI2NCIsInVzZXJfaWQiOiIxIn0.LF9ef4SqQfl6yzsqcFs4_JE3hxFR1BaX_wSDoXxpBL4','2026-01-06 10:02:53.589082','2026-01-13 10:02:53.000000',1,'ab052bb68469489c831d38606a9e4264'),(107,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5ODY4MSwiaWF0IjoxNzY3NjkzODgxLCJqdGkiOiI3MTUzYjIxYTJlOWM0ZTkwYjJjYjNiYWZhNmRhMWE2NSIsInVzZXJfaWQiOiI2In0.q4YTDx39h20vgzoUO4B6RqxVCpPVmw5sRMLLpfHMoXg','2026-01-06 10:04:41.046755','2026-01-13 10:04:41.000000',6,'7153b21a2e9c4e90b2cb3bafa6da1a65'),(108,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5ODgxNiwiaWF0IjoxNzY3Njk0MDE2LCJqdGkiOiJhNGZjY2U5MDZmMDg0Yzg0YThjZTk4YzM4ZWNhOGI0MSIsInVzZXJfaWQiOiI2In0.56Nvm-I9Q26Jj9aUVUMvV5McboLdz-Nxe2Z5HGaAdIg','2026-01-06 10:06:56.788663','2026-01-13 10:06:56.000000',6,'a4fcce906f084c84a8ce98c38eca8b41'),(109,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5ODkyMCwiaWF0IjoxNzY3Njk0MTIwLCJqdGkiOiI0MjQ3NGQzMzg0YTU0MDhmYmZkNDVjYTM5ODI0MDk0MSIsInVzZXJfaWQiOiI2In0.GlLhNW61x6JN702ECDxX3oDYSNlrrLG4tS1Ty-DxKGM','2026-01-06 10:08:40.954348','2026-01-13 10:08:40.000000',6,'42474d3384a5408fbfd45ca398240941'),(110,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODI5OTM3NSwiaWF0IjoxNzY3Njk0NTc1LCJqdGkiOiIzMmZhNDQ1ZTcwM2E0MmMwYTk3MjIzMjlhZmRlNGI3MyIsInVzZXJfaWQiOiIxMCJ9.E97yXA4-uYXOZiPnkdfY8912Om-374RsRbbouRaq4Xk','2026-01-06 10:16:15.340081','2026-01-13 10:16:15.000000',10,'32fa445e703a42c0a9722329afde4b73'),(111,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMTU4MSwiaWF0IjoxNzY3Njk2NzgxLCJqdGkiOiJkY2Q0NWJkYmY4MjE0YjVjYTEyNTI3MTE0YjFlNjE0MyIsInVzZXJfaWQiOiIxIn0.BgPWhzgEdXxZFguHnbK83U1ZU7Xq1DBQhdmRUEN5bcs','2026-01-06 10:53:01.490570','2026-01-13 10:53:01.000000',1,'dcd45bdbf8214b5ca12527114b1e6143'),(112,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMTU4MSwiaWF0IjoxNzY3Njk2NzgxLCJqdGkiOiIxMTk4YjM4YWM3ZmE0ZjU4ODNjZGRlNmUzZTRlZTM4ZiIsInVzZXJfaWQiOiIxIn0.yekOBZdZHhABBo6IQPycrDqc2chdJvs1EPaXnnsdN_U','2026-01-06 10:53:01.460633','2026-01-13 10:53:01.000000',1,'1198b38ac7fa4f5883cdde6e3e4ee38f'),(113,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMTU4MSwiaWF0IjoxNzY3Njk2NzgxLCJqdGkiOiJmNmM0NmZjYjlkMjE0NDgyYWUyZTUwZWY5NTJkMTcxNCIsInVzZXJfaWQiOiIxIn0.GccKbgVLaq75Tb2FYocUAQcOpPj3WYFvly9qFztryy8','2026-01-06 10:53:01.472724','2026-01-13 10:53:01.000000',1,'f6c46fcb9d214482ae2e50ef952d1714'),(114,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMTU4MSwiaWF0IjoxNzY3Njk2NzgxLCJqdGkiOiJiNGM5OWIwMGMzYjc0YzgwOGI1NzgwMjUxYmM3NTU2MSIsInVzZXJfaWQiOiIxIn0.Oi6bJI8dqrVmoLY8BRhEJ2VIldpu9D05xtQ7-wLi8nk','2026-01-06 10:53:01.487250','2026-01-13 10:53:01.000000',1,'b4c99b00c3b74c808b5780251bc75561'),(115,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMTU4MSwiaWF0IjoxNzY3Njk2NzgxLCJqdGkiOiJhZTg1MzI4MzQ2NGM0Njg4YWY3ODc0MzUxMjc5NGJmNSIsInVzZXJfaWQiOiIxIn0.4VNHq2NJxSSP3Vnel6x-jSnJw5BaQY3N-kZv6pD4RRA','2026-01-06 10:53:01.465567','2026-01-13 10:53:01.000000',1,'ae853283464c4688af78743512794bf5'),(116,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMTc0MywiaWF0IjoxNzY3Njk2OTQzLCJqdGkiOiIwNDZlZjczYmI1YzU0OGIzOGQ0NmU0MGU5OTMzZjQ2NiIsInVzZXJfaWQiOiIxMCJ9.sGiY8D39Cl96dV9JafGlPiDlOY_cKd7kXvKmyNxUqQ8','2026-01-06 10:55:43.313147','2026-01-13 10:55:43.000000',10,'046ef73bb5c548b38d46e40e9933f466'),(117,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMTc0MywiaWF0IjoxNzY3Njk2OTQzLCJqdGkiOiI2NTBiYTQwZmI1Yzc0ZjQyOWUwZWJmNDFiNjA4NDFjNCIsInVzZXJfaWQiOiIxMCJ9.uVpfk3QS4US0-g2VbolKaf99fzTRPd8BK4DI46DP1uQ','2026-01-06 10:55:43.311727','2026-01-13 10:55:43.000000',10,'650ba40fb5c74f429e0ebf41b60841c4'),(118,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMjE2MCwiaWF0IjoxNzY3Njk3MzYwLCJqdGkiOiJlOTkwYmVkNDgwYjU0MWNmODEyMjA3MDkxMzdhZDkyNCIsInVzZXJfaWQiOiI2In0.iopCz74YFhpt8My26bkM1AtVElfXbcB_p3upXb5qyQQ','2026-01-06 11:02:40.288669','2026-01-13 11:02:40.000000',6,'e990bed480b541cf81220709137ad924'),(119,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMjkyMiwiaWF0IjoxNzY3Njk4MTIyLCJqdGkiOiJkZWUyZWFjNmNiMTI0MTRhYWMxZGY2NWJmMTEzNDNlMiIsInVzZXJfaWQiOiIzIn0.lfzKtWBxeRJbhGJ-qZYFD4gJ0wtclgdCm0QEefS6YiE','2026-01-06 11:15:22.248141','2026-01-13 11:15:22.000000',3,'dee2eac6cb12414aac1df65bf11343e2'),(120,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMjk1MSwiaWF0IjoxNzY3Njk4MTUxLCJqdGkiOiIxMjhkOTc2OTQ5ZDc0MTUzODA1YzE2NjRjNmVmNzgzMCIsInVzZXJfaWQiOiIzIn0.pEFGR6F2cUqFLO-JkS61HZLLAcuVyi060bGHF9nIrZc','2026-01-06 11:15:51.227934','2026-01-13 11:15:51.000000',3,'128d976949d74153805c1664c6ef7830'),(121,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMzAzMSwiaWF0IjoxNzY3Njk4MjMxLCJqdGkiOiI5NzBiOGRjZGMzMGE0OTBlODQwNTFhMWQyNzQ0ZDc2OSIsInVzZXJfaWQiOiIxIn0.eLISSSPp_rO9OioPm8WOci7ShqBnwFqmfu2I-kAP1Vg','2026-01-06 11:17:11.256608','2026-01-13 11:17:11.000000',1,'970b8dcdc30a490e84051a1d2744d769'),(122,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwMzUxNywiaWF0IjoxNzY3Njk4NzE3LCJqdGkiOiJjYWYxN2Y5Zjk2ODc0ZDA1YTU3MzVkMGIxYzI1OGZmNyIsInVzZXJfaWQiOiIzIn0.PUHNUy8eqs2vAtW-BMEQO1rIOKvEyqJGhtQRYmdc180','2026-01-06 11:25:17.940879','2026-01-13 11:25:17.000000',3,'caf17f9f96874d05a5735d0b1c258ff7'),(123,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwNTk4OSwiaWF0IjoxNzY3NzAxMTg5LCJqdGkiOiJiYmYzOGQ2YTQ2OTk0NTg0OWZhOTRhNzE2NjdmZWRhOCIsInVzZXJfaWQiOiI2In0.JuYdeqHz2XrJEIalR5wXFBC0dmLSBOOfl4fpvXcRrJY','2026-01-06 12:06:29.915193','2026-01-13 12:06:29.000000',6,'bbf38d6a469945849fa94a71667feda8'),(124,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwNjc2NSwiaWF0IjoxNzY3NzAxOTY1LCJqdGkiOiJhMGUyYzEyYTE5OTU0MWM4YjcwZTc4NDFjODk0YzMwMiIsInVzZXJfaWQiOiIzIn0.UmozsJ0f032JSkVZlqI_ZwrMgMw4ufQ0i24BigAMM2c','2026-01-06 12:19:25.981055','2026-01-13 12:19:25.000000',3,'a0e2c12a199541c8b70e7841c894c302'),(125,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwNzc5MywiaWF0IjoxNzY3NzAyOTkzLCJqdGkiOiJmMmE3ZTczNGIxNjQ0OGNhOTFlMzE0ZWUwMjY1MzUyOSIsInVzZXJfaWQiOiI2In0.SySzHqLN8KynfeXUYtEN79wseaAwDMxy33fJlE_j0XQ','2026-01-06 12:36:33.813331','2026-01-13 12:36:33.000000',6,'f2a7e734b16448ca91e314ee02653529'),(126,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODMwODE4NywiaWF0IjoxNzY3NzAzMzg3LCJqdGkiOiJmNjE1MGFhYmI2MjE0MTQ0YjVlMzIzYmZkZDIwYWEwNiIsInVzZXJfaWQiOiI2In0.qkOuZQ7fyqaaZCu4mAWtvntwJHpN3L7MxNgrEX_6EV0','2026-01-06 12:43:07.178341','2026-01-13 12:43:07.000000',6,'f6150aabb6214144b5e323bfdd20aa06'),(127,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM2NzY4NiwiaWF0IjoxNzY3NzYyODg2LCJqdGkiOiIwOWI0OWVkN2Q0ZjY0YTMwYTIxMDFhOGI0NDgyMTYzMyIsInVzZXJfaWQiOiI5In0.dRbED9RP-Nhw2yCVJwVeAynw6P3lo-TgL2SIwJatSdY','2026-01-07 05:14:46.300659','2026-01-14 05:14:46.000000',9,'09b49ed7d4f64a30a2101a8b44821633'),(128,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM2NzgzMCwiaWF0IjoxNzY3NzYzMDMwLCJqdGkiOiJjNjRmYTlmNDcwNWY0MDJiODRhYzk5ZDM5NjE2M2IxMiIsInVzZXJfaWQiOiI5In0.SKemoAqUp2YTTSqlRUtWRRE20ydcrs2KORmGRdEg60w','2026-01-07 05:17:10.216660','2026-01-14 05:17:10.000000',9,'c64fa9f4705f402b84ac99d396163b12'),(129,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM3MjA4NiwiaWF0IjoxNzY3NzY3Mjg2LCJqdGkiOiIzMGM5MTk4MDA3Y2U0NjU2ODA2NjI0NjdjMzQxMGNkMCIsInVzZXJfaWQiOiI5In0.lB7PapHgYDIoruNpdg-t50-_WXUKNHBmUXqHT0I7-os','2026-01-07 06:28:06.085001','2026-01-14 06:28:06.000000',9,'30c9198007ce465680662467c3410cd0'),(130,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM3MzQ1MCwiaWF0IjoxNzY3NzY4NjUwLCJqdGkiOiJhMDgyNTY3NjgxZmE0YTc5OWU4NzY0YjRjNTZkY2NjNSIsInVzZXJfaWQiOiI5In0.T_EwbU5JomaIjnUZIZGeN89QbnmPSidM9Jq0FWmjh3o','2026-01-07 06:50:50.101431','2026-01-14 06:50:50.000000',9,'a082567681fa4a799e8764b4c56dccc5'),(131,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM3NTc2OSwiaWF0IjoxNzY3NzcwOTY5LCJqdGkiOiI5YmNhZmJjMDYzZDE0YTc5YWUyYzAzN2E4YjY1YjFkNCIsInVzZXJfaWQiOiIzIn0.UFhLCaVTWobnwfiFqqC8ImKaip9CzSWH_Cjm6NdS8Tc','2026-01-07 07:29:29.162994','2026-01-14 07:29:29.000000',3,'9bcafbc063d14a79ae2c037a8b65b1d4'),(132,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM3NTk4MiwiaWF0IjoxNzY3NzcxMTgyLCJqdGkiOiJiM2I0ZjYzZjZkODE0YTEyODQ5ZmI2MmI1Yzc2YzI5OCIsInVzZXJfaWQiOiIzIn0.njUoLNjr09ZMwq3Ju4f1qtogZDfUOHE5gQeMihCO5WE','2026-01-07 07:33:02.781616','2026-01-14 07:33:02.000000',3,'b3b4f63f6d814a12849fb62b5c76c298'),(133,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM3NzQ4NSwiaWF0IjoxNzY3NzcyNjg1LCJqdGkiOiIxZjdkZWM3NTE2OWU0N2YxYjAyM2IwYWY3NjY5ODI0NSIsInVzZXJfaWQiOiIxIn0.YpRB0b8mz92_2CAQRRyQI_DIkexN8oc3n60pSJ77Rng','2026-01-07 07:58:05.790577','2026-01-14 07:58:05.000000',1,'1f7dec75169e47f1b023b0af76698245'),(134,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM3OTk2MSwiaWF0IjoxNzY3Nzc1MTYxLCJqdGkiOiI2YTc5ZjE3MTQ3NzQ0ZTVlYWMwYjAyZGVkODU5YjdlOSIsInVzZXJfaWQiOiIxIn0.DQfEEoq0EN3hyVJoR8tm88CgGFP92vNxeVazukll5Hg','2026-01-07 08:39:21.194029','2026-01-14 08:39:21.000000',1,'6a79f17147744e5eac0b02ded859b7e9'),(135,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM4MDM0NSwiaWF0IjoxNzY3Nzc1NTQ1LCJqdGkiOiI5MjI2NjVjOGRmNTQ0ZWM3YjdlNzQyNDczMmE2YjlhMCIsInVzZXJfaWQiOiIxMCJ9.5xQ2A9Q904YzLLAKZYqvwvkmmx1uUW5XISRnJSuO6ko','2026-01-07 08:45:45.701139','2026-01-14 08:45:45.000000',10,'922665c8df544ec7b7e7424732a6b9a0'),(136,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM4MTA4OCwiaWF0IjoxNzY3Nzc2Mjg4LCJqdGkiOiJiODg0MjQ2NjZiMDY0ZjA2ODU2ZTBmM2NkMjkwMDA1MCIsInVzZXJfaWQiOiI2In0.UzC6OOC1KuBpc74dLpe9fckf4tG-__ZnSC9DOWdz6iY','2026-01-07 08:58:08.978399','2026-01-14 08:58:08.000000',6,'b88424666b064f06856e0f3cd2900050'),(137,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM4MzExOCwiaWF0IjoxNzY3Nzc4MzE4LCJqdGkiOiI5MmNlNDBhNzgyNzc0M2Y5YTU5ZWE2ZmMyMDBlNWIwYiIsInVzZXJfaWQiOiIxIn0.FRU4alhXpwb6UcfEBz6x3AXAbi1pJ1kPPgvFaHUggZ4','2026-01-07 09:31:58.795936','2026-01-14 09:31:58.000000',1,'92ce40a7827743f9a59ea6fc200e5b0b'),(138,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5MDA5OSwiaWF0IjoxNzY3Nzg1Mjk5LCJqdGkiOiIyYWE0MGRkOTBmNjU0MGQzODY5ZDdjZWYzNzBiY2Y1OSIsInVzZXJfaWQiOiIxIn0.CUleMYBZj1Lu8c0DqosdybLbNg-0wkRf7i67R8BXKz8','2026-01-07 11:28:19.126722','2026-01-14 11:28:19.000000',1,'2aa40dd90f6540d3869d7cef370bcf59'),(139,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5MDU2MiwiaWF0IjoxNzY3Nzg1NzYyLCJqdGkiOiJjOTY1NjZmYTZmNDQ0NDdmOTUyZThlNzJiYmI5M2NjNiIsInVzZXJfaWQiOiIxIn0.p2Xo4XMR9g_A2l3GdO8U4bW3Pp-MKhOg7duuK0C3AVU','2026-01-07 11:36:02.552502','2026-01-14 11:36:02.000000',1,'c96566fa6f44447f952e8e72bbb93cc6'),(140,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5MDczMiwiaWF0IjoxNzY3Nzg1OTMyLCJqdGkiOiJkYmNiMjQ1MjAzNGY0ZDkwODI1YTlkMTZhYWY4MmM5NCIsInVzZXJfaWQiOiI5In0.C2qMRXWQ3vYG-XIqkIhlc1q_fFvsGRehWCvUm4iZ7WQ','2026-01-07 11:38:52.996449','2026-01-14 11:38:52.000000',9,'dbcb2452034f4d90825a9d16aaf82c94'),(141,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5MDczOCwiaWF0IjoxNzY3Nzg1OTM4LCJqdGkiOiJmZDllYjc5YmVlM2Y0ZDMxOWExMTU2MGM2MWUyNzA3MCIsInVzZXJfaWQiOiIxIn0.PpewG7ZoS6WWVvAwVEpHlCwxpHuhBF5lriOWTsYJsu4','2026-01-07 11:38:58.436933','2026-01-14 11:38:58.000000',1,'fd9eb79bee3f4d319a11560c61e27070'),(142,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5MTAwOCwiaWF0IjoxNzY3Nzg2MjA4LCJqdGkiOiJmZTdjZWI5NmQyNzc0MTFjODYzZDBkMTZhODkzMjRiNCIsInVzZXJfaWQiOiIxMCJ9.AQQSTD2XwWtpHwvcPdLYv07sYxWbSsQcBAprlbLiHnM','2026-01-07 11:43:28.769289','2026-01-14 11:43:28.000000',10,'fe7ceb96d277411c863d0d16a89324b4'),(143,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5Mjc5OSwiaWF0IjoxNzY3Nzg3OTk5LCJqdGkiOiJmNTk4NDY4NTkxOTE0MDFkYjZiMjhkMjkzYWE4YTE0OSIsInVzZXJfaWQiOiIxIn0.YmlZ0vVeRUq_C5Shk-d7abwhxXUSa1GVmlnqu3lT2gA','2026-01-07 12:13:19.053786','2026-01-14 12:13:19.000000',1,'f59846859191401db6b28d293aa8a149'),(144,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5Mjc5OSwiaWF0IjoxNzY3Nzg3OTk5LCJqdGkiOiJiNTQ0ZTIwZWVhMzA0ZDQzYTc0ZjhkYzk4YmExZTVmYSIsInVzZXJfaWQiOiIxIn0.E_qwA13kqwoXy9ocdkh5JbGwAwpne00LsV7O6Tr86x8','2026-01-07 12:13:19.051643','2026-01-14 12:13:19.000000',1,'b544e20eea304d43a74f8dc98ba1e5fa'),(145,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5Mjc5OSwiaWF0IjoxNzY3Nzg3OTk5LCJqdGkiOiJhZGJkYzhkMmZiZjc0MDg2ODU4YTlkNjMyMDJiZjEzZCIsInVzZXJfaWQiOiIxIn0.UvEytNbWoDVaoK8BIsKHzufXcASI970SrrqYSLTZrzc','2026-01-07 12:13:19.055674','2026-01-14 12:13:19.000000',1,'adbdc8d2fbf74086858a9d63202bf13d'),(146,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5Mjc5OSwiaWF0IjoxNzY3Nzg3OTk5LCJqdGkiOiJmNDhhMDNkZmUwMzk0NWMwOGQ4MjA0MWVhZDk5ZTdlYyIsInVzZXJfaWQiOiIxIn0.oninoAB_A1bM5Agkek7A2sQIX8jAUC4AFS0B6ihoDuQ','2026-01-07 12:13:19.052888','2026-01-14 12:13:19.000000',1,'f48a03dfe03945c08d82041ead99e7ec'),(147,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODM5Mjc5OSwiaWF0IjoxNzY3Nzg3OTk5LCJqdGkiOiI5MTk2MDAxYzcyNGU0OTZkOTQ0NjQ3ZWUwYmE0ODVjYSIsInVzZXJfaWQiOiIxIn0.xgDjC076IuG-gbIMVsrCPQPyadbzA1h4cRJRHE8Ylko','2026-01-07 12:13:19.057593','2026-01-14 12:13:19.000000',1,'9196001c724e496d944647ee0ba485ca'),(148,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQwMTM1MCwiaWF0IjoxNzY3Nzk2NTUwLCJqdGkiOiIwMmM0NGFiNWQ3ZTY0YzhhOThmMWQ2YjQyNmFhZjI3ZiIsInVzZXJfaWQiOiIxIn0.vrGaK7t_4Wyr6HrRisX_1rbNJxjheLOnXsrbFDk3mus','2026-01-07 14:35:50.707691','2026-01-14 14:35:50.000000',1,'02c44ab5d7e64c8a98f1d6b426aaf27f'),(149,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQwMTU1MSwiaWF0IjoxNzY3Nzk2NzUxLCJqdGkiOiJlZDBmNGRiN2RiOTY0MDhkYWMzM2JmOGRjNjcwMzcwZCIsInVzZXJfaWQiOiIxIn0.Ywv-29BwVZcS2ZK743IQw1lb8_tr_1veLbd6ju0qj-I','2026-01-07 14:39:11.450984','2026-01-14 14:39:11.000000',1,'ed0f4db7db96408dac33bf8dc670370d'),(150,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQwMTYxNSwiaWF0IjoxNzY3Nzk2ODE1LCJqdGkiOiJlZDA2YjE3MmNjNmE0N2Y4ODhhYmQ5OTc5NWNiMjgzZCIsInVzZXJfaWQiOiIxIn0.q1Sq3iUWOdWygdV11V2LCMHgiICGlZY0Z4F7_R5txnk','2026-01-07 14:40:15.073686','2026-01-14 14:40:15.000000',1,'ed06b172cc6a47f888abd99795cb283d'),(151,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQwMTY1MSwiaWF0IjoxNzY3Nzk2ODUxLCJqdGkiOiIyMDAyOTYzNmY4MTQ0MjM5OGEwNjg4NmZjZmYzNzQ0NSIsInVzZXJfaWQiOiIxMCJ9.8qhrKGXzRvcazRSdUfwfGvH2qdHqUJRiReJrLw3-m_A','2026-01-07 14:40:51.008726','2026-01-14 14:40:51.000000',10,'20029636f81442398a06886fcff37445'),(152,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NDI4NSwiaWF0IjoxNzY3ODQ5NDg1LCJqdGkiOiJkYWM4MGM0NDI3M2U0ZmQzYWY1NDQ4ZWYyMzgwZjQ3MiIsInVzZXJfaWQiOiI2In0.-3qq2_hyrW5df4jWBfy40xnT1pyxj7xEEviqyMFsmo0','2026-01-08 05:18:05.912567','2026-01-15 05:18:05.000000',6,'dac80c44273e4fd3af5448ef2380f472'),(153,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NDY0MCwiaWF0IjoxNzY3ODQ5ODQwLCJqdGkiOiIzYTZiZDcyZDdkZjc0ZmQ2OGU4YTU5NjhjMTJmY2I3YiIsInVzZXJfaWQiOiI2In0.cksCkqMHiB1w8ckHgK7LjTuTEDMHIhPOQh1rTM0kiBg','2026-01-08 05:24:00.357484','2026-01-15 05:24:00.000000',6,'3a6bd72d7df74fd68e8a5968c12fcb7b'),(154,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NTI5OSwiaWF0IjoxNzY3ODUwNDk5LCJqdGkiOiI4YTA5Y2RhY2MzMzQ0Y2M0YWVlYTRjZTA1MGI0MzIzYyIsInVzZXJfaWQiOiIxIn0.fGytQ70ARCiSp8KkmTJEqQu5dN-KxFm7W9uJiFLP9ZI','2026-01-08 05:34:59.785957','2026-01-15 05:34:59.000000',1,'8a09cdacc3344cc4aeea4ce050b4323c'),(155,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NTMwMCwiaWF0IjoxNzY3ODUwNTAwLCJqdGkiOiI4N2YyMDljN2Y4NWE0YTBjYjIxOWM3MWMwNmRhYTY2NyIsInVzZXJfaWQiOiIxIn0.Gkk2KHYx_nolRf32r_AfGgBgLZGEd5cQQmZ_wplkBS8','2026-01-08 05:35:00.756394','2026-01-15 05:35:00.000000',1,'87f209c7f85a4a0cb219c71c06daa667'),(156,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NTMyMiwiaWF0IjoxNzY3ODUwNTIyLCJqdGkiOiIyNzM4OGQzN2QwODQ0ZWFlODg4NDRhMTEwMzZmNDI0ZCIsInVzZXJfaWQiOiI2In0.ouZs6r7HdV_1LK90dwSkO2SdhWohL_jPQsKk6jtT6Og','2026-01-08 05:35:22.971532','2026-01-15 05:35:22.000000',6,'27388d37d0844eae88844a11036f424d'),(157,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NTczMiwiaWF0IjoxNzY3ODUwOTMyLCJqdGkiOiJjNjRhMWQwY2I5MzY0ODhjYmNlZDc3MDM5ODVlMGZmOCIsInVzZXJfaWQiOiI2In0._LSEGYhGACkkRjk3OTkuFh-PEyWLihm-t2MXtDtZAx8','2026-01-08 05:42:12.973894','2026-01-15 05:42:12.000000',6,'c64a1d0cb936488cbced7703985e0ff8'),(158,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NjczMiwiaWF0IjoxNzY3ODUxOTMyLCJqdGkiOiI0YTdhYWEwZGExYWY0OGEyYWEzYzNlMDY1MzE2YWY4MiIsInVzZXJfaWQiOiI2In0.YYrlQCTtg3CCyU7LCEdbfJWoJbvyILS5irwRkk4BQGQ','2026-01-08 05:58:52.358375','2026-01-15 05:58:52.000000',6,'4a7aaa0da1af48a2aa3c3e065316af82'),(159,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1Njc0MywiaWF0IjoxNzY3ODUxOTQzLCJqdGkiOiI4MjRlZmVkNjcxNWM0ODYyYTk0ZjRmMjBlZjEyOTY2NCIsInVzZXJfaWQiOiIxIn0.5dGsPncYTfkcasnDlAtM24O2hPUUmtfrsr57HF0j2wM','2026-01-08 05:59:03.283120','2026-01-15 05:59:03.000000',1,'824efed6715c4862a94f4f20ef129664'),(160,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NjgwOSwiaWF0IjoxNzY3ODUyMDA5LCJqdGkiOiI2MmRjYTQ3M2E2YjY0NWU5OTg1NmVhYWUyMDNmM2Y1MCIsInVzZXJfaWQiOiI2In0.U9Y4tCQS7iWNumbMCGBWsnYAOrMXjG8W-CdT2a8YvA0','2026-01-08 06:00:09.928360','2026-01-15 06:00:09.000000',6,'62dca473a6b645e99856eaae203f3f50'),(161,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NzM4NywiaWF0IjoxNzY3ODUyNTg3LCJqdGkiOiJjODg1ZWU5OGYxZWQ0YTZjOWM2ZGIxY2VlNTRjYzdlNiIsInVzZXJfaWQiOiIxIn0.EonixRqkTq9ug0z0TWhUtZ_fOimNzhwNAJ9RWCAGSM4','2026-01-08 06:09:47.629058','2026-01-15 06:09:47.000000',1,'c885ee98f1ed4a6c9c6db1cee54cc7e6'),(162,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NzM4NywiaWF0IjoxNzY3ODUyNTg3LCJqdGkiOiI2MTU3ZDA0NmQ4MDc0ZjAwOGZjZmYwNTc4NjBhYTBlNCIsInVzZXJfaWQiOiIxIn0.muXtc3os_SKfrtB2-SKMaejTZT3NzxsJXRbLrQ7iyjI','2026-01-08 06:09:47.674401','2026-01-15 06:09:47.000000',1,'6157d046d8074f008fcff057860aa0e4'),(163,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NzM4NywiaWF0IjoxNzY3ODUyNTg3LCJqdGkiOiI0ZDUzMjYwOTRmNDI0OTdhOWYzZmZmY2YwYTU4Mzc4ZSIsInVzZXJfaWQiOiIxIn0.jZ-DF6Aw1h_kBmO6xaOWScaxut3LGH7arktRJNfL-8c','2026-01-08 06:09:47.676148','2026-01-15 06:09:47.000000',1,'4d5326094f42497a9f3fffcf0a58378e'),(164,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NzM4NywiaWF0IjoxNzY3ODUyNTg3LCJqdGkiOiJmYjAzOWRjYjg1ZDQ0NTQ2YjBlYTM4MDRjNDdhZDczMiIsInVzZXJfaWQiOiIxIn0.AtFbGx2L7GULtG6mGEChdMApJdQ069Vl7ED21ofHQ6c','2026-01-08 06:09:47.678400','2026-01-15 06:09:47.000000',1,'fb039dcb85d44546b0ea3804c47ad732'),(165,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ1NzM5MCwiaWF0IjoxNzY3ODUyNTkwLCJqdGkiOiJjNjFiMmE5MGI2OGI0ODlkODdmMzljMWE0MTdmZDc4OSIsInVzZXJfaWQiOiIxIn0.qBW0ZZn7WOt3R6ctjWn89UwQjZLH9VEePAtLpxh4-5E','2026-01-08 06:09:50.790272','2026-01-15 06:09:50.000000',1,'c61b2a90b68b489d87f39c1a417fd789'),(166,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2MDMzMywiaWF0IjoxNzY3ODU1NTMzLCJqdGkiOiI0YTY0MDk3MmQyMmY0ODI1YTg4NDg0M2Q2MDgyOGM1ZiIsInVzZXJfaWQiOiI2In0.6ExV6lkwPAyrUJoiS2Mm3AFV7HyU6FuK_iSAPCiGfYk','2026-01-08 06:58:53.959205','2026-01-15 06:58:53.000000',6,'4a640972d22f4825a884843d60828c5f'),(167,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2MzY2NiwiaWF0IjoxNzY3ODU4ODY2LCJqdGkiOiJkODU1ZmE2MDMxYzc0M2FkYjIwZDdjNTc1NDk2ZGZiMSIsInVzZXJfaWQiOiIxIn0.eshT1Ci1QZS32ngmZCwwqImREaqMx_5p9XtEuqK9IWI','2026-01-08 07:54:26.442548','2026-01-15 07:54:26.000000',1,'d855fa6031c743adb20d7c575496dfb1'),(168,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2MzY4NywiaWF0IjoxNzY3ODU4ODg3LCJqdGkiOiI5OWM3NDMxZDdiM2Y0YzVlYjc0ODdmNDYwZmJhNDQ3ZiIsInVzZXJfaWQiOiIxIn0.PUoD914jC3tplkrFReW-DDh1Ro4g68Gorgqu-eDXrhc','2026-01-08 07:54:47.925186','2026-01-15 07:54:47.000000',1,'99c7431d7b3f4c5eb7487f460fba447f'),(169,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2NTAwMCwiaWF0IjoxNzY3ODYwMjAwLCJqdGkiOiI5YWQ4MDMyZjhiN2U0ZWEzYTI3OTY0OWI0NGNlMzI3ZiIsInVzZXJfaWQiOiIyIn0.EQiXVgl3Li27Fw3etQhOtDU1E8vwuaGYHsnxmDpjgWE','2026-01-08 08:16:40.463322','2026-01-15 08:16:40.000000',2,'9ad8032f8b7e4ea3a279649b44ce327f'),(170,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2NjQzNSwiaWF0IjoxNzY3ODYxNjM1LCJqdGkiOiI2MDhkMTNlZTk3ZTA0ZWViOGY5ODAwYmU0NWZiN2E5ZSIsInVzZXJfaWQiOiIxIn0.ar7IewHXyg1hbT3BkXhcEmmWGbxvHoZNsqeKJCgLLxY','2026-01-08 08:40:35.961398','2026-01-15 08:40:35.000000',1,'608d13ee97e04eeb8f9800be45fb7a9e'),(171,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2NjQzNiwiaWF0IjoxNzY3ODYxNjM2LCJqdGkiOiJiOTMwMjhkZmI3ODE0NjI0OTYyMDBhZGZhZDk2Y2ZhYiIsInVzZXJfaWQiOiIxIn0.XKgbANT6XSKpUU_-Boj7raci2dQmwaNulLIC4F8tTa0','2026-01-08 08:40:36.004292','2026-01-15 08:40:36.000000',1,'b93028dfb781462496200adfad96cfab'),(172,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2NjQ0NSwiaWF0IjoxNzY3ODYxNjQ1LCJqdGkiOiJiYmRiMGEwZTNiZjQ0NDExOTFlYzQ5ODIyNDRhNTg1MyIsInVzZXJfaWQiOiI2In0.K92nPeSgmEAhNOw84w57Ve2BIW7ci9Ud2b_jQ59RhbA','2026-01-08 08:40:45.749991','2026-01-15 08:40:45.000000',6,'bbdb0a0e3bf4441191ec4982244a5853'),(173,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2NjQ0NSwiaWF0IjoxNzY3ODYxNjQ1LCJqdGkiOiI1NWZkZmUzZjlmNTM0MWExOGNiN2E2NmE4NmRmOGUxOCIsInVzZXJfaWQiOiI2In0.8dV_QJvgwz384I9G-_2jH9Z5gK8wqCp3fDpdq0ll8i0','2026-01-08 08:40:45.752714','2026-01-15 08:40:45.000000',6,'55fdfe3f9f5341a18cb7a66a86df8e18'),(174,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2ODAxOCwiaWF0IjoxNzY3ODYzMjE4LCJqdGkiOiI3ZTYxNzRhOWM0MGU0Y2FhOTYwMmVmYTVhMDE0NDI4YSIsInVzZXJfaWQiOiI2In0.SicX6iMxfuUhmoT7vBC02cNefxxMjfiMH_F1v9Rtygo','2026-01-08 09:06:58.532974','2026-01-15 09:06:58.000000',6,'7e6174a9c40e4caa9602efa5a014428a'),(175,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2ODIyOCwiaWF0IjoxNzY3ODYzNDI4LCJqdGkiOiIwYTJiM2ZiOGU5ZDg0NmM5OWU2NDNiNDE4ZmQyNzk4YSIsInVzZXJfaWQiOiI2In0.xE3ywFXdav6uS-3SmFn3u99eMivNwo5-MLbN_jwR33w','2026-01-08 09:10:28.384909','2026-01-15 09:10:28.000000',6,'0a2b3fb8e9d846c99e643b418fd2798a'),(176,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2ODQ4OSwiaWF0IjoxNzY3ODYzNjg5LCJqdGkiOiJiMGM0NGQzODNiODE0ODVjYTA4NjljMGJjZjg0OWIwZCIsInVzZXJfaWQiOiI2In0.i67iMtdq5W0t-eb2B3nelpHPjXlS1FM8kxye254WDhI','2026-01-08 09:14:49.832819','2026-01-15 09:14:49.000000',6,'b0c44d383b81485ca0869c0bcf849b0d'),(177,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2ODg2NCwiaWF0IjoxNzY3ODY0MDY0LCJqdGkiOiJiYjEwYjdiNmE5M2E0NWMzOWQ0OWVkMjYzMDJmNzNhYSIsInVzZXJfaWQiOiIxIn0.J8yDFzA_AbmkkOGuQ80y666DIZmib7EzIUrG_gu5-z4','2026-01-08 09:21:04.937461','2026-01-15 09:21:04.000000',1,'bb10b7b6a93a45c39d49ed26302f73aa'),(178,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2ODg2NCwiaWF0IjoxNzY3ODY0MDY0LCJqdGkiOiJiMzQ0MTJmOWMwZGM0Y2RiODFkODkwZTZiNTcwYmNlNSIsInVzZXJfaWQiOiIxIn0.DRXCzKF4Rzipqyt9P9eqLu3FumaG_7uDGQrH6k1sEus','2026-01-08 09:21:04.944823','2026-01-15 09:21:04.000000',1,'b34412f9c0dc4cdb81d890e6b570bce5'),(179,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2ODkxMywiaWF0IjoxNzY3ODY0MTEzLCJqdGkiOiJjYWQ4MDc2OWQ2ZTQ0ODZjODAwM2QwMzc4YTU0NWUwNCIsInVzZXJfaWQiOiI3In0.vUD4NJPWNCvnOc6eiavkDa_qiPt9KNKJZan1wCO5WtU','2026-01-08 09:21:53.412195','2026-01-15 09:21:53.000000',7,'cad80769d6e4486c8003d0378a545e04'),(180,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2ODk4NCwiaWF0IjoxNzY3ODY0MTg0LCJqdGkiOiI2YmMwMGJiYzBjZjc0MmU0OTkxNjQ5YzViMGNlODBkYiIsInVzZXJfaWQiOiI5In0.xfrOWmaqrC7oy0_dMXRvJk_qLLx0VeCgAfM1FVdYCzM','2026-01-08 09:23:04.913364','2026-01-15 09:23:04.000000',9,'6bc00bbc0cf742e4991649c5b0ce80db'),(181,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2OTQxOSwiaWF0IjoxNzY3ODY0NjE5LCJqdGkiOiJmNjdhOTUyODRiNmM0OTFiOWJjY2I3ZTVkZWU4NDRjMSIsInVzZXJfaWQiOiI4In0.0i-ozSyfbFOzctCZQ3-oHeD7KrU6DZ4Q-irKROoWmHk','2026-01-08 09:30:19.373414','2026-01-15 09:30:19.000000',8,'f67a95284b6c491b9bccb7e5dee844c1'),(182,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2OTk0MCwiaWF0IjoxNzY3ODY1MTQwLCJqdGkiOiIyYTcyMDQ5NGVhYjc0NzA1YjhjMGE0MmUyNGZmZDhkMyIsInVzZXJfaWQiOiIxIn0.aOY8AYWdLgNKu6QDQk0WqvKCuFWm2fPh9cs288jNPXo','2026-01-08 09:39:00.490921','2026-01-15 09:39:00.000000',1,'2a720494eab74705b8c0a42e24ffd8d3'),(183,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ2OTk0MCwiaWF0IjoxNzY3ODY1MTQwLCJqdGkiOiJjZjY0ZjRhZWM5NWY0OTIzOGZjZmFmOGVlMTU4NGU3YyIsInVzZXJfaWQiOiIxIn0.N5ofGtCgduVhWOvl-LBurCt_BEpctrvlIKdY6bJfXLk','2026-01-08 09:39:00.492779','2026-01-15 09:39:00.000000',1,'cf64f4aec95f49238fcfaf8ee1584e7c'),(184,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3MTE3MSwiaWF0IjoxNzY3ODY2MzcxLCJqdGkiOiJkNDU3ZTY4YjM2NWQ0N2EzYmI2OTNhZTY4MzA0OTZkYiIsInVzZXJfaWQiOiI2In0.M_pd79ITIi99U9hTs7uZ05p_XXOxElpBGIsRRFIr01Q','2026-01-08 09:59:31.183674','2026-01-15 09:59:31.000000',6,'d457e68b365d47a3bb693ae6830496db'),(185,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3MTE5MiwiaWF0IjoxNzY3ODY2MzkyLCJqdGkiOiJmMmZmZDdiMjE3Mzc0NzgyOWU5NDlmZWIyNjRhMDhmYyIsInVzZXJfaWQiOiIxIn0.oCgX9NcMIDRkANUfMAFfxS9gVThnewDZZJIdDyFb-b0','2026-01-08 09:59:52.448722','2026-01-15 09:59:52.000000',1,'f2ffd7b2173747829e949feb264a08fc'),(186,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3MTI3NiwiaWF0IjoxNzY3ODY2NDc2LCJqdGkiOiJkZmZhOWM4YWYyZDI0YzU0ODA3ZGQ4OGIyYmVlYjBiNSIsInVzZXJfaWQiOiIxIn0.oi8X5_rN4239uMDG6HiXyqW5za3hUlkRX_yysO_m6MU','2026-01-08 10:01:16.963936','2026-01-15 10:01:16.000000',1,'dffa9c8af2d24c54807dd88b2beeb0b5'),(187,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3NjY0NiwiaWF0IjoxNzY3ODcxODQ2LCJqdGkiOiJiODQ2NDMzZjhkMjg0M2I3YTU1MDhmZjgxMjU2MTRiZSIsInVzZXJfaWQiOiIxIn0.nURWg5FZ9-3m6qBFKFmtJ4n9KOKjj03um7F54w2vMyY','2026-01-08 11:30:46.792390','2026-01-15 11:30:46.000000',1,'b846433f8d2843b7a5508ff8125614be'),(188,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3ODQ1MiwiaWF0IjoxNzY3ODczNjUyLCJqdGkiOiJjZjgyNmEyNTA5ZWI0Y2I3OTIzNmYzZDlkNDcxNzg2MSIsInVzZXJfaWQiOiIxIn0.ed_xA-mpv35IwQrqTo_IhtV5xhkmURHXK7gq1EHfTXg','2026-01-08 12:00:52.899684','2026-01-15 12:00:52.000000',1,'cf826a2509eb4cb79236f3d9d4717861'),(189,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3ODQ1MiwiaWF0IjoxNzY3ODczNjUyLCJqdGkiOiI0NDY4M2ExZWYwZGQ0OTE4YTRiNzQ1NWY1NDNjMDI1YiIsInVzZXJfaWQiOiIxIn0.-CYjxomjY2NvzQnjF85Gq_m6Coryx_SbAH20U-Hbrgk','2026-01-08 12:00:52.906205','2026-01-15 12:00:52.000000',1,'44683a1ef0dd4918a4b7455f543c025b'),(190,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3OTEwMSwiaWF0IjoxNzY3ODc0MzAxLCJqdGkiOiIwNGU0MTlkOGI2ZjU0N2NhODE2NjkzMWIzOWExZTUwZSIsInVzZXJfaWQiOiIyIn0.I3O18m7ITDteRHX4Xu_z9unQZIUUOjaadpOHacKI2fo','2026-01-08 12:11:41.001515','2026-01-15 12:11:41.000000',2,'04e419d8b6f547ca8166931b39a1e50e'),(191,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3OTE5NywiaWF0IjoxNzY3ODc0Mzk3LCJqdGkiOiIyNzA1NjI0MmZjNjI0ZjAxYTk4NWI1NWY5YzEyMjBkMyIsInVzZXJfaWQiOiI2In0.domTlnUfCTDZx0fDgdO-0fgG5CabLC2A2urU-hI2Plg','2026-01-08 12:13:17.435883','2026-01-15 12:13:17.000000',6,'27056242fc624f01a985b55f9c1220d3'),(192,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3OTIwMSwiaWF0IjoxNzY3ODc0NDAxLCJqdGkiOiJlN2JkOTA1Y2VjYjc0OTg0OGEyN2YxM2JjN2I1MThmYyIsInVzZXJfaWQiOiIyIn0.KhXm7taY5RZWNLJC5JBJPrvOE4Iggx1UxL_aX5okIJI','2026-01-08 12:13:21.660429','2026-01-15 12:13:21.000000',2,'e7bd905cecb749848a27f13bc7b518fc'),(193,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ3OTI5NywiaWF0IjoxNzY3ODc0NDk3LCJqdGkiOiJjYTI5M2U0YmU5OGM0YzE4YTQ4MDczNTNkOTNkN2ZjZiIsInVzZXJfaWQiOiIxIn0.LVyKrIa0HO-Z_yQFXwM1z-wy_U0xY8oDLj6sP63TYZc','2026-01-08 12:14:57.175652','2026-01-15 12:14:57.000000',1,'ca293e4be98c4c18a4807353d93d7fcf'),(194,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MDg1NywiaWF0IjoxNzY3ODc2MDU3LCJqdGkiOiI4MzFlMDBiZmJiNGM0ZTM4ODY4MzE5MTgzZDkxYjJiYiIsInVzZXJfaWQiOiI2In0.R1Vpm8EholMcsxP53aKf1P1HZ-2fPwXEFlvuqpVI7Zc','2026-01-08 12:40:57.513809','2026-01-15 12:40:57.000000',6,'831e00bfbb4c4e38868319183d91b2bb'),(195,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MDg5MiwiaWF0IjoxNzY3ODc2MDkyLCJqdGkiOiIyNDNiZTYzNTAyNDc0NWZhYmNiYjgyZGY3NWUzYTJjYiIsInVzZXJfaWQiOiIxIn0.xfwCNgz9kVUCNrcWthwsbgc-C9hrgr9fpGYp0YZqngQ','2026-01-08 12:41:32.780826','2026-01-15 12:41:32.000000',1,'243be635024745fabcbb82df75e3a2cb'),(196,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MTY4OSwiaWF0IjoxNzY3ODc2ODg5LCJqdGkiOiI2ZmM4YzNiMTAxZjk0ZGIwYmU3OTZiOWUxOWJhYWQ5MyIsInVzZXJfaWQiOiI3In0.C0edt06Is8UbCi9y5Q1JVntu2wqufyfxuMkn9j2j2pg','2026-01-08 12:54:49.927553','2026-01-15 12:54:49.000000',7,'6fc8c3b101f94db0be796b9e19baad93'),(197,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MTg0OSwiaWF0IjoxNzY3ODc3MDQ5LCJqdGkiOiJiNWY2YzA1YjJjOTU0YzEzOTgxYmE3NmE3YzE3ZDExMiIsInVzZXJfaWQiOiIxIn0.xra9TmvTiTJ3ndgqKzj1JMHnxjYcg7Fp4aR_TifLbmA','2026-01-08 12:57:29.528198','2026-01-15 12:57:29.000000',1,'b5f6c05b2c954c13981ba76a7c17d112'),(198,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MTg0OSwiaWF0IjoxNzY3ODc3MDQ5LCJqdGkiOiIwZTAyYjU0NGE3Zjc0MWRlYjlmNjlkYjk0YTNlODk0YyIsInVzZXJfaWQiOiIxIn0.0P9CkFpLfX3OmxViurjqGulyJLeJvzl63wnbU-HnWBo','2026-01-08 12:57:29.542114','2026-01-15 12:57:29.000000',1,'0e02b544a7f741deb9f69db94a3e894c'),(199,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MTg0OSwiaWF0IjoxNzY3ODc3MDQ5LCJqdGkiOiJmYjk4ZWY1ZWFkZmQ0OTI4ODY1YzQ5MWY1MWNkZTAyNyIsInVzZXJfaWQiOiIxIn0.DNeBdRw7zCwMTUH1DDSajaA4o74hrbbJtpiIzXO0jvU','2026-01-08 12:57:29.544161','2026-01-15 12:57:29.000000',1,'fb98ef5eadfd4928865c491f51cde027'),(200,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MTg0OSwiaWF0IjoxNzY3ODc3MDQ5LCJqdGkiOiJhZjU4YWI5YmJiMTY0NGQwODJjY2RkNGE2ZTlhZGNiMCIsInVzZXJfaWQiOiIxIn0.2sC2QKcWYfIhuxOnKI3UMWWF_mGhBULrvmiipShav1I','2026-01-08 12:57:29.540385','2026-01-15 12:57:29.000000',1,'af58ab9bbb1644d082ccdd4a6e9adcb0'),(201,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MTg0OSwiaWF0IjoxNzY3ODc3MDQ5LCJqdGkiOiJkMjgzMzFkOTZjY2U0NjRmYjIyMDczODM5MDQ1ODUzOSIsInVzZXJfaWQiOiIxIn0.N-9kYhFHquK4MWKpeEII1nwxylsR1qB1qOKSo3_2r-4','2026-01-08 12:57:29.539339','2026-01-15 12:57:29.000000',1,'d28331d96cce464fb220738390458539'),(202,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4Mjg3MSwiaWF0IjoxNzY3ODc4MDcxLCJqdGkiOiI3OGMwMWJkNjNhZGU0M2VkOTQwMjQ2ZTYzYmY5YzA0NyIsInVzZXJfaWQiOiIxIn0.uXYjL0VvN7HnzugtOA7ExIb27SOCTLtsAwwzvsSUmIw','2026-01-08 13:14:31.875667','2026-01-15 13:14:31.000000',1,'78c01bd63ade43ed940246e63bf9c047'),(203,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MzE4MiwiaWF0IjoxNzY3ODc4MzgyLCJqdGkiOiJmMDk5NzEwMDU2MGI0YmZhYmY5NTQwMDA5MzAwMThmMCIsInVzZXJfaWQiOiIxMSJ9.GOMdh3FQzmqn7kiNTre_GdcgmkmRnSwL55SrRxObhD0','2026-01-08 13:19:42.654493','2026-01-15 13:19:42.000000',11,'f0997100560b4bfabf954000930018f0'),(204,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4MzU5MywiaWF0IjoxNzY3ODc4NzkzLCJqdGkiOiJjYzk2NzZhMjM4YTk0ZjEzODE5NGQxZjY0NDk5ZjY3OCIsInVzZXJfaWQiOiI3In0.lUZculecj3UV4R02TAw6JWd0mmCAlqqZ3v_vZnqqha0','2026-01-08 13:26:33.210398','2026-01-15 13:26:33.000000',7,'cc9676a238a94f138194d1f64499f678'),(205,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4NDQyNSwiaWF0IjoxNzY3ODc5NjI1LCJqdGkiOiJiMDYyNzE1ZDU2Yjc0ZGI4OGZhOTY5ODllNzc2YzMzNSIsInVzZXJfaWQiOiI2In0.y27XSeOM3lk0iB2q4EPKTBnx0oslpcCVzZ25SX5dcaI','2026-01-08 13:40:25.339614','2026-01-15 13:40:25.000000',6,'b062715d56b74db88fa96989e776c335'),(206,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4NTg0NiwiaWF0IjoxNzY3ODgxMDQ2LCJqdGkiOiJiNjhhMDExNDI5YTY0OTQzODgwYjM1YWY0NzkxNTI1NSIsInVzZXJfaWQiOiIxIn0.UkDoVwlmdEGdgx9gFfJp850WoSlr9CpYe5eHI8Mkmgk','2026-01-08 14:04:06.209427','2026-01-15 14:04:06.000000',1,'b68a011429a64943880b35af47915255'),(207,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4NTg0NiwiaWF0IjoxNzY3ODgxMDQ2LCJqdGkiOiIyMTMwNDI0NjIwMTI0NjJjODUzNzNhZDdkNzgzY2M4NCIsInVzZXJfaWQiOiIxIn0.v3lPXWW4A_4LXwZDRNTiIiN1JrTIws79iHRJTt5X004','2026-01-08 14:04:06.208304','2026-01-15 14:04:06.000000',1,'213042462012462c85373ad7d783cc84'),(208,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4NTg0NiwiaWF0IjoxNzY3ODgxMDQ2LCJqdGkiOiI2ZTdmMzE5MTQxOTc0ZTM5OTY0NTJlOTBlMzdlZDk5YSIsInVzZXJfaWQiOiIxIn0.vu6g7k7YjZz1N_xe-Ujc0o1tg_SM_OC2i4Y9t3aHqC4','2026-01-08 14:04:06.205296','2026-01-15 14:04:06.000000',1,'6e7f319141974e3996452e90e37ed99a'),(209,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4NTg0NiwiaWF0IjoxNzY3ODgxMDQ2LCJqdGkiOiI1ZWVmYzZiNGU2NjQ0MzI5YmE0YzliY2EzZGQwNWNhZCIsInVzZXJfaWQiOiIxIn0.N-jh2Xk18q4eP4Qa0gLqA6lJHyXd8TroKIBWU9wsWbc','2026-01-08 14:04:06.207173','2026-01-15 14:04:06.000000',1,'5eefc6b4e6644329ba4c9bca3dd05cad'),(210,'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0b2tlbl90eXBlIjoicmVmcmVzaCIsImV4cCI6MTc2ODQ4NTg0NiwiaWF0IjoxNzY3ODgxMDQ2LCJqdGkiOiJkM2FhNDBhZTc4ZTA0ZGRjYmU3MWRjMjAzMGQ1NThiZCIsInVzZXJfaWQiOiIxIn0.b_3RFRK2ZhNDmt5RIw5M3W-aC0Z7k1m_HvHQp1fOuNM','2026-01-08 14:04:06.210599','2026-01-15 14:04:06.000000',1,'d3aa40ae78e04ddcbe71dc2030d558bd');
/*!40000 ALTER TABLE `token_blacklist_outstandingtoken` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_accommodationbooking`
--

DROP TABLE IF EXISTS `travel_accommodationbooking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_accommodationbooking` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `accommodation_type` varchar(30) NOT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL,
  `nights` int unsigned NOT NULL,
  `guest_count` int unsigned NOT NULL,
  `hotel_name` varchar(200) NOT NULL,
  `hotel_contact` varchar(100) NOT NULL,
  `hotel_address` longtext NOT NULL,
  `status` varchar(30) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `special_requests` longtext NOT NULL,
  `rate_per_night` decimal(8,2) DEFAULT NULL,
  `total_cost` decimal(10,2) DEFAULT NULL,
  `confirmation_number` varchar(100) NOT NULL,
  `booking_reference` varchar(100) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `confirmed_at` datetime(6) DEFAULT NULL,
  `arc_hotel_id` bigint DEFAULT NULL,
  `guest_house_id` bigint DEFAULT NULL,
  `trip_details_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_acco_trip_de_52a529_idx` (`trip_details_id`,`status`),
  KEY `travel_acco_check_i_10527c_idx` (`check_in_date`,`check_out_date`),
  KEY `travel_accommodation_arc_hotel_id_4013f634_fk_master_da` (`arc_hotel_id`),
  KEY `travel_accommodation_guest_house_id_a6d7b7af_fk_master_da` (`guest_house_id`),
  CONSTRAINT `travel_accommodation_arc_hotel_id_4013f634_fk_master_da` FOREIGN KEY (`arc_hotel_id`) REFERENCES `master_data_archotelmaster` (`id`),
  CONSTRAINT `travel_accommodation_guest_house_id_a6d7b7af_fk_master_da` FOREIGN KEY (`guest_house_id`) REFERENCES `master_data_guesthousemaster` (`id`),
  CONSTRAINT `travel_accommodation_trip_details_id_2d6e2dc5_fk_travel_tr` FOREIGN KEY (`trip_details_id`) REFERENCES `travel_tripdetails` (`id`),
  CONSTRAINT `travel_accommodationbooking_chk_1` CHECK ((`nights` >= 0)),
  CONSTRAINT `travel_accommodationbooking_chk_2` CHECK ((`guest_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_accommodationbooking`
--

LOCK TABLES `travel_accommodationbooking` WRITE;
/*!40000 ALTER TABLE `travel_accommodationbooking` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_accommodationbooking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_auditlog`
--

DROP TABLE IF EXISTS `travel_auditlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_auditlog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action` varchar(30) NOT NULL,
  `timestamp` datetime(6) NOT NULL,
  `object_id` int unsigned NOT NULL,
  `changes` json NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `user_agent` longtext NOT NULL,
  `content_type_id` int NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_audi_content_ffc724_idx` (`content_type_id`,`object_id`),
  KEY `travel_audi_user_id_ee2356_idx` (`user_id`,`timestamp` DESC),
  CONSTRAINT `travel_auditlog_content_type_id_4e26221b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `travel_auditlog_user_id_1da82577_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `travel_auditlog_chk_1` CHECK ((`object_id` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_auditlog`
--

LOCK TABLES `travel_auditlog` WRITE;
/*!40000 ALTER TABLE `travel_auditlog` DISABLE KEYS */;
INSERT INTO `travel_auditlog` VALUES (1,'reject','2026-01-05 13:06:17.398474',1,'{\"reason\": \"Need to update 7 days before\", \"approval_level\": \"manager\"}','192.168.1.1:60240','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',51,7),(2,'cancel','2026-01-05 13:08:53.289722',1,'{\"reason\": \"Need to update befor 7 days\", \"current_status\": \"cancellation_requested\", \"previous_status\": \"rejected_manager\"}',NULL,'',51,6),(3,'cancelled','2026-01-05 13:09:33.552048',1,'{\"reason\": \"Need to update befor 7 days\", \"previous_status\": \"cancellation_requested\"}',NULL,'',51,7),(4,'approve','2026-01-05 13:36:26.441429',3,'{\"notes\": \"\", \"approval_level\": \"manager\"}','192.168.1.1:52804','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',51,7),(5,'approve','2026-01-08 09:22:26.577522',11,'{\"notes\": \"\", \"approval_level\": \"manager\"}','192.168.1.1:62026','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',51,7),(6,'approve','2026-01-08 09:35:06.047211',12,'{\"notes\": \"\", \"approval_level\": \"manager\"}','192.168.1.1:52258','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',51,7),(7,'approve','2026-01-08 09:35:07.344850',13,'{\"notes\": \"\", \"approval_level\": \"manager\"}','192.168.1.1:52258','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0',51,7),(8,'assign_booking','2026-01-08 13:18:34.823365',20,'{\"scope\": \"single_booking\", \"agent_id\": 11, \"booking_id\": 20, \"application_id\": 12}',NULL,'',50,1),(9,'update_booking_status','2026-01-08 13:20:21.345450',20,'{\"remarks\": \"\", \"booking_id\": 20, \"new_status\": \"confirmed\"}',NULL,'',50,11);
/*!40000 ALTER TABLE `travel_auditlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_booking`
--

DROP TABLE IF EXISTS `travel_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_booking` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `booking_details` json NOT NULL,
  `status` varchar(20) NOT NULL,
  `estimated_cost` decimal(10,2) DEFAULT NULL,
  `actual_cost` decimal(10,2) DEFAULT NULL,
  `booking_reference` varchar(100) NOT NULL,
  `vendor_reference` varchar(100) NOT NULL,
  `booking_file` varchar(100) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `booked_at` datetime(6) DEFAULT NULL,
  `booking_type_id` bigint NOT NULL,
  `sub_option_id` bigint DEFAULT NULL,
  `trip_details_id` bigint NOT NULL,
  `special_instruction` longtext NOT NULL,
  `uploaded_at` datetime(6) DEFAULT NULL,
  `uploaded_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_book_trip_de_429dac_idx` (`trip_details_id`,`booking_type_id`),
  KEY `travel_book_status_0ce8c3_idx` (`status`),
  KEY `travel_booking_booking_type_id_4785424a_fk_master_da` (`booking_type_id`),
  KEY `travel_booking_sub_option_id_9ce46d1d_fk_master_da` (`sub_option_id`),
  KEY `travel_booking_uploaded_by_id_072a5d25_fk_auth_user_id` (`uploaded_by_id`),
  CONSTRAINT `travel_booking_booking_type_id_4785424a_fk_master_da` FOREIGN KEY (`booking_type_id`) REFERENCES `master_data_travelmodemaster` (`id`),
  CONSTRAINT `travel_booking_sub_option_id_9ce46d1d_fk_master_da` FOREIGN KEY (`sub_option_id`) REFERENCES `master_data_travelsuboptionmaster` (`id`),
  CONSTRAINT `travel_booking_trip_details_id_93de9488_fk_travel_tripdetails_id` FOREIGN KEY (`trip_details_id`) REFERENCES `travel_tripdetails` (`id`),
  CONSTRAINT `travel_booking_uploaded_by_id_072a5d25_fk_auth_user_id` FOREIGN KEY (`uploaded_by_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_booking`
--

LOCK TABLES `travel_booking` WRITE;
/*!40000 ALTER TABLE `travel_booking` DISABLE KEYS */;
INSERT INTO `travel_booking` VALUES (16,'{\"to_location\": \"1945\", \"arrival_date\": \"2026-01-15\", \"arrival_time\": \"00:00\", \"from_location\": \"601\", \"ticket_number\": \"AIR-4023\", \"departure_date\": \"2026-01-12\", \"departure_time\": \"00:00\", \"meal_preference\": \"Vegeterian Food\", \"to_location_name\": \"Pune (Maharashtra, India)\", \"from_location_name\": \"Ahmedabad (Gujarat, India)\"}','pending',NULL,NULL,'','','','2026-01-07 11:34:54.345331','2026-01-07 11:34:54.345352',NULL,1,1,8,'',NULL,NULL),(17,'{\"place\": \"\", \"check_in_date\": \"2026-01-12\", \"check_in_time\": \"00:00\", \"check_out_date\": \"2026-01-15\", \"check_out_time\": \"00:00\", \"meal_preference\": \"Vegeterian Food\", \"guest_house_preferences\": []}','pending',NULL,NULL,'','','','2026-01-07 11:34:54.349059','2026-01-07 11:34:54.349079',NULL,7,9,8,'',NULL,NULL),(18,'{\"to_location\": \"186\", \"arrival_date\": \"2026-01-21\", \"arrival_time\": \"10:00\", \"from_location\": \"78\", \"ticket_number\": \"dfsdfsdfdf\", \"departure_date\": \"2026-01-20\", \"departure_time\": \"10:00\", \"meal_preference\": \"Vegeterian Food\", \"to_location_name\": \"Vijayawada (Andhra Pradesh, India)\", \"from_location_name\": \"Guntur (Andhra Pradesh, India)\"}','pending',8500.00,NULL,'','','','2026-01-08 06:08:46.750248','2026-01-08 06:08:46.750274',NULL,2,2,10,'sdfsdfsdfsdfsdfsdff',NULL,NULL),(19,'{\"place\": \"\", \"check_in_date\": \"2026-01-21\", \"check_in_time\": \"10:00\", \"check_out_date\": \"2026-01-21\", \"check_out_time\": \"12:00\", \"meal_preference\": \"Vegeterian Food\", \"guest_house_preferences\": []}','pending',9000.00,NULL,'','','','2026-01-08 06:08:46.754265','2026-01-08 06:08:46.754296',NULL,7,9,10,'test',NULL,NULL),(20,'{\"to_location\": \"467\", \"arrival_date\": \"2026-01-29\", \"arrival_time\": \"10:00\", \"from_location\": \"1803\", \"ticket_number\": \"dfsdfsdf\", \"departure_date\": \"2026-01-29\", \"departure_time\": \"00:00\", \"meal_preference\": \"Vegeterian Food\", \"to_location_name\": \"Durg (Chhattisgarh, India)\", \"from_location_name\": \"Durgapur (Maharashtra, India)\"}','confirmed',1000.00,1250.00,'','','','2026-01-08 07:21:47.923252','2026-01-08 13:20:21.323981','2026-01-08 13:20:21.323860',2,3,11,'',NULL,NULL),(21,'{\"to_location\": \"2909\", \"arrival_date\": \"2026-02-07\", \"arrival_time\": \"10:00\", \"from_location\": \"601\", \"ticket_number\": \"sdfsdfsdf\", \"departure_date\": \"2026-02-01\", \"departure_time\": \"09:00\", \"meal_preference\": \"Non. Vegeterian Food\", \"to_location_name\": \"Lal Bahadur Nagar (Telangana, India)\", \"from_location_name\": \"Ahmedabad (Gujarat, India)\"}','pending',1000.00,NULL,'','','','2026-01-08 09:33:49.262710','2026-01-08 09:33:49.262727',NULL,1,1,12,'sdsdfsdfsdf',NULL,NULL),(22,'{\"place\": \"\", \"check_in_date\": \"2026-02-01\", \"check_in_time\": \"11:00\", \"check_out_date\": \"2026-02-07\", \"check_out_time\": \"10:00\", \"meal_preference\": \"Vegeterian Food\", \"guest_house_preferences\": []}','pending',1000.00,NULL,'','','','2026-01-08 09:33:49.263591','2026-01-08 09:33:49.263607',NULL,7,9,12,'sdfsdfsdfsdf',NULL,NULL),(23,'{\"guests\": [], \"report_at\": \"Railway Station\", \"start_date\": \"2026-02-01\", \"start_time\": \"10:00\", \"club_reason\": \"\", \"distance_km\": \"\", \"to_location\": \"dfsdfsdf\", \"club_booking\": true, \"not_required\": false, \"drop_location\": \"Guest House\", \"from_location\": \"fsdfsdfsdfsdf\", \"has_six_airbags\": true}','pending',2000.00,NULL,'','','','2026-01-08 09:33:49.264444','2026-01-08 09:33:49.264462',NULL,3,4,12,'',NULL,NULL);
/*!40000 ALTER TABLE `travel_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_bookingassignment`
--

DROP TABLE IF EXISTS `travel_bookingassignment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_bookingassignment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `assignment_scope` varchar(20) NOT NULL,
  `notes` longtext NOT NULL,
  `assigned_at` datetime(6) NOT NULL,
  `accepted_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `assigned_by_id` bigint DEFAULT NULL,
  `assigned_to_id` bigint DEFAULT NULL,
  `booking_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `booking_id` (`booking_id`),
  KEY `travel_book_assigne_136358_idx` (`assigned_to_id`,`assigned_at`),
  KEY `travel_bookingassignment_assigned_by_id_31ea5296_fk_auth_user_id` (`assigned_by_id`),
  CONSTRAINT `travel_bookingassign_booking_id_169ad787_fk_travel_bo` FOREIGN KEY (`booking_id`) REFERENCES `travel_booking` (`id`),
  CONSTRAINT `travel_bookingassignment_assigned_by_id_31ea5296_fk_auth_user_id` FOREIGN KEY (`assigned_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `travel_bookingassignment_assigned_to_id_844addc3_fk_auth_user_id` FOREIGN KEY (`assigned_to_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_bookingassignment`
--

LOCK TABLES `travel_bookingassignment` WRITE;
/*!40000 ALTER TABLE `travel_bookingassignment` DISABLE KEYS */;
INSERT INTO `travel_bookingassignment` VALUES (1,'single_booking','','2026-01-08 13:18:34.816776',NULL,NULL,1,11,20);
/*!40000 ALTER TABLE `travel_bookingassignment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_bookingnote`
--

DROP TABLE IF EXISTS `travel_bookingnote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_bookingnote` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `note` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `author_id` bigint DEFAULT NULL,
  `booking_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_bookingnote_author_id_4a3cf513_fk_auth_user_id` (`author_id`),
  KEY `travel_bookingnote_booking_id_3d206131_fk_travel_booking_id` (`booking_id`),
  CONSTRAINT `travel_bookingnote_author_id_4a3cf513_fk_auth_user_id` FOREIGN KEY (`author_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `travel_bookingnote_booking_id_3d206131_fk_travel_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `travel_booking` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_bookingnote`
--

LOCK TABLES `travel_bookingnote` WRITE;
/*!40000 ALTER TABLE `travel_bookingnote` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_bookingnote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_traveladvancerequest`
--

DROP TABLE IF EXISTS `travel_traveladvancerequest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_traveladvancerequest` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `air_fare` decimal(10,2) NOT NULL,
  `train_fare` decimal(10,2) NOT NULL,
  `lodging_fare` decimal(10,2) NOT NULL,
  `conveyance_fare` decimal(10,2) NOT NULL,
  `other_expenses` decimal(10,2) NOT NULL,
  `special_instruction` longtext NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `trip_detail_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trip_detail_id` (`trip_detail_id`),
  CONSTRAINT `travel_traveladvance_trip_detail_id_2e6c2b03_fk_travel_tr` FOREIGN KEY (`trip_detail_id`) REFERENCES `travel_tripdetails` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_traveladvancerequest`
--

LOCK TABLES `travel_traveladvancerequest` WRITE;
/*!40000 ALTER TABLE `travel_traveladvancerequest` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_traveladvancerequest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_travelapplication`
--

DROP TABLE IF EXISTS `travel_travelapplication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_travelapplication` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `purpose` longtext NOT NULL,
  `internal_order` varchar(50) DEFAULT NULL,
  `sanction_number` varchar(50) DEFAULT NULL,
  `advance_amount` decimal(10,2) DEFAULT NULL,
  `estimated_total_cost` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL,
  `is_settled` tinyint(1) NOT NULL,
  `settlement_due_date` date DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `submitted_at` datetime(6) DEFAULT NULL,
  `current_approver_id` bigint DEFAULT NULL,
  `employee_id` bigint NOT NULL,
  `general_ledger_id` bigint DEFAULT NULL,
  `cancellation_approved_at` datetime(6) DEFAULT NULL,
  `cancellation_reason` longtext NOT NULL,
  `cancellation_requested_at` datetime(6) DEFAULT NULL,
  `cancelled_by_id` bigint DEFAULT NULL,
  `self_approved` tinyint(1) NOT NULL,
  `booking_completed_at` datetime(6) DEFAULT NULL,
  `booking_forwarded_at` datetime(6) DEFAULT NULL,
  `travel_desk_user_id` bigint DEFAULT NULL,
  `previous_status` varchar(30) DEFAULT NULL,
  `cancellation_rejection_reason` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_trav_employe_b46994_idx` (`employee_id`,`status`),
  KEY `travel_trav_status_9c519a_idx` (`status`,`current_approver_id`),
  KEY `travel_trav_created_f63a79_idx` (`created_at`),
  KEY `travel_travelapplica_current_approver_id_94748edc_fk_auth_user` (`current_approver_id`),
  KEY `travel_travelapplica_general_ledger_id_d608ba11_fk_master_da` (`general_ledger_id`),
  KEY `travel_travelapplica_cancelled_by_id_650a8c54_fk_auth_user` (`cancelled_by_id`),
  KEY `travel_travelapplica_travel_desk_user_id_f084c742_fk_auth_user` (`travel_desk_user_id`),
  CONSTRAINT `travel_travelapplica_cancelled_by_id_650a8c54_fk_auth_user` FOREIGN KEY (`cancelled_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `travel_travelapplica_current_approver_id_94748edc_fk_auth_user` FOREIGN KEY (`current_approver_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `travel_travelapplica_general_ledger_id_d608ba11_fk_master_da` FOREIGN KEY (`general_ledger_id`) REFERENCES `master_data_glcodemaster` (`id`),
  CONSTRAINT `travel_travelapplica_travel_desk_user_id_f084c742_fk_auth_user` FOREIGN KEY (`travel_desk_user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `travel_travelapplication_employee_id_93e57e2e_fk_auth_user_id` FOREIGN KEY (`employee_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_travelapplication`
--

LOCK TABLES `travel_travelapplication` WRITE;
/*!40000 ALTER TABLE `travel_travelapplication` DISABLE KEYS */;
INSERT INTO `travel_travelapplication` VALUES (8,'Test Application to check whether application is visible on travel desk portal','IONUMBER','SANCNUMBER',NULL,0.00,'pending_travel_desk',0,'2026-02-14','2026-01-07 11:34:54.341364','2026-01-07 11:34:54.341463','2026-01-07 11:34:54.554062',NULL,1,2,NULL,'',NULL,NULL,1,NULL,NULL,NULL,NULL,''),(10,'Test TR from Travel desk','IO','SANC',NULL,0.00,'draft',0,NULL,'2026-01-07 12:14:38.434413','2026-01-07 12:14:38.434438',NULL,NULL,1,3,NULL,'',NULL,NULL,0,NULL,NULL,NULL,NULL,''),(11,'sdfsdfsdfsdfsdfdsf','dfsdfsdfsdf','sfsdfssfsfsf',1000.00,17500.00,'pending_travel_desk',0,'2026-02-20','2026-01-08 06:08:46.744063','2026-01-08 09:22:26.557439','2026-01-08 06:08:46.915678',NULL,6,3,NULL,'',NULL,NULL,0,NULL,NULL,NULL,NULL,''),(12,'Test the Icon functionality','1234567891111dfsdfs','sddsfdf',1000.00,1000.00,'booked',0,'2026-02-28','2026-01-08 07:21:47.920947','2026-01-08 09:35:06.036501','2026-01-08 09:34:45.166320',NULL,6,2,NULL,'',NULL,NULL,0,NULL,NULL,NULL,NULL,''),(13,'To Check the full Cycle of the upto travel desk','gdgdfg64646','dfsdfsdf',1000.00,4000.00,'pending_travel_desk',0,'2026-03-09','2026-01-08 09:33:49.260943','2026-01-08 09:35:07.334253','2026-01-08 09:33:49.395763',NULL,6,2,NULL,'',NULL,NULL,0,NULL,NULL,NULL,NULL,'');
/*!40000 ALTER TABLE `travel_travelapplication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_travelapprovalflow`
--

DROP TABLE IF EXISTS `travel_travelapprovalflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_travelapprovalflow` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `approval_level` varchar(20) NOT NULL,
  `sequence` int unsigned NOT NULL,
  `can_view` tinyint(1) NOT NULL,
  `can_approve` tinyint(1) NOT NULL,
  `status` varchar(20) NOT NULL,
  `approved_at` datetime(6) DEFAULT NULL,
  `notes` longtext NOT NULL,
  `is_required` tinyint(1) NOT NULL,
  `triggered_by_rule` varchar(100) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `approver_id` bigint NOT NULL,
  `travel_application_id` bigint NOT NULL,
  `parallel_group` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `travel_travelapprovalflo_travel_application_id_ap_495f6887_uniq` (`travel_application_id`,`approver_id`,`approval_level`),
  KEY `travel_trav_travel__986962_idx` (`travel_application_id`,`sequence`),
  KEY `travel_trav_approve_b4a76c_idx` (`approver_id`,`status`),
  CONSTRAINT `travel_travelapprova_travel_application_i_0cd72296_fk_travel_tr` FOREIGN KEY (`travel_application_id`) REFERENCES `travel_travelapplication` (`id`),
  CONSTRAINT `travel_travelapprovalflow_approver_id_d318ffde_fk_auth_user_id` FOREIGN KEY (`approver_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `travel_travelapprovalflow_chk_1` CHECK ((`sequence` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_travelapprovalflow`
--

LOCK TABLES `travel_travelapprovalflow` WRITE;
/*!40000 ALTER TABLE `travel_travelapprovalflow` DISABLE KEYS */;
INSERT INTO `travel_travelapprovalflow` VALUES (7,'self_approval',1,1,1,'approved','2026-01-07 11:34:54.551573','Auto-approved (no approver required)',1,'','2026-01-07 11:34:54.551984',1,8,NULL),(8,'manager',1,1,1,'approved','2026-01-08 09:22:26.547720','',1,'','2026-01-08 06:08:46.914190',7,11,NULL),(9,'manager',1,1,1,'approved','2026-01-08 09:35:07.319089','',1,'','2026-01-08 09:33:49.394997',7,13,NULL),(10,'manager',1,1,1,'approved','2026-01-08 09:35:06.023212','',1,'','2026-01-08 09:34:45.165579',7,12,NULL);
/*!40000 ALTER TABLE `travel_travelapprovalflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_traveldocument`
--

DROP TABLE IF EXISTS `travel_traveldocument`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_traveldocument` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_type` varchar(30) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `file` varchar(100) NOT NULL,
  `file_size` int unsigned DEFAULT NULL,
  `file_type` varchar(50) NOT NULL,
  `uploaded_at` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `related_booking_id` bigint DEFAULT NULL,
  `travel_application_id` bigint NOT NULL,
  `uploaded_by_id` bigint NOT NULL,
  `parent_document_id` bigint DEFAULT NULL,
  `thumbnail` varchar(100) DEFAULT NULL,
  `version` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_trav_travel__6bd4ec_idx` (`travel_application_id`,`document_type`),
  KEY `travel_trav_uploade_320d7d_idx` (`uploaded_by_id`,`uploaded_at`),
  KEY `travel_traveldocumen_related_booking_id_91b7859d_fk_travel_bo` (`related_booking_id`),
  KEY `travel_traveldocumen_parent_document_id_674dbf22_fk_travel_tr` (`parent_document_id`),
  CONSTRAINT `travel_traveldocumen_parent_document_id_674dbf22_fk_travel_tr` FOREIGN KEY (`parent_document_id`) REFERENCES `travel_traveldocument` (`id`),
  CONSTRAINT `travel_traveldocumen_related_booking_id_91b7859d_fk_travel_bo` FOREIGN KEY (`related_booking_id`) REFERENCES `travel_booking` (`id`),
  CONSTRAINT `travel_traveldocumen_travel_application_i_e7fe1caf_fk_travel_tr` FOREIGN KEY (`travel_application_id`) REFERENCES `travel_travelapplication` (`id`),
  CONSTRAINT `travel_traveldocument_uploaded_by_id_202f9fef_fk_auth_user_id` FOREIGN KEY (`uploaded_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `travel_traveldocument_chk_1` CHECK ((`file_size` >= 0)),
  CONSTRAINT `travel_traveldocument_chk_2` CHECK ((`version` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_traveldocument`
--

LOCK TABLES `travel_traveldocument` WRITE;
/*!40000 ALTER TABLE `travel_traveldocument` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_traveldocument` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_tripdetails`
--

DROP TABLE IF EXISTS `travel_tripdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_tripdetails` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `departure_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `trip_purpose` longtext NOT NULL,
  `guest_count` int unsigned NOT NULL,
  `from_location_id` bigint DEFAULT NULL,
  `to_location_id` bigint DEFAULT NULL,
  `travel_application_id` bigint NOT NULL,
  `end_time` time(6) DEFAULT NULL,
  `estimated_distance_km` decimal(8,2) DEFAULT NULL,
  `start_time` time(6) DEFAULT NULL,
  `no_bookings_required` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_trip_travel__3ac1d1_idx` (`travel_application_id`,`departure_date`),
  KEY `travel_tripdetails_from_location_id_833c9fe5_fk_master_da` (`from_location_id`),
  KEY `travel_tripdetails_to_location_id_110b6436_fk_master_da` (`to_location_id`),
  CONSTRAINT `travel_tripdetails_from_location_id_833c9fe5_fk_master_da` FOREIGN KEY (`from_location_id`) REFERENCES `master_data_citymaster` (`id`),
  CONSTRAINT `travel_tripdetails_to_location_id_110b6436_fk_master_da` FOREIGN KEY (`to_location_id`) REFERENCES `master_data_citymaster` (`id`),
  CONSTRAINT `travel_tripdetails_travel_application_i_93084126_fk_travel_tr` FOREIGN KEY (`travel_application_id`) REFERENCES `travel_travelapplication` (`id`),
  CONSTRAINT `travel_tripdetails_chk_1` CHECK ((`guest_count` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_tripdetails`
--

LOCK TABLES `travel_tripdetails` WRITE;
/*!40000 ALTER TABLE `travel_tripdetails` DISABLE KEYS */;
INSERT INTO `travel_tripdetails` VALUES (8,'2026-01-12','2026-01-15','',0,601,1945,8,'00:00:00.000000',NULL,'00:00:00.000000',0),(9,'2026-01-16','2026-01-18','',0,601,1945,10,'00:00:00.000000',NULL,'00:00:00.000000',0),(10,'2026-01-20','2026-01-21','',0,78,186,11,'10:00:00.000000',NULL,'10:00:00.000000',0),(11,'2026-01-28','2026-01-29','',0,2254,2983,12,'00:00:00.000000',NULL,'10:00:00.000000',0),(12,'2026-02-01','2026-02-07','',0,601,2909,13,'10:00:00.000000',NULL,'10:00:00.000000',0);
/*!40000 ALTER TABLE `travel_tripdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_vehiclebooking`
--

DROP TABLE IF EXISTS `travel_vehiclebooking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `travel_vehiclebooking` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `vehicle_type` varchar(20) NOT NULL,
  `pickup_location` varchar(200) NOT NULL,
  `drop_location` varchar(200) NOT NULL,
  `pickup_date` date NOT NULL,
  `pickup_time` time(6) NOT NULL,
  `return_date` date DEFAULT NULL,
  `return_time` time(6) DEFAULT NULL,
  `estimated_distance` decimal(8,2) DEFAULT NULL,
  `estimated_duration` bigint DEFAULT NULL,
  `passenger_count` int unsigned NOT NULL,
  `special_requirements` longtext NOT NULL,
  `vendor_name` varchar(100) NOT NULL,
  `driver_name` varchar(100) NOT NULL,
  `driver_phone` varchar(15) NOT NULL,
  `vehicle_number` varchar(20) NOT NULL,
  `own_car_details` json NOT NULL,
  `status` varchar(20) NOT NULL,
  `duty_slip_number` varchar(50) NOT NULL,
  `estimated_cost` decimal(10,2) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `assigned_spoc_id` bigint DEFAULT NULL,
  `trip_details_id` bigint NOT NULL,
  `vehicle_category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `travel_vehi_trip_de_91df91_idx` (`trip_details_id`,`status`),
  KEY `travel_vehi_assigne_c66a9d_idx` (`assigned_spoc_id`,`status`),
  KEY `travel_vehiclebookin_vehicle_category_id_b7d8a7da_fk_master_da` (`vehicle_category_id`),
  CONSTRAINT `travel_vehiclebookin_assigned_spoc_id_17530269_fk_master_da` FOREIGN KEY (`assigned_spoc_id`) REFERENCES `master_data_locationspoc` (`id`),
  CONSTRAINT `travel_vehiclebookin_trip_details_id_434f8de1_fk_travel_tr` FOREIGN KEY (`trip_details_id`) REFERENCES `travel_tripdetails` (`id`),
  CONSTRAINT `travel_vehiclebookin_vehicle_category_id_b7d8a7da_fk_master_da` FOREIGN KEY (`vehicle_category_id`) REFERENCES `master_data_vehicletypemaster` (`id`),
  CONSTRAINT `travel_vehiclebooking_chk_1` CHECK ((`passenger_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_vehiclebooking`
--

LOCK TABLES `travel_vehiclebooking` WRITE;
/*!40000 ALTER TABLE `travel_vehiclebooking` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_vehiclebooking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `is_primary` tinyint(1) NOT NULL,
  `assigned_at` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `assigned_by_id` bigint DEFAULT NULL,
  `role_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `authentication_userrole_user_id_role_id_2e4aff32_uniq` (`user_id`,`role_id`),
  KEY `authentication_userr_assigned_by_id_9c018c80_fk_authentic` (`assigned_by_id`),
  KEY `authentication_userr_role_id_f9a93670_fk_authentic` (`role_id`),
  KEY `user_roles_user_id_50c4b6_idx` (`user_id`,`is_primary`),
  CONSTRAINT `authentication_userr_assigned_by_id_9c018c80_fk_authentic` FOREIGN KEY (`assigned_by_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `authentication_userr_role_id_f9a93670_fk_authentic` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `authentication_userr_user_id_981863a5_fk_authentic` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_roles`
--

LOCK TABLES `user_roles` WRITE;
/*!40000 ALTER TABLE `user_roles` DISABLE KEYS */;
INSERT INTO `user_roles` VALUES (1,1,'2025-12-31 08:40:07.725781',1,1,1,1),(2,1,'2026-01-01 05:09:05.925283',1,NULL,1,2),(3,0,'2026-01-01 06:38:33.928270',1,NULL,2,2),(4,1,'2026-01-01 06:43:05.685610',1,NULL,3,3),(5,1,'2026-01-01 06:46:51.871792',1,NULL,3,5),(6,1,'2026-01-05 09:41:13.301667',1,NULL,3,6),(7,1,'2026-01-05 12:58:03.396721',1,NULL,3,7),(8,0,'2026-01-05 12:58:03.406557',1,NULL,2,7),(11,0,'2026-01-06 07:29:03.006514',1,NULL,6,9),(13,1,'2026-01-06 08:58:28.198781',1,NULL,3,9),(14,1,'2026-01-06 10:16:15.329497',1,NULL,3,10),(15,0,'2026-01-07 11:35:17.814912',1,NULL,6,1),(16,0,'2026-01-07 11:35:33.603376',1,NULL,7,1),(17,0,'2026-01-07 11:35:33.603969',1,NULL,4,1),(18,0,'2026-01-07 11:35:33.604660',1,NULL,5,1),(19,1,'2026-01-08 09:30:19.294295',1,NULL,3,8),(20,0,'2026-01-08 09:30:19.368467',1,NULL,2,8),(21,1,'2026-01-08 09:47:40.114815',1,NULL,7,11),(22,0,'2026-01-08 12:12:50.987818',1,NULL,7,2),(23,0,'2026-01-08 12:12:50.988709',1,NULL,6,2);
/*!40000 ALTER TABLE `user_roles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-09  5:14:27
